[CmdletBinding()]
param([string]$TemporaryRoot=[IO.Path]::GetTempPath(),[string]$NativeScript)
$ErrorActionPreference='Stop'

# Parse and load only named helpers. Never evaluate native-com.ps1's entry point,
# interop compiler, real process launcher or COM attachment.
$source=if($NativeScript){$NativeScript}else{Join-Path $PSScriptRoot '..\bridge\native-com.ps1'}
$tokens=$null;$parseErrors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($source,[ref]$tokens,[ref]$parseErrors)
if($parseErrors.Count -ne 0){throw 'The native bridge did not parse'}
foreach($name in @('New-NativeFailure','Write-HostJson','Save-HostTerminalFailure','Throw-HostError','Get-SolidworksProcesses','Select-SolidworksStartup','Wait-SolidworksCom')){
    $found=@($ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $name},$false))
    if($found.Count -ne 1){throw ('Expected one production helper: '+$name)}
    . ([scriptblock]::Create($found[0].Extent.Text))
}

$tempRoot=[IO.Path]::GetFullPath($TemporaryRoot).TrimEnd('\')+'\'
if(-not [IO.Directory]::Exists($tempRoot)){throw 'The isolated test parent directory must already exist'}
$testHome=[IO.Path]::GetFullPath((Join-Path $tempRoot ('autosw-startup-policy-'+[Guid]::NewGuid().ToString('N'))))
if(-not $testHome.StartsWith($tempRoot,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe test directory'}
[void][IO.Directory]::CreateDirectory($testHome)
$request=@{host_home=$testHome}
$script:checked=0
function Assert-Policy([bool]$condition,[string]$message){if(-not $condition){throw $message};$script:checked++}
function Reset-Fixture {
    $script:processes=@();$script:inspectionFails=$false;$script:launchFails=$false
    $script:launchCount=0;$script:processReads=0;$script:snapshots=@();$script:nativeStage='fixture'
    $script:birth=[DateTime]::new(638000000000000002,[DateTimeKind]::Utc)
    $script:launched=[pscustomobject]@{ProcessName='SLDWORKS';Id=4242;StartTime=$script:birth}
    $script:hostState=@{ok=$true;status='starting';connected=$false;busy=$true;native_operation=$null;host_id=[Guid]::NewGuid().ToString();host_pid=4001;host_process_start_ticks='638000000000000001';source_sha256='fixture';native_launch_state='not_requested';native_launch_may_have_occurred=$false;cad_execution_not_started=$true}
}
function Get-Process {
    param([string]$Name,[string]$ErrorAction)
    if(($Name -and ($Name -cne 'SLDWORKS' -or $ErrorAction -cne 'SilentlyContinue')) -or (-not $Name -and $ErrorAction -cne 'Stop')){throw 'Unexpected process inspection policy'}
    $script:processReads++
    if($script:inspectionFails){throw 'Isolated process enumeration failure'}
    return $script:processes
}
function Save-HostState {
    $script:snapshots+=@(($hostState|ConvertTo-Json -Depth 32 -Compress|ConvertFrom-Json))
    Write-HostJson (Join-Path $request.host_home 'state.json') $hostState
}
function Start-Process {
    param([string]$FilePath,[string]$WorkingDirectory,[string]$WindowStyle,[switch]$PassThru)
    $script:launchCount++
    Assert-Policy ($WindowStyle -ceq 'Normal' -and $PassThru) 'Unexpected launch policy'
    Assert-Policy ($script:snapshots.Count -gt 0 -and $script:snapshots[-1].native_launch_state -ceq 'requested' -and $script:snapshots[-1].native_launch_may_have_occurred) 'Launch intent was not durable before dispatch'
    if($script:launchFails){throw 'Isolated launch response failure; application creation may have happened'}
    return $script:launched
}
function Capture-Failure([scriptblock]$action){try{& $action}catch{return $_};throw 'Expected isolated failure'}

try {
    Reset-Fixture
    Assert-Policy (@(Get-SolidworksProcesses).Count -eq 0) 'A successful empty snapshot should be accepted'
    Assert-Policy ($script:processReads -eq 1 -and $script:launchCount -eq 0) 'Inspection dispatched a launch'

    Reset-Fixture;$script:inspectionFails=$true
    $failure=Capture-Failure {Select-SolidworksStartup 'C:\fixture\SLDWORKS.exe'}
    Assert-Policy ($failure.Exception.Data['code'] -ceq 'SW_PROCESS_INSPECTION_FAILED') 'Enumeration errors were mistaken for absence'
    Assert-Policy ($script:launchCount -eq 0 -and $script:snapshots.Count -eq 0) 'An unconfirmed snapshot dispatched a launch'

    Reset-Fixture
    $unreadable=[pscustomobject]@{ProcessName='SLDWORKS';Id=4242}
    $unreadable|Add-Member ScriptProperty StartTime {throw 'Isolated inaccessible process birth'}
    $script:processes=@($unreadable)
    $failure=Capture-Failure {Select-SolidworksStartup 'C:\fixture\SLDWORKS.exe'}
    Assert-Policy ($failure.Exception.Data['code'] -ceq 'SW_PROCESS_INSPECTION_FAILED' -and $script:launchCount -eq 0) 'Unreadable process identity permitted a launch'

    Reset-Fixture
    Assert-Policy (@(Get-SolidworksProcesses).Count -eq 0) 'Initial snapshot should be empty'
    $script:processes=@($script:launched)
    $selected=Select-SolidworksStartup 'C:\fixture\SLDWORKS.exe'
    Assert-Policy ($script:processReads -eq 2 -and $script:launchCount -eq 0) 'The prelaunch resnapshot failed to reuse a new application'
    Assert-Policy ($selected.pid -eq 4242 -and -not $selected.created_app -and $script:snapshots[-1].native_launch_state -ceq 'preexisting') 'The reused process identity was not preserved'

    Reset-Fixture;$script:processes=@($script:launched,$script:launched)
    $failure=Capture-Failure {Select-SolidworksStartup 'C:\fixture\SLDWORKS.exe'}
    Assert-Policy ($failure.Exception.Data['code'] -ceq 'SW_RECONNECT_REQUIRED' -and $script:launchCount -eq 0) 'Multiple applications permitted another launch'

    Reset-Fixture
    $selected=Select-SolidworksStartup 'C:\fixture\SLDWORKS.exe'
    Assert-Policy ($script:launchCount -eq 1 -and $script:snapshots.Count -eq 2) 'Cold start was not dispatched exactly once'
    Assert-Policy ($script:snapshots[-1].native_launch_state -ceq 'launched' -and $script:snapshots[-1].pid -eq 4242 -and $script:snapshots[-1].process_start_ticks -ceq [string]$script:birth.Ticks) 'Actual launch identity was not durable before COM'
    $record=Capture-Failure {throw 'Isolated COM/frame initialization failure'}
    $terminal=Save-HostTerminalFailure $record 'attach_running_com' $false
    Assert-Policy ($terminal.state -ceq 'unknown' -and $terminal.busy -and -not $terminal.execution_not_started -and $terminal.cad_execution_not_started) 'Post-launch failure incorrectly claimed no application launch'
    $proof=Get-Content -LiteralPath (Join-Path $testHome ('startup-'+$hostState.host_id+'-failure.json')) -Raw|ConvertFrom-Json
    Assert-Policy ($proof.pid -eq 4242 -and $proof.process_start_ticks -ceq [string]$script:birth.Ticks -and $proof.native_launch_state -ceq 'launched' -and $proof.initialization_failed) 'Startup failure lost the original launched process proof'

    Reset-Fixture;$script:launchFails=$true
    $record=Capture-Failure {Select-SolidworksStartup 'C:\fixture\SLDWORKS.exe'}
    $terminal=Save-HostTerminalFailure $record 'launch_normal_application' $false
    Assert-Policy ($script:launchCount -eq 1 -and $terminal.state -ceq 'unknown' -and $terminal.native_launch_state -ceq 'requested' -and $terminal.native_launch_may_have_occurred -and -not $terminal.execution_not_started) 'An interrupted launch was treated as safely replayable'
    Assert-Policy (-not $hostState.ContainsKey('pid')) 'An unobserved launch invented a process identity'

    Reset-Fixture
    $record=Capture-Failure {throw 'Isolated prelaunch compilation failure'}
    $terminal=Save-HostTerminalFailure $record 'load_installed_interop' $false
    Assert-Policy ($terminal.state -ceq 'failed' -and -not $terminal.busy -and $terminal.execution_not_started -and $terminal.cad_execution_not_started -and -not $terminal.native_launch_may_have_occurred) 'A definite prelaunch failure became unknown'
    Assert-Policy ($script:launchCount -eq 0) 'Prelaunch failure dispatched an application'

    Reset-Fixture;$script:processes=@($script:launched,$script:launched)
    $record=Capture-Failure {Wait-SolidworksCom 4242 ([string]$script:birth.Ticks) 1 1}
    Assert-Policy ($record.Exception.Message -match 'original SOLIDWORKS startup process changed' -and $script:launchCount -eq 0) 'COM polling accepted multiple applications'

    @{ok=$true;checks=$script:checked;native_called=$false;real_process_launches=0;real_com_calls=0}|ConvertTo-Json -Compress
} finally {
    $resolved=[IO.Path]::GetFullPath($testHome)
    if(-not $resolved.StartsWith($tempRoot,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe cleanup target'}
    Remove-Item -LiteralPath $resolved -Recurse -Force
}
