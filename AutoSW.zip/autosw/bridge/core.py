"""Bounded, identity-scoped SOLIDWORKS COM automation; no third-party Python runtime."""
import hashlib
import json
import math
import os
import re
import subprocess
import uuid
from datetime import datetime, timezone
from pathlib import Path
from host_transport import HostError, IDENTITY_FIELDS, request_host

RUN_ID = re.compile(r'^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$', re.I)


class NativeOutcomeUnknown(RuntimeError):
    code = 'SW_OPERATION_UNKNOWN'
    def __init__(self, message, receipt=None):
        super().__init__(message)
        self.native_details = {key: receipt[key] for key in ('native_stage','hresult','native_error_type','native_line') if receipt and key in receipt}


class NativeOperationFailed(RuntimeError):
    def __init__(self, receipt):
        super().__init__(str(receipt.get('error', 'SOLIDWORKS native operation failed'))[:1200])
        self.native_details = {key: receipt[key] for key in ('native_stage', 'hresult', 'native_error_type', 'native_line') if key in receipt}
        self.code = receipt.get('code', 'SW_NATIVE_FAILED')
        self.execution_not_started = receipt.get('execution_not_started', False)


def local(path, missing=False):
    path = Path(path).absolute()
    for candidate in (path, *path.parents):
        if candidate.is_symlink() or (candidate.exists() and hasattr(candidate, 'is_junction') and candidate.is_junction()):
            raise ValueError('Linked paths are not allowed')
    if not missing and not path.exists():
        raise ValueError('Required local path does not exist')
    return path


def relative(root, value):
    if not isinstance(value, str) or not value or len(value) > 600 or re.search(r'[\x00-\x1f:*?"<>|]', value):
        raise ValueError('A workspace-relative file path is required')
    parts = value.replace('\\', '/').split('/')
    if any(part in ('', '.', '..') or part.endswith((' ', '.')) for part in parts):
        raise ValueError('Path traversal is not allowed')
    return local(root.joinpath(*parts))


def write_json(path, data):
    target = path.with_name('.' + uuid.uuid4().hex + '.tmp')
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    target.replace(path)


def native_project_path(root, run_id):
    target = root / 'solidworks-runs' / run_id / ('result-' + run_id + '.sldprt')
    if len(str(target).encode('utf-16-le')) // 2 > 255:
        raise ValueError('SOLIDWORKS原生项目完整路径超过255个UTF-16字符，请用较短项目目录；在同一工作区重试不会解决，本次尚未建模。')
    return target


def number(value, label, minimum=-10000, maximum=10000):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError('Invalid numeric parameter: ' + label)
    return float(value)


def validate_spec(value):
    if not isinstance(value, dict) or set(value) - {'schema_version', 'name', 'units', 'base', 'holes', 'density_kg_m3', 'export_step'}:
        raise ValueError('Unsupported SOLIDWORKS specification fields')
    if type(value.get('schema_version', 1)) is not int or value.get('schema_version', 1) != 1 or value.get('units') != 'mm':
        raise ValueError('Use schema_version 1 and explicit mm units')
    name = value.get('name', 'part')
    if not isinstance(name, str) or not 1 <= len(name) <= 100 or re.search(r'[\x00-\x1f]', name):
        raise ValueError('Invalid part name')
    base = value.get('base')
    if not isinstance(base, dict) or base.get('profile') not in ('rectangle', 'circle'):
        raise ValueError('Supported base profiles: rectangle, circle')
    profile = base['profile']
    allowed = {'profile', 'depth', 'width', 'height'} if profile == 'rectangle' else {'profile', 'depth', 'radius'}
    if set(base) != allowed:
        raise ValueError('Specify exactly the parameters required by the base profile')
    base = {key: number(val, key, 0.01, 10000) if key != 'profile' else val for key, val in base.items()}
    holes = value.get('holes', [])
    if not isinstance(holes, list) or len(holes) > 64:
        raise ValueError('At most 64 through holes are supported')
    normalized = []
    for hole in holes:
        if not isinstance(hole, dict) or set(hole) != {'x', 'y', 'radius'}:
            raise ValueError('Each through hole requires x, y, radius in sketch coordinates')
        item = dict(x=number(hole['x'], 'hole.x'), y=number(hole['y'], 'hole.y'), radius=number(hole['radius'], 'hole.radius', 0.01, 5000))
        if profile == 'rectangle':
            inside = abs(item['x']) + item['radius'] < base['width'] / 2 and abs(item['y']) + item['radius'] < base['height'] / 2
        else:
            inside = math.hypot(item['x'], item['y']) + item['radius'] < base['radius']
        if not inside or any(math.hypot(item['x']-other['x'], item['y']-other['y']) <= item['radius']+other['radius'] for other in normalized):
            raise ValueError('Through holes must be disjoint and wholly inside the base profile')
        normalized.append(item)
    density = number(value.get('density_kg_m3', 7800), 'density_kg_m3', 0.01, 100000)
    export = value.get('export_step', True)
    if not isinstance(export, bool):
        raise ValueError('export_step must be boolean')
    return dict(schema_version=1, name=name, units='mm', base=base, holes=normalized, density_kg_m3=density, export_step=export)


def theoretical_volume(spec):
    base = spec['base']
    area = base['width']*base['height'] if base['profile'] == 'rectangle' else math.pi*base['radius']**2
    return (area-sum(math.pi*hole['radius']**2 for hole in spec['holes']))*base['depth']*1e-9


def catalog():
    return dict(ok=True, software='SOLIDWORKS', api='Installed official Windows COM/.NET interfaces on one persistent STA host', supported=['compatible rectangle/circle JSON parts', 'model-written C# Build method body through reviewed owned-document context', 'official feature/sketch/assembly/drawing interfaces available in the installed API', 'native save/reopen/export/readback', 'installed API reflection via api command', 'Simulation only when the requested installed add-in and licence actually respond'],
                unsupported=['arbitrary process, filesystem, network, reflection or application lifecycle code', 'unverified blanket claims about all features or licences'], units='mm', legacy_json_units='mm', native_api_units='metres and radians',
                example=dict(schema_version=1, name='disc', units='mm', base=dict(profile='circle', radius=25, depth=8), holes=[dict(x=0,y=0,radius=5)], density_kg_m3=7800, export_step=True),
                instance_policy='Only explicit connect may start or attach an application. All task operations reuse the same login STA host and exact PID/birth/window. Existing user documents are retained; an exited original instance requires explicit reconnect, never automatic replay.',
                note='Connection and native execution require an installed, licensed SOLIDWORKS. Catalog presence is not a successful native test.')


def binding(root, run_id, encoded):
    if not RUN_ID.fullmatch(run_id or ''):
        raise ValueError('A version-4 run UUID is required')
    supplied = json.loads(encoded) if encoded else dict(account_id='standalone-local', session_id='standalone-local', workspace=str(root), run_id=run_id)
    if not isinstance(supplied, dict) or set(supplied) != {'account_id','session_id','workspace','run_id'}:
        raise ValueError('Invalid execution binding')
    if any(not isinstance(supplied[key],str) or not supplied[key] or len(supplied[key]) > 200 for key in ('account_id','session_id')):
        raise ValueError('Invalid owner or session identity')
    if supplied['run_id'] != run_id or Path(supplied['workspace']).resolve() != root.resolve():
        raise ValueError('Execution binding does not match this workspace/run')
    return supplied


def invoke_bridge(root, payload, request_path):
    if os.name != 'nt':
        raise RuntimeError('SOLIDWORKS desktop automation requires Windows')
    write_json(request_path, payload)
    try:
        receipt = request_host(payload, Path(__file__).with_name('native-com.ps1').resolve())
    except HostError as error:
        if error.unknown:
            raise NativeOutcomeUnknown(str(error)) from None
        raise NativeOperationFailed(dict(error=str(error), code=error.code, execution_not_started=True)) from None
    if receipt.get('ok') is not True:
        if receipt.get('state') == 'unknown' or receipt.get('code') == 'SW_OPERATION_UNKNOWN':
            raise NativeOutcomeUnknown(str(receipt.get('error', 'Native request remains unknown')), receipt) from None
        raise NativeOperationFailed(receipt)
    return receipt


def connection_snapshot(expected=None):
    payload = dict(operation='status')
    if expected is not None:
        payload['connection_identity'] = expected
    state = request_host(payload, Path(__file__).with_name('native-com.ps1').resolve())
    if state.get('connected') is not True or any(key not in state for key in IDENTITY_FIELDS):
        raise HostError('SW_RECONNECT_REQUIRED', '请先显式接入SOLIDWORKS；任务不会自动启动或替换原软件')
    return {key: state[key] for key in IDENTITY_FIELDS}


def bound_connection_snapshot(expected):
    """The caller's accepted window must never be replaced by the latest host."""
    current = connection_snapshot(expected)
    if expected is not None and current != expected:
        raise NativeOperationFailed(dict(code='SW_RECONNECT_REQUIRED', execution_not_started=True,
            error='原调用方绑定的SOLIDWORKS宿主或窗口已改变；尚未派发，不会操作新的连接'))
    return current


def output_file(directory, value, suffixes=None):
    if not isinstance(value, str) or not Path(value).is_absolute():
        raise RuntimeError('The native receipt must identify an absolute output path')
    file = local(value)
    try:
        file.resolve().relative_to(directory.resolve())
    except ValueError:
        raise RuntimeError('The native receipt references an output outside this run') from None
    if not file.is_file() or file.stat().st_size <= 0 or suffixes and file.suffix.lower() not in suffixes:
        raise RuntimeError('The registered native output is missing, empty or of an unsupported type')
    return file


def verify_general_result(receipt, directory, source_sha256, require_reopen, binding_json=None):
    if receipt.get('connected') is not True or receipt.get('visible') is not True or receipt.get('document_dirty') is not False or receipt.get('saved') is not True:
        raise RuntimeError('The actual native application and clean saved document were not confirmed')
    if require_reopen and receipt.get('reopened') is not True:
        raise RuntimeError('The generated native document was not positively reopened from disk')
    if receipt.get('source_sha256') != source_sha256:
        raise RuntimeError('The native receipt does not match the frozen source snapshot')
    if binding_json is not None and receipt.get('binding_sha256') != hashlib.sha256(binding_json.encode('utf-8')).hexdigest():
        raise RuntimeError('The native receipt does not match the original account/session/run binding')
    native = receipt.get('native_documents')
    if not isinstance(native, list) or not 1 <= len(native) <= 1024:
        raise RuntimeError('No bounded list of actual native documents was returned')
    registered = {}
    for item in native:
        if not isinstance(item, dict):
            raise RuntimeError('Invalid native document receipt')
        file = output_file(directory, item.get('path'), {'.sldprt', '.sldasm', '.slddrw'})
        digest = hashlib.sha256(file.read_bytes()).hexdigest()
        if digest != item.get('sha256') or str(file.resolve()).casefold() in registered:
            raise RuntimeError('Native document hash or unique identity was not confirmed')
        registered[str(file.resolve()).casefold()] = digest
    project = output_file(directory, receipt.get('project'), {'.sldprt', '.sldasm', '.slddrw'})
    if str(project.resolve()).casefold() not in registered:
        raise RuntimeError('The main native project is not in its registered document manifest')
    artifacts = receipt.get('artifacts')
    if not isinstance(artifacts, list) or not 1 <= len(artifacts) <= 4096:
        raise RuntimeError('No actual output artifact manifest was returned')
    for item in artifacts:
        file = output_file(directory, item.get('path'))
        if hashlib.sha256(file.read_bytes()).hexdigest() != item.get('sha256') or file.stat().st_size != item.get('bytes'):
            raise RuntimeError('An output artifact differs from the native receipt')
    output_file(directory, receipt.get('preview'), {'.png'})
    receipt['project_sha256'] = registered[str(project.resolve()).casefold()]


def authorized_artifact(root, directory, result, requested):
    if requested:
        file = relative(root, requested)
    else:
        file = output_file(directory, result.get('project'), {'.sldprt', '.sldasm', '.slddrw'})
    file = output_file(directory, str(file), {'.sldprt', '.sldasm', '.slddrw'})
    allowed = {str(Path(item['path']).resolve()).casefold(): item.get('sha256') for item in result.get('native_documents', []) if isinstance(item, dict) and isinstance(item.get('path'), str)}
    if result.get('project') and result.get('project_sha256'):
        allowed[str(Path(result['project']).resolve()).casefold()] = result['project_sha256']
    if allowed.get(str(file.resolve()).casefold()) != hashlib.sha256(file.read_bytes()).hexdigest():
        raise ValueError('Only the exact original run manifest native document and SHA may be opened')
    return str(file)


def execute(command, workspace, run_id=None, spec_path=None, binding_json=None,
            script_path=None, artifact=None, type_name=None, member_name=None, expected_connection_json=None,
            connect_intent_json=None):
    root = local(workspace)
    if not root.is_dir():
        raise ValueError('Workspace must be an existing directory')
    connection_intent=None
    if connect_intent_json is not None:
        if command not in ('connect','status'):
            raise ValueError('Internal connect intent is only accepted for explicit connect/read-only recovery')
        connection_intent=json.loads(connect_intent_json)
        if not isinstance(connection_intent,dict) or not isinstance(connection_intent.get('binding'),dict) or \
                not isinstance(connection_intent['binding'].get('workspace'),str) or Path(connection_intent['binding']['workspace']).resolve()!=root.resolve():
            raise ValueError('Internal connect intent does not match this workspace')
    expected_connection = None
    if expected_connection_json is not None:
        if command in ('connect', 'catalog'):
            raise ValueError('An expected connection selector cannot establish or replace a connection')
        expected_connection = json.loads(expected_connection_json)
        if not isinstance(expected_connection, dict) or set(expected_connection) != set(IDENTITY_FIELDS) or not isinstance(expected_connection.get('host_id'), str) or not RUN_ID.fullmatch(expected_connection['host_id']):
            raise ValueError('The exact caller-accepted host/application identity is required')
        if any(isinstance(expected_connection[key], bool) or not isinstance(expected_connection[key], int) or not 0 < expected_connection[key] < 2**53 for key in ('host_pid','pid','hwnd')):
            raise ValueError('Invalid host/application process or window identity')
        if any(not isinstance(expected_connection[key], str) or not re.fullmatch(r'[0-9]{1,22}', expected_connection[key]) for key in ('host_process_start_ticks','process_start_ticks')):
            raise ValueError('Invalid host/application process birth identity')
    if command == 'catalog':
        return catalog()
    if command in ('connect', 'status', 'disconnect', 'close-owned-empty', 'api'):
        for value in (type_name, member_name):
            if value is not None and (not isinstance(value, str) or len(value) > 200 or re.search(r'[\x00-\x1f]', value)):
                raise ValueError('API reflection names must be bounded strings')
        connection = root / 'solidworks-connection'
        connection.mkdir(exist_ok=True)
        local(connection)
        payload = dict(operation=command, type_name=type_name, member_name=member_name)
        if connection_intent is not None:payload['connect_intent']=connection_intent
        if expected_connection is not None:
            payload['connection_identity'] = expected_connection
        request_path = connection / ('probe-' + uuid.uuid4().hex + '.json')
        receipt = invoke_bridge(root, payload, request_path)
        if command == 'connect' and receipt.get('connected'):
            write_json(connection/'connection.json', receipt)
        request_path.unlink()
        return receipt
    if command not in ('run', 'script', 'readback', 'open', 'cleanup'):
        raise ValueError('Unsupported business command')
    identity = binding(root, run_id, binding_json)
    if command in ('run', 'script'):
        native_project_path(root, run_id)
    runs = root / 'solidworks-runs'
    directory = runs / run_id
    is_script = command == 'script'
    source_bytes = None
    if command in ('run', 'script'):
        source = relative(root, script_path if is_script else spec_path)
        if source.stat().st_size > 1024*1024 or source.suffix.lower() != ('.cs' if is_script else '.json'):
            raise ValueError('Use a workspace-relative C# method-body or JSON file no larger than 1 MiB')
        if is_script:
            source_bytes = source.read_bytes()
            source_bytes.decode('utf-8-sig')
            if not source_bytes.strip():
                raise ValueError('A nonempty C# Build method body is required')
            normalized = dict(path=source.relative_to(root).as_posix(), sha256=hashlib.sha256(source_bytes).hexdigest(), snapshot='source-snapshot.cs')
        else:
            normalized = validate_spec(json.loads(source.read_text(encoding='utf-8-sig')))
        if directory.exists():
            local(directory)
            original = json.loads((directory/'request.json').read_text(encoding='utf-8'))
            if original['binding'] != identity or original.get('operation', 'run') != command or original.get('script' if is_script else 'spec') != normalized:
                raise ValueError('Run ID is already bound to a different owner, operation or source snapshot')
            if (directory/'result.json').exists():
                cached = json.loads((directory/'result.json').read_text(encoding='utf-8'))
                if is_script:
                    verify_general_result(cached, directory, normalized['sha256'], True, json.dumps(identity,ensure_ascii=True,separators=(',', ':')))
                else:
                    project = local(directory/('result-'+run_id+'.sldprt'))
                    if hashlib.sha256(project.read_bytes()).hexdigest() != cached.get('project_sha256'):
                        raise ValueError('The saved project has changed; keep the original run and use readback to inspect it')
                return {**cached, 'cached_receipt': True}
            if (directory/('failure-'+command+'.json')).exists():
                return json.loads((directory/('failure-'+command+'.json')).read_text(encoding='utf-8'))
            return dict(ok=False, state='unknown', code='SW_OPERATION_UNKNOWN', run_id=run_id, note='Original native request is retained; inspect/readback this run instead of replaying it.')
        current = bound_connection_snapshot(expected_connection)
        runs.mkdir(exist_ok=True)
        local(runs)
        directory.mkdir()
        original = dict(binding=identity, operation=command, connection_identity=current, created_at=datetime.now(timezone.utc).isoformat())
        original['script' if is_script else 'spec'] = normalized
        if is_script:
            temporary = directory / ('.'+uuid.uuid4().hex+'.tmp')
            temporary.write_bytes(source_bytes)
            temporary.replace(directory/'source-snapshot.cs')
        write_json(directory/'request.json', original)
    else:
        local(directory)
        original = json.loads((directory/'request.json').read_text(encoding='utf-8'))
        if original['binding'] != identity:
            raise ValueError('Only the original workspace/account/session may inspect this result')
        is_script = original.get('operation', 'run') == 'script'
        normalized = original['script' if is_script else 'spec']
        current = bound_connection_snapshot(expected_connection)
    payload = dict(operation=command, directory=str(directory), workspace=str(root), run_id=run_id,
                   binding_json=json.dumps(identity, ensure_ascii=True, separators=(',', ':')),
                   connection_identity=current, business_kind='script' if is_script else 'run')
    if is_script:
        snapshot = local(directory/'source-snapshot.cs')
        if hashlib.sha256(snapshot.read_bytes()).hexdigest() != normalized['sha256']:
            raise ValueError('The original accepted C# source snapshot changed; it cannot be replayed')
        payload.update(source_snapshot_path=str(snapshot), source_sha256=normalized['sha256'])
    else:
        payload['spec'] = normalized
    if artifact and command != 'open':
        raise ValueError('An artifact selector is only accepted for opening a recorded native result')
    if command == 'open':
        proof = directory/'result.json'
        if not proof.is_file():
            proof = local(directory/'readback.json')
        saved = json.loads(proof.read_text(encoding='utf-8'))
        if saved.get('state') != 'completed':
            raise ValueError('No positively verified saved result or reconciled readback authorizes this native document')
        payload['requested_artifact'] = authorized_artifact(root, directory, saved, artifact)
        if not is_script and payload['requested_artifact'] != str(directory/('result-'+run_id+'.sldprt')):
            raise ValueError('The compatible JSON run only owns its recorded SLDPRT project')
    try:
        receipt = invoke_bridge(root, payload, directory/('native-'+command+'.json'))
        for key, value in current.items():
            if receipt.get(key) != value:
                raise NativeOutcomeUnknown('The native operation did not confirm the original host/process/window identity')
        receipt.update(run_id=run_id, output_directory=str(directory), software='SOLIDWORKS')
        if command in ('run', 'script', 'readback'):
            if is_script:
                verify_general_result(receipt, directory, normalized['sha256'], command == 'script', payload['binding_json'])
            else:
                spec = normalized
                project_path = directory/('result-'+run_id+'.sldprt')
                if receipt.get('connected') is not True or receipt.get('visible') is not True or Path(receipt.get('project','')).resolve() != project_path.resolve() or receipt.get('document_dirty') is not False:
                    raise RuntimeError('Native application, saved project identity or clean document state was not confirmed')
                if command=='run' and (receipt.get('reopened') is not True or receipt.get('save_errors') != 0):
                    raise RuntimeError('The native project was not positively saved and reopened from disk')
                if command=='run':
                    preview = local(directory/'preview.png')
                    if preview.stat().st_size <= 0 or receipt.get('preview') != str(preview):
                        raise RuntimeError('The actual native preview was not confirmed')
                    if spec['export_step'] and (receipt.get('step_errors') != 0 or local(directory/'result.step').stat().st_size <= 0):
                        raise RuntimeError('The requested STEP export was not confirmed')
                expected = theoretical_volume(spec)
                measured = receipt.get('volume_m3')
                if not isinstance(measured,(int,float)) or not math.isfinite(measured) or measured <= 0:
                    raise RuntimeError('No positive native solid-body volume was returned')
                receipt.update(expected_volume_m3=expected, relative_volume_error=abs(measured-expected)/expected)
                if receipt['relative_volume_error'] > 1e-6 or receipt.get('body_count') != 1:
                    raise RuntimeError('Native body volume does not match the requested parametric part')
                project = local(directory/('result-'+run_id+'.sldprt'))
                if project.stat().st_size <= 0:
                    raise RuntimeError('The native SLDPRT project is missing')
                receipt['project_sha256'] = hashlib.sha256(project.read_bytes()).hexdigest()
            receipt['state'] = 'completed'
        if command == 'open':
            opened = receipt.get('opened_project', receipt.get('project'))
            if receipt.get('opened') is not True or not opened or Path(opened).resolve() != Path(payload['requested_artifact']).resolve():
                raise RuntimeError('The requested manifest native document was not confirmed open')
            receipt['opened_project'] = opened
        write_json(directory/('result.json' if command in ('run','script') else command+'.json'),receipt)
        return receipt
    except Exception as error:
        write_json(directory/('failure-'+command+'.json'),dict(ok=False, state='unknown' if isinstance(error,NativeOutcomeUnknown) else 'failed', code=getattr(error,'code','SW_NATIVE_FAILED'), run_id=run_id, error=str(error), original_request_preserved=True))
        raise
