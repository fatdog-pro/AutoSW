"""Offline startup/auth proofs; no Windows libraries, processes or CAD calls."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import uuid

spec = importlib.util.spec_from_file_location('autosw_transport_policy',
    Path(__file__).resolve().parents[1]/'bridge'/'host_transport.py')
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)


class TransportPolicyTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='AutoSW-transport-policy-')
        self.addCleanup(temporary.cleanup)
        self.home = Path(temporary.name)
        self.host_id = str(uuid.uuid4())
        self.snapshot = dict(files={}, sha256='a'*64)
        self.intent = dict(schema_version=1, connect_id=str(uuid.uuid4()),
            source_sha256=self.snapshot['sha256'],
            binding=dict(account_id='test',session_id='test',workspace=str(self.home)))
        self.state = dict(host_id=self.host_id,host_pid=123,host_process_start_ticks='123456',
            source_sha256=self.snapshot['sha256'],connected=False,status='starting',busy=True,
            native_operation=None)
        # Any accidental access to Windows APIs fails this test immediately.
        guard = patch.object(transport,'windows_libraries',side_effect=AssertionError('No Windows/CAD calls'))
        guard.start(); self.addCleanup(guard.stop)

    def write_state(self, value):
        (self.home/'state.json').write_text(json.dumps(value),encoding='utf-8')

    def proofs(self):
        transport.connect_proof_write(self.home,self.intent,'intent.json',self.intent)
        startup = self.home/('startup-'+self.host_id+'.json')
        startup.write_text(json.dumps(dict(host_id=self.host_id,host_home=str(self.home),
            connect_intent=self.intent,windows_sid='test-sid',windows_session=7,
            source_snapshot=self.snapshot)),encoding='utf-8')
        transport.select_connect_host(self.home,self.intent,self.state,startup)

    def test_repeated_start_does_not_rotate_live_owner_auth(self):
        transport.ensure_auth_key(self.home)
        original = (self.home/'auth.key').read_bytes()
        for _ in range(3):
            transport.ensure_auth_key(self.home)
        self.assertEqual((self.home/'auth.key').read_bytes(),original)
        self.assertEqual(len(original),64)

    def test_incomplete_auth_is_blocked_without_replacement(self):
        (self.home/'auth.key').write_bytes(b'')
        with self.assertRaises(transport.HostError):
            transport.ensure_auth_key(self.home)
        self.assertEqual((self.home/'auth.key').read_bytes(),b'')

    def test_unknown_start_keeps_launch_evidence(self):
        failed = dict(self.state,status='unknown',busy=True,initialization_failed=True,
            execution_not_started=False,cad_execution_not_started=True,
            native_launch_may_have_occurred=True,native_launch_state='launched',
            pid=456,process_start_ticks='999')
        error = transport.startup_error(failed)
        self.assertTrue(error.unknown)
        self.assertFalse(error.execution_not_started)
        self.assertEqual(error.native_details['pid'],456)
        self.assertTrue(error.native_details['cad_execution_not_started'])

    def test_terminal_unknown_fallback_retains_exact_original(self):
        self.write_state(self.state)
        failed = dict(self.state,status='unknown',busy=True,initialization_failed=True,
            execution_not_started=False,cad_execution_not_started=True,
            native_launch_may_have_occurred=True,pid=456,process_start_ticks='999')
        (self.home/('startup-'+self.host_id+'-failure.json')).write_text(json.dumps(failed))
        self.assertEqual(transport.read_state(self.home),failed)

    def test_other_birth_terminal_cannot_replace_state(self):
        self.write_state(self.state)
        failed = dict(self.state,host_process_start_ticks='000',status='failed',busy=False,
            initialization_failed=True,execution_not_started=True)
        (self.home/('startup-'+self.host_id+'-failure.json')).write_text(json.dumps(failed))
        self.assertEqual(transport.read_state(self.home),self.state)

    def test_nonobject_terminal_proof_cannot_crash_or_replace_canonical_state(self):
        self.write_state(self.state)
        terminal = self.home/('startup-'+self.host_id+'-failure.json')
        for value in ([],None,'bad-proof',123):
            terminal.write_text(json.dumps(value))
            self.assertEqual(transport.read_state(self.home),self.state)

    def test_lost_connect_recovers_known_failure_without_new_host(self):
        self.proofs()
        failed = dict(self.state,status='failed',busy=False,initialization_failed=True,
            execution_not_started=True,cad_execution_not_started=True,
            native_launch_may_have_occurred=False,native_launch_state='not_requested')
        self.write_state(failed)
        with self.assertRaises(transport.HostError) as caught:
            transport.recover_connect_identity(self.home,self.intent,self.snapshot,'test-sid',7)
        self.assertFalse(caught.exception.unknown)
        self.assertTrue(caught.exception.execution_not_started)
        self.assertFalse(caught.exception.native_details['native_launch_may_have_occurred'])

    def test_lost_postlaunch_failure_stays_original_unknown(self):
        self.proofs()
        failed = dict(self.state,status='unknown',busy=True,initialization_failed=True,
            execution_not_started=False,cad_execution_not_started=True,
            native_launch_may_have_occurred=True,native_launch_state='launched',
            pid=456,process_start_ticks='999')
        self.write_state(failed)
        with self.assertRaises(transport.HostError) as caught:
            transport.recover_connect_identity(self.home,self.intent,self.snapshot,'test-sid',7)
        self.assertTrue(caught.exception.unknown)
        self.assertEqual(caught.exception.native_details['pid'],456)


if __name__ == '__main__':
    unittest.main()
