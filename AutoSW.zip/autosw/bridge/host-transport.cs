using System;
using System.IO;
using System.IO.Pipes;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Fixed local transport only. CAD calls remain on the PowerShell host's STA.
// Idle asynchronous pipe waits pump the apartment instead of destroying and
// recreating the application's COM reference for each model request.
public sealed class YanLabsSWPipe : IDisposable {
    private readonly NamedPipeServerStream pipe;
    public YanLabsSWPipe(string name,string sid) {
        PipeSecurity acl=new PipeSecurity();
        acl.SetAccessRuleProtection(true,false);
        acl.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(sid),PipeAccessRights.FullControl,AccessControlType.Allow));
        acl.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),PipeAccessRights.FullControl,AccessControlType.Allow));
        pipe=new NamedPipeServerStream(name,PipeDirection.InOut,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous,8192,8192,acl);
    }
    private static void Await(Task task,int timeoutMs=0) {
        System.Diagnostics.Stopwatch clock=System.Diagnostics.Stopwatch.StartNew();
        while(!task.IsCompleted) {
            if(timeoutMs>0 && clock.ElapsedMilliseconds>=timeoutMs) throw new TimeoutException("The local transport frame did not complete");
            Application.DoEvents(); System.Threading.Thread.Sleep(20);
        }
        task.GetAwaiter().GetResult();
    }
    public string Receive(int connectionTimeoutMs=0) {
        Await(pipe.WaitForConnectionAsync(),connectionTimeoutMs);
        using(MemoryStream bytes=new MemoryStream()) {
            byte[] buffer=new byte[8192];
            while(true) {
                Task<int> read=pipe.ReadAsync(buffer,0,buffer.Length);Await(read,30000);int count=read.Result;
                if(count==0) throw new EndOfStreamException("The local request ended before its complete frame");
                if(bytes.Length+count>2*1024*1024) throw new InvalidDataException("The local request exceeded its bound");
                for(int index=0;index<count;index++) {
                    if(buffer[index]==10) {
                        if(index!=count-1) throw new InvalidDataException("Only one request frame is accepted per connection");
                        return Encoding.UTF8.GetString(bytes.ToArray());
                    }
                    bytes.WriteByte(buffer[index]);
                }
            }
        }
    }
    public void Send(string value) {
        byte[] bytes=new UTF8Encoding(false,true).GetBytes(value+"\n");
        if(bytes.Length>4*1024*1024) throw new InvalidDataException("The native receipt exceeded its bound");
        Await(pipe.WriteAsync(bytes,0,bytes.Length),30000);Await(pipe.FlushAsync(),30000);
    }
    public void Dispose() { pipe.Dispose(); }
}
