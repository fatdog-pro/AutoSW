"""Portable AutoSW execution boundary; standard library, fixed native bridge."""
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PureWindowsPath
import re
import stat
import subprocess
import sys
import threading
import uuid

CORE_FILES = ('cli.py', 'core.py', 'host_transport.py', 'native-com.ps1',
              'host-transport.cs', 'business-native.cs', 'general-api.cs')
IDENTITY = ('host_id', 'host_pid', 'host_process_start_ticks', 'pid', 'process_start_ticks', 'hwnd')
PRIVATE = set(IDENTITY) | {'binding','binding_json','account_id','session_id','connection_identity',
    'expected_identity','windows_sid','windows_session','auth_key','auth','pipe_name','private_home'}
INPUT_EXTENSIONS = {'.sldprt','.sldasm','.slddrw','.step','.stp','.iges','.igs','.x_t','.x_b',
    '.stl','.dxf','.dwg','.pdf','.png','.jpg','.jpeg','.webp','.bmp'}
HEX = re.compile(r'^[0-9a-f]{64}$')
KEY = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,95}$')
THREAD_LOCK = threading.RLock()


class AutoSWError(RuntimeError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def fail(code, message):
    raise AutoSWError(code, message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def plain_path(path):
    path = Path(os.path.abspath(path))
    for item in (path, *path.parents):
        if item.exists() or item.is_symlink():
            info = item.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
                fail('AUTOSW_LINK_REJECTED', 'Symlinks, junctions and reparse points are not accepted')
    return path


def relative_path(root, name, exists=True):
    if not isinstance(name,str) or not name or len(name)>500 or '\\' in name:
        fail('AUTOSW_SCOPE', 'Use a bounded workspace-relative path with forward slashes')
    parts = name.split('/')
    devices = {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}
    if PureWindowsPath(name).is_absolute() or Path(name).is_absolute() or any(
            not p or p in ('.','..') or p.rstrip(' .')!=p or ':' in p or
            re.search(r'[\x00-\x1f<>"|?*]',p) or p.split('.')[0].upper() in devices for p in parts):
        fail('AUTOSW_SCOPE', 'Unsafe relative path')
    path = plain_path(root.joinpath(*parts))
    if root not in path.parents:
        fail('AUTOSW_SCOPE', 'Path is outside the fixed workspace')
    if exists and not path.is_file():
        fail('AUTOSW_FILE_MISSING', 'The workspace file does not exist')
    if path.exists() and (not path.is_file() or path.stat().st_nlink!=1):
        fail('AUTOSW_SCOPE', 'Only regular files with one link are accepted')
    return path


def atomic_json(path, value):
    path = plain_path(path)
    if path.exists() and path.stat().st_nlink!=1:
        fail('AUTOSW_SCOPE', 'Linked state files are not accepted')
    temporary = path.with_name('.'+uuid.uuid4().hex+'.tmp')
    with temporary.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=True,separators=(',',':'))
        stream.flush(); os.fsync(stream.fileno())
    temporary.replace(path)


def public(value):
    if isinstance(value,dict):
        return {key:public(item) for key,item in value.items() if key not in PRIVATE}
    if isinstance(value,list):
        return [public(item) for item in value]
    return value


def connection(receipt):
    if not isinstance(receipt,dict) or receipt.get('connected') is not True:
        fail('AUTOSW_CONNECTION_INVALID', 'The explicit connection was not confirmed')
    result = {key:receipt.get(key) for key in IDENTITY}
    try:
        if str(uuid.UUID(result['host_id'],version=4))!=result['host_id']:
            raise ValueError()
        if any(isinstance(result[k],bool) or not isinstance(result[k],int) or not 0<result[k]<2**53
               for k in ('host_pid','pid','hwnd')):
            raise ValueError()
        if any(not isinstance(result[k],str) or not re.fullmatch(r'[0-9]{1,22}',result[k])
               for k in ('host_process_start_ticks','process_start_ticks')):
            raise ValueError()
    except (TypeError,ValueError,AttributeError):
        fail('AUTOSW_CONNECTION_INVALID', 'The native six-field identity was not confirmed')
    return result


def is_unknown(receipt):
    operation = receipt.get('native_operation') or {}
    return receipt.get('state')=='unknown' or receipt.get('status')=='unknown' or \
        receipt.get('busy') is True or receipt.get('code') in ('SW_OPERATION_UNKNOWN','SW_HOST_BUSY') or \
        isinstance(operation,dict) and operation.get('state',operation.get('status')) in ('unknown','running','pending')


class Runtime:
    def __init__(self, workspace, package=None, *, _runner=None, _private=None):
        self.workspace = plain_path(workspace)
        if not self.workspace.is_dir():
            fail('AUTOSW_WORKSPACE', 'Explicitly select an existing project workspace')
        self.package = plain_path(package or Path(__file__).resolve().parents[1])
        self.bridge = self.package/'bridge'
        self._runner, self._private, self.home = _runner, _private, None

    def verify(self):
        try:
            manifest = json.loads(plain_path(self.package/'bridge-manifest.json').read_text(encoding='utf-8'))
            files = manifest['files']
        except (OSError,ValueError,KeyError,TypeError):
            fail('AUTOSW_SOURCE_FREEZE', 'Frozen bridge manifest is missing or invalid')
        if not isinstance(files,dict) or set(files)!=set(CORE_FILES) or any(
                not isinstance(v,str) or not HEX.fullmatch(v) for v in files.values()):
            fail('AUTOSW_SOURCE_FREEZE', 'Manifest must freeze exactly seven native bridge sources')
        for name,expected in files.items():
            file = plain_path(self.bridge/name)
            if not file.is_file() or file.stat().st_nlink!=1 or sha(file.read_bytes())!=expected:
                fail('AUTOSW_SOURCE_FREEZE', 'Frozen native bridge source missing or changed: '+name)
        aggregate = sha(json.dumps(files,sort_keys=True,separators=(',',':')).encode())
        if manifest.get('sha256')!=aggregate:
            fail('AUTOSW_SOURCE_FREEZE', 'Bridge aggregate hash does not match')
        return dict(ok=True,bridge_sha256=aggregate,source_count=len(files),native_called=False)

    def _home(self):
        if self.home is not None:
            return self.home
        if self._private is not None:  # Offline dependency injection; no CLI or environment override.
            home,owner = self._private
            home = plain_path(home); home.mkdir(parents=True,exist_ok=True)
        else:
            self.verify()
            spec = importlib.util.spec_from_file_location('_autosw_fixed_transport',self.bridge/'host_transport.py')
            transport = importlib.util.module_from_spec(spec); spec.loader.exec_module(transport)
            sid,_ = transport.windows_identity()  # Token identity only; no CAD or UI call.
            base = os.environ.get('LOCALAPPDATA')
            if not base or not Path(base).is_absolute():
                fail('AUTOSW_PRIVATE_STATE', 'Current-user local application-data directory unavailable')
            owner = 'local-'+sha(sid.encode())[:32]
            home = plain_path(Path(base)/'AutoSW'/sha((owner+str(self.workspace).casefold()).encode()))
            transport.secure_directory(home,sid)
        self.home,self.owner = home,owner
        return home

    @contextmanager
    def locked(self):
        with THREAD_LOCK:
            file = plain_path(self._home()/'workspace.lock')
            if file.exists() and file.stat().st_nlink!=1:
                fail('AUTOSW_SCOPE', 'Linked lock files are not accepted')
            with file.open('a+b') as lock:
                lock.seek(0)
                if lock.read(1)==b'':
                    lock.write(b'0'); lock.flush()
                lock.seek(0)
                try:
                    if os.name=='nt':
                        import msvcrt
                        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
                    else:
                        import fcntl
                        fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                except OSError:
                    fail('AUTOSW_BUSY', 'Another operation owns this workspace; inspect its original run')
                try:
                    yield
                finally:
                    lock.seek(0)
                    if os.name=='nt':
                        msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
                    else:
                        fcntl.flock(lock.fileno(),fcntl.LOCK_UN)

    def _load(self):
        file = plain_path(self._home()/'state.json')
        if not file.exists():
            state = dict(schema_version=1,workspace=str(self.workspace),account_id=self.owner,
                         session_id=str(uuid.uuid4()),connection=None,pending_run=None,runs={},operations={},
                         connect_attempt=None,connect_history=[],pending_operation=None,operation_recoveries=[])
            self._save(state); return state
        if file.stat().st_nlink!=1 or file.stat().st_size>16*1024*1024:
            fail('AUTOSW_PRIVATE_STATE', 'Unsafe or oversized private state')
        state = json.loads(file.read_text(encoding='utf-8'))
        if state.get('schema_version')!=1 or state.get('workspace')!=str(self.workspace) or state.get('account_id')!=self.owner:
            fail('AUTOSW_PRIVATE_STATE', 'Private state belongs to another user or workspace')
        state.setdefault('connect_attempt',None);state.setdefault('connect_history',[])
        state.setdefault('pending_operation',None);state.setdefault('operation_recoveries',[])
        return state

    def _save(self, state):
        state['updated_at'] = timestamp()
        atomic_json(self._home()/'state.json',state)

    def _invoke(self, command, state, run_id=None, _connect_intent=None, **kwargs):
        self.verify()
        args = [sys.executable,'-I','-B',str(self.bridge/'cli.py'),command,'--workspace',str(self.workspace)]
        if _connect_intent is not None:
            if command not in ('connect','status'):
                fail('AUTOSW_CONNECT_INTENT_INVALID','Connect intents are internal to explicit connect and read-only recovery')
            args += ['--connect-intent-json',json.dumps(_connect_intent,separators=(',',':'))]
        if command not in ('connect','catalog') and _connect_intent is None:
            accepted = state['runs'][run_id]['connection'] if run_id else state.get('connection')
            if not accepted:
                fail('AUTOSW_CONNECT_REQUIRED', 'Explicitly connect first; this command cannot start or adopt SOLIDWORKS')
            args += ['--expected-connection-json',json.dumps(accepted,separators=(',',':'))]
        if run_id:
            binding = {key:state[key] for key in ('account_id','session_id','workspace')}
            binding['run_id'] = run_id
            args += ['--run-id',run_id,'--binding-json',json.dumps(binding,separators=(',',':'))]
        for name,value in kwargs.items():
            if value is not None:
                args += ['--'+name.replace('_','-'),value]
        if self._runner is not None:
            exit_code,receipt = self._runner(args)
        else:
            if os.name!='nt':
                fail('AUTOSW_WINDOWS_REQUIRED', 'Native execution requires Windows and activated SOLIDWORKS')
            try:
                process = subprocess.run(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,shell=False,check=False,creationflags=0x08000000)
            except OSError:
                return dict(ok=False,state='unknown',code='AUTOSW_EXECUTOR_UNCONFIRMED',run_id=run_id,
                            original_request_preserved=True,process_exit_code=None)
            exit_code = process.returncode
            try:
                if len(process.stdout)>16*1024*1024:
                    raise ValueError()
                receipt = json.loads(process.stdout.decode('utf-8-sig'))
            except (ValueError,UnicodeError):
                receipt = dict(ok=False,state='unknown',code='AUTOSW_INVALID_NATIVE_RECEIPT',
                               run_id=run_id,original_request_preserved=True)
        if not isinstance(receipt,dict):
            receipt = dict(ok=False,state='unknown',code='AUTOSW_INVALID_NATIVE_RECEIPT',run_id=run_id)
        receipt = dict(receipt,process_exit_code=exit_code)
        if receipt.get('ok') is True and (exit_code!=0 or run_id and not all(k in receipt for k in IDENTITY)):
            return dict(ok=False,state='unknown',code='AUTOSW_INCOMPLETE_NATIVE_PROOF',run_id=run_id,
                        process_exit_code=exit_code,original_request_preserved=True)
        if run_id and receipt.get('run_id')!=run_id:
            return dict(ok=False,state='unknown',code='AUTOSW_RUN_MISMATCH',run_id=run_id,
                        process_exit_code=exit_code,original_request_preserved=True)
        if command!='connect' and _connect_intent is None and all(k in receipt for k in IDENTITY):
            expected = state['runs'][run_id]['connection'] if run_id else state.get('connection')
            if {k:receipt[k] for k in IDENTITY}!=expected:
                return dict(ok=False,state='unknown',code='AUTOSW_CONNECTION_CHANGED',run_id=run_id,
                            process_exit_code=exit_code,original_request_preserved=True)
        return receipt

    def catalog(self):
        return dict(self.verify(),name='autosw',title='AutoSW',native_execution='explicit connect only',
            source='C# Build method body through the frozen owned-document context',units='Official API metres/radians',
            capabilities=['installed official API signatures','owned CAD source execution','native save/reopen/readback',
                          'input-file identity inspection','original-run recovery','normal owned-document cleanup'],
            limits=['No arbitrary shell, filesystem or networking tools','No UI automation or desktop OCR',
                    'No blanket claim about every API feature, mate solver or Simulation licence'])

    def init(self):
        with self.locked():
            state = self._load()
            return dict(ok=True,workspace=str(self.workspace),session_persistent=True,
                        connected=bool(state['connection']),pending_run=state['pending_run'],
                        pending_connect=self._pending_connect(state))

    def _pending_connect(self,state):
        attempt=state.get('connect_attempt')
        return attempt['intent']['connect_id'] if attempt and attempt.get('state') in ('accepted','unknown') else None

    def _require_resolved_connect(self,state):
        if self._pending_connect(state):
            fail('AUTOSW_CONNECT_PENDING','The original explicit connect is unconfirmed; use status, never another connect or CAD command')

    def _record_connect(self,state,receipt,recovering=False):
        attempt=state['connect_attempt'];intent=attempt['intent']
        attempt['receipt_history'].append(dict(observed_at=timestamp(),recovering=recovering,receipt=receipt))
        expected_source=self.verify()['bridge_sha256']
        confirmed=receipt.get('connect_id')==intent['connect_id'] and intent['source_sha256']==expected_source and \
            receipt.get('source_sha256')==intent['source_sha256'] and receipt.get('ok') is True and \
            receipt.get('connected') is True and not is_unknown(receipt)
        if confirmed:
            try:accepted=connection(receipt)
            except AutoSWError:confirmed=False
        if confirmed:
            state['connection']=accepted;attempt['state']='completed'
        elif receipt.get('connect_id')==intent['connect_id'] and receipt.get('ok') is False and \
                receipt.get('state')=='failed' and not is_unknown(receipt) and (not recovering or
                    receipt.get('source_sha256')==intent['source_sha256'] and
                    receipt.get('initialization_failed') is True and
                    receipt.get('cad_execution_not_started') is True and
                    receipt.get('native_launch_may_have_occurred') is False):
            attempt['state']='failed'
        else:
            attempt['state']='unknown'
            receipt=dict(receipt,ok=False,state='unknown',connect_id=intent['connect_id'],
                         original_request_preserved=True,connect_recovery_required=True)
        attempt['last_receipt']=receipt;self._save(state)
        return receipt

    def connect(self):
        with self.locked():
            state = self._load()
            if state['pending_run']:
                fail('AUTOSW_ORIGINAL_RUN_PENDING', 'Resolve the original run before accepting a new connection')
            self._require_resolved_connect(state)
            intent=dict(schema_version=1,connect_id=str(uuid.uuid4()),source_sha256=self.verify()['bridge_sha256'],
                        binding={key:state[key] for key in ('workspace','account_id','session_id')})
            if state.get('connect_attempt'):state['connect_history'].append(state['connect_attempt'])
            state['connect_attempt']=dict(intent=intent,state='accepted',created_at=timestamp(),receipt_history=[])
            self._save(state)
            receipt=self._invoke('connect',state,_connect_intent=intent)
            receipt=self._record_connect(state,receipt)
            return public(receipt)

    def status(self):
        with self.locked():
            state = self._load()
            history = [dict(run_id=key,state=run['state'],source=run['source'],
                source_sha256=run['source_sha256'],created_at=run['created_at']) for key,run in state['runs'].items()]
            if self._pending_connect(state):
                receipt=self._invoke('status',state,_connect_intent=state['connect_attempt']['intent'])
                receipt=self._record_connect(state,receipt,recovering=True)
                return dict(public(receipt),pending_connect=self._pending_connect(state),pending_run=state['pending_run'],runs=history)
            if not state['connection']:
                return dict(ok=True,connected=False,status='not_connected',native_called=False,pending_run=state['pending_run'],runs=history)
            receipt = self._invoke('status',state)
            recovered=self._recover_known_result_operation(state,receipt)
            pending_result=self._pending_result_operation(state)
            return dict(public(receipt),pending_run=state['pending_run'],runs=history,
                        original_run_requires_readback=bool(state['pending_run']) and pending_result is None,
                        pending_result_operation=pending_result,recovered_operation=recovered)

    def api(self, type_name, member=None):
        if any(v is not None and (not isinstance(v,str) or not v or len(v)>200 or re.search(r'[\x00-\x1f]',v))
               for v in (type_name,member)):
            fail('AUTOSW_API_NAME', 'Use bounded installed API type/member names')
        with self.locked():
            state = self._load()
            self._require_resolved_connect(state)
            if state['pending_run']:
                fail('AUTOSW_ORIGINAL_RUN_PENDING', 'Only status/readback may inspect the outstanding native run')
            return public(self._invoke('api',state,type=type_name,member=member))

    def write_script(self, path, source, expected_sha256=None):
        if not isinstance(source,str) or not source.strip() or len(source.encode('utf-8'))>1024*1024:
            fail('AUTOSW_SOURCE', 'Supply a nonempty UTF-8 C# Build method body no larger than 1 MiB')
        if not isinstance(path,str) or not path.startswith('sources/') or not path.endswith('.cs'):
            fail('AUTOSW_SCOPE', 'Source writes are restricted to sources/*.cs')
        with self.locked():
            self._load()
            file = relative_path(self.workspace,path,False)
            if file.exists() and (not isinstance(expected_sha256,str) or sha(file.read_bytes())!=expected_sha256):
                fail('AUTOSW_SOURCE_CHANGED', 'An existing source requires its exact prior SHA256 before replacement')
            if not file.exists() and expected_sha256 is not None:
                fail('AUTOSW_SOURCE_CHANGED', 'The expected existing source is missing')
            file.parent.mkdir(parents=True,exist_ok=True); plain_path(file.parent)
            temporary = file.with_name('.'+uuid.uuid4().hex+'.tmp')
            temporary.write_text(source,encoding='utf-8',newline='\n'); temporary.replace(file)
            return dict(ok=True,path=path,sha256=sha(file.read_bytes()),bytes=file.stat().st_size,executed=False)

    def run_script(self, path, source_sha256, operation_key):
        if not isinstance(operation_key,str) or not KEY.fullmatch(operation_key):
            fail('AUTOSW_OPERATION_KEY', 'Provide a stable intent key: 1-96 letters, digits, dot, dash or underscore')
        if not isinstance(source_sha256,str) or not HEX.fullmatch(source_sha256):
            fail('AUTOSW_SOURCE', 'The exact accepted source SHA256 is required')
        with self.locked():
            state = self._load(); file = relative_path(self.workspace,path)
            self._require_resolved_connect(state)
            if not path.startswith('sources/') or file.suffix.lower()!='.cs' or file.stat().st_size>1024*1024:
                fail('AUTOSW_SCOPE', 'Only an accepted sources/*.cs method body can run')
            if sha(file.read_bytes())!=source_sha256:
                fail('AUTOSW_SOURCE_CHANGED', 'The source changed after acceptance')
            previous = state['operations'].get(operation_key)
            if previous:
                run = state['runs'][previous]
                if run['source_sha256']!=source_sha256 or run['source']!=path:
                    fail('AUTOSW_INTENT_CONFLICT', 'This intent key belongs to a different frozen source')
                return dict(public(run.get('receipt') or dict(ok=False,state='unknown')),run_id=previous,
                            cached_receipt=True,task_replayed=False)
            if state['pending_run']:
                fail('AUTOSW_ORIGINAL_RUN_PENDING', 'Inspect the original pending run; do not create a replacement intent')
            if not state['connection']:
                fail('AUTOSW_CONNECT_REQUIRED', 'Explicitly connect first; sending a task cannot launch SOLIDWORKS')
            self.verify()
            run_id = str(uuid.uuid4())
            # Separate immutable accepted input from the editable source. The public
            # source writer cannot address this directory or any original run files.
            accepted = plain_path(self.workspace/'autosw-accepted')
            accepted.mkdir(exist_ok=True)
            frozen = accepted/(run_id+'.cs')
            source_bytes = file.read_bytes()
            if sha(source_bytes)!=source_sha256:
                fail('AUTOSW_SOURCE_CHANGED', 'The source changed while accepting this request')
            with frozen.open('xb') as stream:
                stream.write(source_bytes); stream.flush(); os.fsync(stream.fileno())
            run = dict(run_id=run_id,source=path,source_sha256=source_sha256,connection=state['connection'],
                       accepted_source=frozen.relative_to(self.workspace).as_posix(),
                       created_at=timestamp(),state='unknown',phase='accepted_before_dispatch')
            state['runs'][run_id] = run; state['operations'][operation_key] = run_id
            state['pending_run'] = run_id; self._save(state)
            receipt = self._invoke('script',state,run_id,script=run['accepted_source'])
            self._record(state,run_id,receipt)
            return public(receipt)

    def _record(self, state, run_id, receipt):
        run = state['runs'][run_id]
        run['receipt'] = receipt; run['phase'] = 'receipt_observed'
        run['state'] = 'unknown' if is_unknown(receipt) else receipt.get('state','unknown')
        confirmed = receipt.get('ok') is True and receipt.get('state')=='completed' and not is_unknown(receipt)
        known_failed = receipt.get('ok') is False and receipt.get('state')=='failed' and not is_unknown(receipt)
        state['pending_run'] = None if confirmed or known_failed else run_id
        self._save(state)

    def _run(self, state, run_id):
        try:
            valid = isinstance(run_id,str) and str(uuid.UUID(run_id,version=4))==run_id
        except (ValueError,AttributeError):
            valid = False
        if not valid or run_id not in state['runs']:
            fail('AUTOSW_RUN_SCOPE', 'Only an original run registered to this user, session and workspace is accepted')
        return state['runs'][run_id]

    def readback(self, run_id):
        with self.locked():
            state = self._load(); self._run(state,run_id)
            self._require_resolved_connect(state)
            if state['pending_run'] and state['pending_run']!=run_id:
                fail('AUTOSW_ORIGINAL_RUN_PENDING', 'Read back the outstanding original run first')
            run=state['runs'][run_id]
            if state['pending_run']==run_id and (state.get('pending_operation') or
                    run.get('state') in ('completed','failed') and any(run.get(name+'_receipt') for name in ('open','cleanup'))):
                fail('AUTOSW_OPERATION_PENDING','Use status to reconcile the original open/cleanup operation; CAD readback cannot clear a different operation')
            receipt = self._invoke('readback',state,run_id); self._record(state,run_id,receipt)
            return public(receipt)

    def open(self, run_id, artifact=None):
        return self._result_operation('open',run_id,artifact)

    def cleanup(self, run_id):
        return self._result_operation('cleanup',run_id)

    def _result_operation(self, command, run_id, artifact=None):
        with self.locked():
            state = self._load(); run = self._run(state,run_id)
            self._require_resolved_connect(state)
            allowed = run['state']=='completed' or command=='cleanup' and run['state']=='failed'
            if state['pending_run'] or not allowed:
                fail('AUTOSW_ORIGINAL_RUN_PENDING', 'Open needs completed proof; cleanup also permits a known failed run, never unknown work')
            if artifact is not None:
                relative_path(self.workspace,artifact)
                if not artifact.startswith('solidworks-runs/'+run_id+'/'):
                    fail('AUTOSW_RUN_SCOPE', 'Open only this run’s recorded native artifact')
            operation=dict(operation_id=str(uuid.uuid4()),command=command,run_id=run_id,
                connection=dict(run['connection']),bridge_sha256=self.verify()['bridge_sha256'],
                accepted_at=timestamp(),state='accepted',receipt_provenance='fixed_cli_original_bound_arguments')
            state['pending_run'] = run_id;state['pending_operation']=operation; self._save(state)
            receipt = self._invoke(command,state,run_id,artifact=artifact)
            run[command+'_receipt'] = receipt
            operation['receipt']=receipt
            terminal=self._result_operation_terminal(receipt,run_id,run['connection'])
            operation['state']='completed' if terminal and receipt.get('ok') is True else 'failed' if terminal else 'unknown'
            run.setdefault('result_operations',[]).append(operation)
            if terminal:
                state['pending_run'] = None;state['pending_operation']=None
            self._save(state)
            return public(receipt)

    def _result_operation_terminal(self,receipt,run_id,expected):
        if not isinstance(receipt,dict) or receipt.get('run_id')!=run_id or is_unknown(receipt):return False
        if isinstance(receipt.get('process_exit_code'),bool):return False
        # Known CLI errors may omit identity fields. The immutable accepted
        # selector/source are recorded before dispatch; contradictory fields fail.
        supplied=[key for key in IDENTITY if key in receipt]
        if supplied and (len(supplied)!=len(IDENTITY) or {key:receipt[key] for key in IDENTITY}!=expected):return False
        if receipt.get('ok') is True:
            return receipt.get('process_exit_code')==0 and len(supplied)==len(IDENTITY)
        return receipt.get('ok') is False and receipt.get('state')=='failed' and \
            not isinstance(receipt.get('process_exit_code'),bool) and receipt.get('process_exit_code')==1

    def _pending_result_operation(self,state):
        run_id=state.get('pending_run');run=state['runs'].get(run_id)
        if not run:return None
        operation=state.get('pending_operation')
        if operation and operation.get('command') in ('open','cleanup'):
            return dict(command=operation['command'],run_id=run_id,state=operation.get('state','unknown'))
        names=[name for name in ('open','cleanup') if run.get(name+'_receipt')]
        if run.get('state') in ('completed','failed') and names:
            return dict(command=names[0] if len(names)==1 else 'open_or_cleanup',run_id=run_id,state='unconfirmed_occupancy')
        return None

    def _recover_known_result_operation(self,state,status):
        """Release a proven failed result operation; never a scientific unknown.

        Legacy private state has pending_run plus a command_receipt. Accept it
        only with original connect/source proof and a fresh exact idle identity.
        No CAD/open/cleanup is reissued, no original outcome or receipt is changed.
        """
        run_id=state.get('pending_run');run=state['runs'].get(run_id)
        if not run or run.get('state') not in ('completed','failed') or state.get('connection')!=run.get('connection'):
            return None
        original=run.get('receipt') or {}
        if original.get('run_id')!=run_id or original.get('state')!=run['state'] or is_unknown(original):
            return None
        expected=run['connection'];snapshot=self.verify()['bridge_sha256']
        if status.get('ok') is not True or status.get('process_exit_code')!=0 or status.get('connected') is not True or \
                status.get('busy') is not False or 'native_operation' not in status or status.get('native_operation') is not None or is_unknown(status) or \
                status.get('source_sha256')!=snapshot or {key:status.get(key) for key in IDENTITY}!=expected:
            return None
        operation=state.get('pending_operation');legacy=operation is None
        if legacy:
            candidates=[(name,run.get(name+'_receipt')) for name in ('open','cleanup') if run.get(name+'_receipt') is not None]
            if len(candidates)!=1:return None
            command,receipt=candidates[0]
            accepted=state.get('connect_attempt') or {};last=accepted.get('last_receipt') or {}
            if accepted.get('state')!='completed' or (accepted.get('intent') or {}).get('source_sha256')!=snapshot or \
                    {key:last.get(key) for key in IDENTITY}!=expected:
                return None
            operation=dict(command=command,run_id=run_id,connection=dict(expected),bridge_sha256=snapshot,
                           receipt=receipt,receipt_provenance='legacy_private_command_receipt_plus_original_connect_proof')
        if operation.get('command') not in ('open','cleanup') or operation.get('run_id')!=run_id or \
                operation.get('connection')!=expected or operation.get('bridge_sha256')!=snapshot:
            return None
        receipt=operation.get('receipt') or {}
        if receipt.get('ok') is not False or not self._result_operation_terminal(receipt,run_id,expected):return None
        evidence=dict(recovered_at=timestamp(),operation=operation,legacy_marker=legacy,
            status_receipt=status,original_run_state=run['state'],operation_outcome='failed',
            action_replayed=False,original_receipt_preserved=True)
        state['operation_recoveries'].append(evidence)
        state['pending_run']=None;state['pending_operation']=None;self._save(state)
        return dict(command=operation['command'],run_id=run_id,outcome='failed',
                    original_run_state=run['state'],action_replayed=False)

    def disconnect(self):
        with self.locked():
            state = self._load()
            self._require_resolved_connect(state)
            if state['pending_run']:
                fail('AUTOSW_ORIGINAL_RUN_PENDING', 'An outstanding native operation cannot be retired or replaced')
            if not state['connection']:
                return dict(ok=True,connected=False,native_called=False)
            receipt = self._invoke('disconnect',state)
            if receipt.get('ok') is True and receipt.get('connected') is False and not is_unknown(receipt):
                state['connection'] = None; self._save(state)
            return public(receipt)

    def input_inspect(self, path):
        file = relative_path(self.workspace,path)
        if not path.startswith('inputs/') or file.suffix.lower() not in INPUT_EXTENSIONS:
            fail('AUTOSW_INPUT_SCOPE', 'Inspect only supported image/drawing/CAD files deliberately placed in inputs/')
        before = file.stat(); digest = hashlib.sha256()
        with file.open('rb') as stream:
            for block in iter(lambda:stream.read(1024*1024),b''):
                digest.update(block)
        after = file.stat()
        if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):
            fail('AUTOSW_INPUT_CHANGED', 'Input changed during inspection')
        return dict(ok=True,path=path,extension=file.suffix.lower(),bytes=after.st_size,sha256=digest.hexdigest(),
            input_modified=False,note='File identity only; not dimension recognition, CAD solve or geometry validation')
