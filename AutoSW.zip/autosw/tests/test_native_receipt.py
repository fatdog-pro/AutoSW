"""Saved-only receipts must never impersonate disk-reopen verification."""
import copy
import hashlib
import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest

bridge=Path(__file__).resolve().parents[1]/'bridge'
sys.path.insert(0,str(bridge))
spec=importlib.util.spec_from_file_location('autosw_native_receipt_core',bridge/'core.py')
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)


class NativeReceiptTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory(prefix='AutoSW-receipt-policy-')
        self.addCleanup(temporary.cleanup);self.directory=Path(temporary.name)
        self.project=self.directory/'example.sldasm';self.project.write_bytes(b'offline synthetic CAD bytes')
        self.preview=self.directory/'preview.png';self.preview.write_bytes(b'offline preview fixture')
        artifact=lambda p:dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
        self.receipt=dict(connected=True,visible=True,document_dirty=False,saved=True,reopened=False,
            source_sha256='a'*64,project=str(self.project),preview=str(self.preview),
            native_documents=[artifact(self.project)],artifacts=[artifact(self.project),artifact(self.preview)],
            reopen_deferred=True,
            reopen_verification=dict(status='deferred',reason='retained_hidden_documents',close_calls=0,
                retained_hidden_count=1,disk_reopen_verified=False,saved_native_bytes_verified=True,
                current_saved_structure_verified=True),
            native_document_lifecycle=dict(all_run_documents_unloaded_before_main_reopen=False,
                closed_owned_paths=[],explicitly_reopened_path=None,reopen_deferred=True))

    def verify(self, receipt=None):
        core.verify_general_result(self.receipt if receipt is None else receipt,self.directory,'a'*64,True)

    def test_saved_verified_result_reports_reopen_deferred_truthfully(self):
        self.verify()
        self.assertFalse(self.receipt['reopened'])
        self.assertFalse(self.receipt['disk_reopen_verified'])
        self.assertEqual(self.receipt['verification_status'],'saved_native_verified_reopen_deferred')

    def test_simple_false_reopen_without_proof_still_rejected(self):
        self.receipt.pop('reopen_verification')
        with self.assertRaises(RuntimeError):self.verify()

    def test_fake_zero_close_or_missing_retained_doc_proof_rejected(self):
        for key,value in (('close_calls',True),('close_calls',1),('retained_hidden_count',False),
                ('retained_hidden_count',0),('saved_native_bytes_verified',False),
                ('disk_reopen_verified',True),('current_saved_structure_verified',False)):
            receipt=copy.deepcopy(self.receipt);receipt['reopen_verification'][key]=value
            with self.subTest(key=key,value=value),self.assertRaises(RuntimeError):self.verify(receipt)

    def test_claimed_close_cannot_be_accepted_as_no_close_deferral(self):
        self.receipt['native_document_lifecycle']['closed_owned_paths']=[str(self.project)]
        with self.assertRaises(RuntimeError):self.verify()

    def test_artifact_tampering_still_rejected_when_reopen_deferred(self):
        self.project.write_bytes(b'changed CAD fixture')
        with self.assertRaises(RuntimeError):self.verify()

    def test_real_reopen_contract_remains_accepted(self):
        self.receipt['reopened']=True;self.receipt.pop('reopen_deferred')
        self.receipt.pop('reopen_verification');self.receipt.pop('native_document_lifecycle')
        self.verify()
        self.assertNotIn('verification_status',self.receipt)
