using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using SolidWorks.Interop.sldworks;

// Fixed, reviewed business operations only. All dimensions supplied here are mm.
public static class YanLabsSWBusiness {
    public static string Stage { get; private set; }
    private static void Step(string value) { Stage=value; }
    private static bool SamePath(string left,string right) {
        return !String.IsNullOrWhiteSpace(left) && !String.IsNullOrWhiteSpace(right) &&
            String.Equals(Path.GetFullPath(left),Path.GetFullPath(right),StringComparison.OrdinalIgnoreCase);
    }
    private static double[] Numbers(object value,int minimum) {
        Array array=value as Array;
        if(array==null || array.Length<minimum) throw new InvalidOperationException("The native numeric array is incomplete");
        double[] result=new double[array.Length];
        for(int index=0;index<array.Length;index++) {
            result[index]=Convert.ToDouble(array.GetValue(index));
            if(Double.IsNaN(result[index]) || Double.IsInfinity(result[index])) throw new InvalidOperationException("The native numeric array is not finite");
        }
        return result;
    }
    private static void Positive(double value,string name) {
        if(Double.IsNaN(value) || Double.IsInfinity(value) || value<0.01 || value>10000) throw new ArgumentException("Invalid bounded dimension: "+name);
    }
    private static bool SameComObject(object left,object right) {
        IntPtr first=IntPtr.Zero,second=IntPtr.Zero;
        try {first=Marshal.GetIUnknownForObject(left);second=Marshal.GetIUnknownForObject(right);return first==second;}
        finally {if(first!=IntPtr.Zero) Marshal.Release(first);if(second!=IntPtr.Zero) Marshal.Release(second);}
    }
    private static IFeature SketchFeature(IModelDoc2 part,ISketch sketch) {
        IFeature feature=(IFeature)part.FirstFeature();int count=0;
        while(feature!=null) {
            if(++count>1024) throw new InvalidOperationException("Sketch-feature traversal exceeded its bound");
            if(feature.GetTypeName2()=="ProfileFeature") {
                object specific=feature.GetSpecificFeature2();
                if(specific!=null && SameComObject(specific,sketch)) return feature;
            }
            feature=(IFeature)feature.GetNextFeature();
        }
        throw new InvalidOperationException("The feature for this newly created sketch could not be identified");
    }
    private static void Validate(string profile,double width,double height,double radius,double depth,double[] holes,double density) {
        Positive(depth,"depth");
        if(profile=="rectangle") { Positive(width,"width");Positive(height,"height"); }
        else if(profile=="circle") Positive(radius,"radius");
        else throw new ArgumentException("Unsupported bounded base profile");
        if(holes==null || holes.Length%3!=0 || holes.Length>192) throw new ArgumentException("Invalid bounded through-hole array");
        if(Double.IsNaN(density) || Double.IsInfinity(density) || density<0.01 || density>100000) throw new ArgumentException("Invalid declared density");
        for(int i=0;i<holes.Length;i+=3) {
            double x=holes[i],y=holes[i+1],r=holes[i+2];Positive(r,"hole radius");
            if(Double.IsNaN(x) || Double.IsInfinity(x) || Double.IsNaN(y) || Double.IsInfinity(y)) throw new ArgumentException("Invalid hole coordinates");
            bool inside=profile=="rectangle" ? Math.Abs(x)+r<width/2 && Math.Abs(y)+r<height/2 : Math.Sqrt(x*x+y*y)+r<radius;
            if(!inside) throw new ArgumentException("Through holes must lie wholly inside the base profile");
            for(int j=0;j<i;j+=3) {double dx=x-holes[j],dy=y-holes[j+1];if(Math.Sqrt(dx*dx+dy*dy)<=r+holes[j+2]) throw new ArgumentException("Through holes must be disjoint");}
        }
    }
    private static IModelDoc2 OpenOwned(ISldWorks app,string project,out bool openedFromDisk,out int warning) {
        Step("open_owned_project");openedFromDisk=false;warning=0;
        IModelDoc2 part=(IModelDoc2)app.GetOpenDocumentByName(project);
        if(part==null) {
            int error=0;
            part=(IModelDoc2)app.OpenDoc6(project,1,1,"",ref error,ref warning);
            if(part==null || error!=0) throw new InvalidOperationException("Native project reopen failed: "+error);
            openedFromDisk=true;
        }
        if(!SamePath(part.GetPathName(),project)) throw new InvalidOperationException("Opened project identity does not match this run");
        return part;
    }
    private static void CloseOwned(ISldWorks app,IModelDoc2 part,string project) {
        Step("close_owned_project");
        if(!SamePath(part.GetPathName(),project)) throw new InvalidOperationException("Document identity mismatch; close refused");
        if(part.GetSaveFlag()) throw new InvalidOperationException("The generated document has unsaved changes; close refused");
        string title=part.GetTitle();
        if(String.IsNullOrWhiteSpace(title)) throw new InvalidOperationException("An empty document title cannot be closed safely");
        int matches=0;Array documents=app.GetDocuments() as Array;
        if(documents!=null) foreach(object raw in documents) {
            IModelDoc2 document=raw as IModelDoc2;
            if(document!=null && String.Equals(document.GetTitle(),title,StringComparison.OrdinalIgnoreCase)) matches++;
        }
        if(matches!=1) throw new InvalidOperationException("Document title is not unique; no document was closed");
        app.CloseDoc(title);
        if(app.GetOpenDocumentByName(project)!=null) throw new InvalidOperationException("Native document closure has not been confirmed");
    }
    private static Dictionary<string,object> ReadPart(IModelDoc2 part,double density) {
        Step("read_native_bodies");
        IPartDoc solid=(IPartDoc)part;
        Array bodies=solid.GetBodies2(0,false) as Array;
        if(bodies==null || bodies.Length!=1 || bodies.GetValue(0)==null) throw new InvalidOperationException("Expected exactly one native solid body");
        IBody2 body=(IBody2)bodies.GetValue(0);
        double[] mass=Numbers(body.GetMassProperties(density),6);
        double[] box=Numbers(body.GetBodyBox(),6);
        if(box.Length!=6) throw new InvalidOperationException("Native bounding-box readback failed");
        Step("read_native_features");
        List<Dictionary<string,object>> features=new List<Dictionary<string,object>>();
        IFeature item=(IFeature)part.FirstFeature();
        while(item!=null) {
            if(features.Count>=2048) throw new InvalidOperationException("Feature traversal exceeded its bound");
            string rawType=item.GetTypeName2();
            string underlyingType=rawType=="ICE" ? item.GetTypeName() : rawType;
            features.Add(new Dictionary<string,object>{{"name",item.Name},{"type",underlyingType},{"raw_type_name2",rawType}});
            item=(IFeature)item.GetNextFeature();
        }
        return new Dictionary<string,object>{{"body_count",bodies.Length},{"volume_m3",mass[3]},{"surface_area_m2",mass[4]},
            {"mass_kg_at_declared_density",mass[5]},{"density_kg_m3",density},{"density_source","declared specification, not assigned material"},
            {"native_material_assigned",false},{"center_of_mass_m",new double[]{mass[0],mass[1],mass[2]}},{"bounding_box_m",box},
            {"bounding_box_approximate",true},{"features",features}};
    }
    private static void BuildPart(IModelDoc2 part,string profile,double width,double height,double radius,double depth,double[] holes) {
        Step("find_native_reference_plane");
        IFeature plane=(IFeature)part.FirstFeature();int guard=0;
        while(plane!=null && plane.GetTypeName2()!="RefPlane") {plane=(IFeature)plane.GetNextFeature();if(++guard>1024) throw new InvalidOperationException("Reference-plane traversal exceeded its bound");}
        if(plane==null) throw new InvalidOperationException("A native part reference plane was not found");
        part.ClearSelection2(true);
        if(!plane.Select2(false,0)) throw new InvalidOperationException("Unable to select the native reference plane");
        Step("build_native_base_sketch");
        ISketchManager manager=(ISketchManager)part.SketchManager;
        manager.InsertSketch(true);
        ISketch sketch=(ISketch)part.GetActiveSketch2();
        if(sketch==null) throw new InvalidOperationException("The native base sketch is not active");
        if(profile=="rectangle") manager.CreateCornerRectangle(-width/2000,-height/2000,0,width/2000,height/2000,0);
        else manager.CreateCircleByRadius(0,0,0,radius/1000);
        manager.InsertSketch(true);part.ClearSelection2(true);
        IFeature sketchFeature=SketchFeature(part,sketch);
        if(!sketchFeature.Select2(false,0)) throw new InvalidOperationException("The native base sketch could not be selected for extrusion");
        Step("extrude_native_base");
        IFeatureManager featureManager=(IFeatureManager)part.FeatureManager;
        double metres=depth/1000;
        IFeature extrusion=(IFeature)featureManager.FeatureExtrusion3(true,false,false,0,0,metres,metres,false,false,false,false,0,0,false,false,false,false,true,true,true,0,0,false);
        if(extrusion==null) throw new InvalidOperationException("Native boss extrusion failed");
        if(holes.Length>0) {
            Step("build_native_hole_sketch");
            part.ClearSelection2(true);
            if(!plane.Select2(false,0)) throw new InvalidOperationException("Unable to reselect the native reference plane");
            manager.InsertSketch(true);
            ISketch holeSketch=(ISketch)part.GetActiveSketch2();
            if(holeSketch==null) throw new InvalidOperationException("The native hole sketch is not active");
            for(int i=0;i<holes.Length;i+=3) manager.CreateCircleByRadius(holes[i]/1000,holes[i+1]/1000,0,holes[i+2]/1000);
            manager.InsertSketch(true);part.ClearSelection2(true);
            IFeature holeFeature=SketchFeature(part,holeSketch);
            if(!holeFeature.Select2(false,0)) throw new InvalidOperationException("The native hole sketch could not be selected for cutting");
            Step("cut_native_through_holes");
            IFeature cut=(IFeature)featureManager.FeatureCut4(true,false,true,1,1,metres,metres,false,false,false,false,0,0,false,false,false,false,false,true,true,false,false,false,0,0,false,false);
            if(cut==null) throw new InvalidOperationException("Native through-hole cut failed");
        }
        Step("rebuild_native_part");part.ForceRebuild3(false);part.ClearSelection2(true);
        part.ShowNamedView2("",7);part.ViewZoomtofit2();
    }
    public static Dictionary<string,object> Execute(object raw,string operation,string directory,string profile,double width,double height,double radius,double depth,double[] holes,double density,bool exportStep) {
        try {
            Step("validate_native_business_request");
            if(operation!="run" && operation!="open" && operation!="readback" && operation!="cleanup") throw new ArgumentException("Unsupported native business operation");
            directory=Path.GetFullPath(directory);string run=Path.GetFileName(directory);
            if(!Directory.Exists(directory) || !Regex.IsMatch(run,@"^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-4[a-fA-F0-9]{3}-[89abAB][a-fA-F0-9]{3}-[a-fA-F0-9]{12}$")) throw new ArgumentException("The native run directory identity is invalid");
            Validate(profile,width,height,radius,depth,holes,density);
            string project=Path.Combine(directory,"result-"+run+".sldprt");
            ISldWorks app=(ISldWorks)raw;
            IModelDoc2 part=null;
            Dictionary<string,object> result=new Dictionary<string,object>{{"project",project}};
            if(operation=="run") {
                if(File.Exists(project)) throw new InvalidOperationException("Native target already exists; it will not be overwritten");
                Step("create_native_part");part=(IModelDoc2)app.NewPart();
                if(part==null) throw new InvalidOperationException("No part template is configured; set the default SOLIDWORKS part template and retry with a new run");
                BuildPart(part,profile,width,height,radius,depth,holes);
                Step("save_native_project");int saveError=0,saveWarning=0;
                IModelDocExtension extension=(IModelDocExtension)part.Extension;
                bool saved=extension.SaveAs(project,0,1,null,ref saveError,ref saveWarning);
                if(!saved || saveError!=0 || !File.Exists(project)) throw new InvalidOperationException("Native SLDPRT save failed: "+saveError);
                result["save_errors"]=saveError;result["save_warnings"]=saveWarning;
                if(exportStep) {
                    Step("export_native_step");int activateError=0;
                    app.ActivateDoc3(part.GetTitle(),false,0,ref activateError);part.ClearSelection2(true);
                    if(activateError!=0) throw new InvalidOperationException("Native project activation for STEP failed: "+activateError);
                    string step=Path.Combine(directory,"result.step");int stepError=0,stepWarning=0;
                    bool exported=extension.SaveAs(step,0,1,null,ref stepError,ref stepWarning);
                    if(!exported || stepError!=0 || !File.Exists(step)) throw new InvalidOperationException("STEP export failed: "+stepError);
                    result["step"]=step;result["step_errors"]=stepError;result["step_warnings"]=stepWarning;
                }
                Step("export_native_preview");string bitmap=Path.Combine(directory,"preview.bmp"),preview=Path.Combine(directory,"preview.png");
                if(!part.SaveBMP(bitmap,1200,900)) throw new InvalidOperationException("Native model preview export failed");
                using(Image image=Image.FromFile(bitmap)) image.Save(preview,ImageFormat.Png);
                File.Delete(bitmap);result["preview"]=preview;
                CloseOwned(app,part,project);
                bool reopened;int reopenWarning;part=OpenOwned(app,project,out reopened,out reopenWarning);
                if(!reopened) throw new InvalidOperationException("Native project disk reopen was not positively observed");
                result["reopened"]=true;result["reopen_warnings"]=reopenWarning;
            } else if(operation=="cleanup") {
                Step("find_owned_project_for_cleanup");part=(IModelDoc2)app.GetOpenDocumentByName(project);
                if(part!=null) CloseOwned(app,part,project);
                result["closed_owned_document"]=true;return result;
            } else {
                bool opened;int warning;part=OpenOwned(app,project,out opened,out warning);
                result["opened"]=true;result["opened_from_disk"]=opened;result["open_warnings"]=warning;
            }
            result["document_dirty"]=part.GetSaveFlag();
            foreach(KeyValuePair<string,object> property in ReadPart(part,density)) result[property.Key]=property.Value;
            return result;
        } catch(Exception error) {error.Data["native_stage"]=Stage;throw;}
    }
}
