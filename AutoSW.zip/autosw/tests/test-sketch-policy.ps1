param(
 [Parameter(Mandatory=$true)][string]$PiaDirectory,
 [string]$OutputDirectory
)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -ne 'Desktop'){throw 'Run this compile-only policy test with Windows PowerShell 5.'}
if(-not $OutputDirectory){$OutputDirectory=Join-Path ([IO.Path]::GetTempPath()) ('autosw-sketch-policy-'+[Guid]::NewGuid().ToString('N'))}
[void][IO.Directory]::CreateDirectory($OutputDirectory)
$testDirectory=$PSScriptRoot
if(-not $testDirectory){$testDirectory=[IO.Path]::GetDirectoryName($env:YANLABS_SOLIDWORKS_SCRIPT)}
$api=[IO.Path]::GetFullPath((Join-Path $testDirectory '..\bridge\general-api.cs'))
$policy=Join-Path $testDirectory 'test-sketch-policy.cs'
$pia=Join-Path $PiaDirectory 'SolidWorks.Interop.sldworks.dll'
foreach($file in [IO.Directory]::GetFiles($PiaDirectory,'SolidWorks.Interop.*.dll')){[void][Reflection.Assembly]::LoadFrom($file)}
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$helper=Join-Path $OutputDirectory 'AutoSWSketchPolicyHelper.dll'
& $compiler /nologo /target:library ('/out:'+$helper) ('/reference:'+$pia) /reference:System.Drawing.dll /reference:System.Web.Extensions.dll /reference:Microsoft.CSharp.dll /reference:System.Core.dll $api
if($LASTEXITCODE -ne 0){throw 'Trusted helper compilation failed'}
[void][Reflection.Assembly]::LoadFrom($helper)
$test=Join-Path $OutputDirectory 'AutoSWSketchPolicyTests.dll'
& $compiler /nologo /target:library ('/out:'+$test) ('/reference:'+$helper) $policy
if($LASTEXITCODE -ne 0){throw 'Policy test compilation failed'}
[void][Reflection.Assembly]::LoadFrom($test)
$passed=[AutoSWSketchPolicyTests]::Run($OutputDirectory)
[pscustomobject]@{passed=$true;tests=$passed;compile_only=$true;build_invocations=0;real_com_calls=0;output_directory=$OutputDirectory}|ConvertTo-Json -Compress
