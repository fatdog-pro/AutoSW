"""AutoSW portable CLI / stdio MCP entry. Never interprets a shell command."""
import argparse
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from autosw_runtime import AutoSWError, Runtime


def main(argv=None):
    for stream in (sys.stdin,sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'):
            stream.reconfigure(encoding='utf-8',errors='strict')
    parser = argparse.ArgumentParser(description='AutoSW: fixed-workspace official SOLIDWORKS API executor')
    parser.add_argument('--workspace',required=True,help='Existing project directory; fixed for this invocation/MCP process')
    sub = parser.add_subparsers(dest='command',required=True)
    for command in ('init','verify','catalog','connect','status','disconnect','mcp'):
        sub.add_parser(command)
    api = sub.add_parser('api'); api.add_argument('--type',dest='type_name',required=True); api.add_argument('--member')
    source = sub.add_parser('write-script'); source.add_argument('--path',required=True)
    source.add_argument('--source-stdin',action='store_true',required=True,help='Read explicit C# method body from UTF-8 stdin')
    source.add_argument('--expected-sha256')
    run = sub.add_parser('run-script'); run.add_argument('--path',required=True)
    run.add_argument('--source-sha256',required=True); run.add_argument('--operation-key',required=True)
    for command in ('readback','open','cleanup'):
        item = sub.add_parser(command); item.add_argument('--run-id',required=True)
        if command=='open': item.add_argument('--artifact')
    inspect = sub.add_parser('input-inspect'); inspect.add_argument('--path',required=True)
    args = vars(parser.parse_args(argv)); workspace=args.pop('workspace'); command=args.pop('command')
    try:
        runtime = Runtime(workspace)
        if command=='mcp':
            from autosw_mcp import serve
            serve(runtime,sys.stdin,sys.stdout)
            return 0
        if command=='write-script':
            args.pop('source_stdin')
            args['source'] = sys.stdin.read(1048577)
        result = getattr(runtime,command.replace('-','_'))(**args)
        print(json.dumps(result,ensure_ascii=True,separators=(',',':')))
        return 0 if result.get('ok') is True else 1
    except AutoSWError as error:
        if command=='mcp':
            print(json.dumps(dict(code=error.code,error=str(error)),ensure_ascii=True),file=sys.stderr)
            return 1
        print(json.dumps(dict(ok=False,code=error.code,error=str(error)),ensure_ascii=True))
        return 1
    except Exception:
        if command=='mcp':
            print('AutoSW MCP executor failed; preserve and inspect the original run.',file=sys.stderr)
            return 1
        print(json.dumps(dict(ok=False,code='AUTOSW_LOCAL_ERROR',
            error='Local executor could not confirm completion; inspect the preserved original run before retrying'),ensure_ascii=True))
        return 1


if __name__=='__main__':
    raise SystemExit(main())
