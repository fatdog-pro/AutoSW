[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$RequestPath)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$nativeStage='read_request'
$request=Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$mutex=$null
$legacyMutex=$null
$legacyLocked=$false
$locked=$false
$application=$null
$typedApplication=$null
$hostState=$null
$hostReady=$false
function New-NativeFailure($record,[string]$stage) {
    $exception=$record.Exception;$diagnostic=$exception;$depth=0
    while($null -ne $exception -and $depth -lt 12){if($exception.Data.Contains('native_stage')){$stage=[string]$exception.Data['native_stage']};if($exception -is [Runtime.InteropServices.COMException]){$diagnostic=$exception};$exception=$exception.InnerException;$depth++}
    $result=@{ok=$false;error=[string]$record.Exception.Message;native_stage=$stage;hresult=('0x'+([int]$diagnostic.HResult).ToString('X8'));native_error_type=$diagnostic.GetType().FullName;native_line=[int]$record.InvocationInfo.ScriptLineNumber;original_request_preserved=$true}
    $exception=$record.Exception
    while($null -ne $exception){foreach($key in @('code','execution_not_started','native_outcome_known')){if($exception.Data.Contains($key)){$result[$key]=$exception.Data[$key]}};$exception=$exception.InnerException}
    return $result
}
function Resolve-SolidworksInstallation {
    $classes=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::ClassesRoot,[Microsoft.Win32.RegistryView]::Registry64)
    $progid=$null;$server=$null
    try {
        $progid=$classes.OpenSubKey('SldWorks.Application\CLSID')
        if($null -eq $progid){throw 'A registered SOLIDWORKS desktop installation was not found'}
        $classId=[string]$progid.GetValue('')
        if($classId -notmatch '^\{[a-fA-F0-9-]{36}\}$'){throw 'The registered SOLIDWORKS application identity is invalid'}
        $server=$classes.OpenSubKey(('CLSID\'+$classId+'\LocalServer32'))
        if($null -eq $server){throw 'The registered SOLIDWORKS executable was not found'}
        $value=[Environment]::ExpandEnvironmentVariables([string]$server.GetValue(''))
        if($value -match '^\s*"([^"]+\.exe)"(?:\s.*)?$'){$executable=$matches[1]}
        elseif($value -match '^\s*(.+?\.exe)(?:\s.*)?$'){$executable=$matches[1]}
        else{throw 'The registered SOLIDWORKS executable path is invalid'}
        $executable=[IO.Path]::GetFullPath($executable)
        if([IO.Path]::GetFileName($executable) -ine 'SLDWORKS.exe' -or -not [IO.File]::Exists($executable)){throw 'The registered SOLIDWORKS executable is unavailable'}
        $signature=Get-AuthenticodeSignature -LiteralPath $executable
        if($signature.Status -ne 'Valid' -or $null -eq $signature.SignerCertificate -or $signature.SignerCertificate.Subject -notmatch '(?i)Dassault|SolidWorks'){throw 'The registered SOLIDWORKS executable publisher could not be verified'}
        $pia=Join-Path ([IO.Path]::GetDirectoryName($executable)) 'api\redist\SolidWorks.Interop.sldworks.dll'
        if(-not [IO.File]::Exists($pia)){throw 'The installed official SOLIDWORKS .NET interop assembly is unavailable'}
        return @{executable=$executable;pia=$pia}
    } finally {if($null -ne $server){$server.Dispose()};if($null -ne $progid){$progid.Dispose()};$classes.Dispose()}
}
function Initialize-SolidworksInterop([string]$pia) {
    [void][Reflection.Assembly]::LoadFrom($pia)
    Add-Type -ReferencedAssemblies $pia -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using SolidWorks.Interop.sldworks;
public sealed class YanLabsSWConnection {
 [DllImport("user32.dll", SetLastError=true)]
 [return: MarshalAs(UnmanagedType.Bool)]
 private static extern bool IsWindow(IntPtr window);
 [DllImport("user32.dll", SetLastError=true)]
 private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
 private readonly object raw;
 private readonly ISldWorks app;
 private YanLabsSWConnection(object value) { raw=value; app=(ISldWorks)value; }
 public static YanLabsSWConnection AttachExisting() { return new YanLabsSWConnection(Marshal.GetActiveObject("SldWorks.Application")); }
 public object NativeObject() { return raw; }
 public int ProcessId() { return app.GetProcessID(); }
 // Process.MainWindowHandle may point at a modal/auxiliary window. The early-
 // bound official IFrame API is the identity of the application frame itself.
 public long MainFrameWindow() { return ((IFrame)app.Frame()).GetHWndx64(); }
 public static bool WindowBelongsToProcess(long window, int processId) {
  if(window<=0 || processId<=0) return false;
  IntPtr handle=new IntPtr(window);
  uint owner;
  return IsWindow(handle) && GetWindowThreadProcessId(handle,out owner)!=0 && owner==(uint)processId;
 }
 public string Revision() { return app.RevisionNumber(); }
 public bool IsVisible() { return app.Visible; }
 public void SetVisible() { app.Visible=true; }
 public void SetUserControl() { app.UserControl=true; }
 public void ExitIfEmpty() { if(app.GetFirstDocument()!=null) throw new InvalidOperationException("Documents remain open; the application is retained"); app.ExitApp(); }
}
'@
}
function Get-SolidworksProcesses {
    try {
        # Enumerate all processes so that an empty match is a successful read,
        # rather than a suppressed Get-Process -Name error mistaken for absence.
        $processes=@(Get-Process -ErrorAction Stop | Where-Object {$_.ProcessName -ieq 'SLDWORKS'})
        foreach($process in $processes){
            if($process.Id -le 0 -or $process.StartTime.ToUniversalTime().Ticks -le 0){throw 'A SOLIDWORKS process birth could not be read'}
        }
        return $processes
    } catch {
        $failure=[InvalidOperationException]::new('SOLIDWORKS process inspection failed; no application may be launched from an unconfirmed snapshot',$_.Exception)
        $failure.Data['code']='SW_PROCESS_INSPECTION_FAILED'
        throw $failure
    }
}
function Select-SolidworksStartup([string]$executable) {
    # Recheck after installation verification and interop compilation, directly
    # before launch. A sole application that appeared meanwhile is reused.
    $script:nativeStage='inspect_processes_before_launch'
    $current=@(Get-SolidworksProcesses)
    if($current.Count -gt 1){Throw-HostError 'SW_RECONNECT_REQUIRED' 'This integration requires one SOLIDWORKS application instance; no application was changed'}
    if($current.Count -eq 1){
        $selected=$current[0]
        $hostState.pid=[int]$selected.Id;$hostState.process_start_ticks=[string]$selected.StartTime.ToUniversalTime().Ticks
        $hostState.created_app=$false;$hostState.native_launch_state='preexisting'
        Save-HostState
    }else{
        $script:nativeStage='launch_normal_application'
        # A launch can succeed even when the caller fails before observing its
        # result. Keep that possibility durable before invoking Start-Process.
        $hostState.native_launch_state='requested';$hostState.native_launch_may_have_occurred=$true
        $hostState.native_launch_executable=$executable;Save-HostState
        $launched=Start-Process -FilePath $executable -WorkingDirectory ([IO.Path]::GetDirectoryName($executable)) -WindowStyle Normal -PassThru
        $hostState.pid=[int]$launched.Id;$hostState.created_app=$true
        $hostState.process_start_ticks=[string]$launched.StartTime.ToUniversalTime().Ticks
        $hostState.native_launch_state='launched'
        # Publish the actual process birth before COM/frame/compilation calls.
        Save-HostState
    }
    return @{pid=$hostState.pid;process_start_ticks=$hostState.process_start_ticks;created_app=$hostState.created_app}
}
function Wait-SolidworksCom([int]$expectedPid,[string]$expectedStartTicks,[int]$timeoutMs=120000,[int]$pollMs=500) {
    $clock=[Diagnostics.Stopwatch]::StartNew();$lastException=$null
    do {
        $running=@(Get-Process -Name SLDWORKS -ErrorAction SilentlyContinue)
        if($running.Count -ne 1 -or $running[0].Id -ne $expectedPid -or [string]$running[0].StartTime.ToUniversalTime().Ticks -ne $expectedStartTicks){throw 'The original SOLIDWORKS startup process changed; no additional application was launched'}
        try {return [YanLabsSWConnection]::AttachExisting()} catch {$lastException=$_.Exception}
        if($clock.ElapsedMilliseconds -ge $timeoutMs){break}
        Start-Sleep -Milliseconds ([Math]::Max(1,[Math]::Min($pollMs,$timeoutMs-$clock.ElapsedMilliseconds)))
    } while($clock.ElapsedMilliseconds -le $timeoutMs)
    throw [InvalidOperationException]::new('SOLIDWORKS COM endpoint is not ready after the bounded startup wait; complete startup or licence dialogs before reconnecting',$lastException)
}
function Initialize-SolidworksBusiness([string]$pia) {
    if('YanLabsSWBusiness' -as [type]){return}
    $nativeDirectory=[IO.Path]::GetDirectoryName($env:YANLABS_SOLIDWORKS_SCRIPT)
    $businessSource=Join-Path $nativeDirectory 'business-native.cs'
    $generalSource=Join-Path $nativeDirectory 'general-api.cs'
    if(-not [IO.File]::Exists($businessSource)){throw 'The reviewed SOLIDWORKS business helper is missing from the client installation'}
    $sources=@($businessSource);if([IO.File]::Exists($generalSource)){$sources+=@($generalSource)}
    $references=@($pia,'System.Drawing.dll','System.Core.dll','Microsoft.CSharp.dll','System.Web.Extensions.dll')
    foreach($name in @('SolidWorks.Interop.swconst.dll','SolidWorks.Interop.cosworks.dll')){$file=Join-Path ([IO.Path]::GetDirectoryName($pia)) $name;if([IO.File]::Exists($file)){$references+=@($file);[void][Reflection.Assembly]::LoadFrom($file)}}
    $assembly=Join-Path $request.host_home ('fixed-business-'+[Guid]::NewGuid().ToString('N')+'.dll')
    Add-Type -Path $sources -ReferencedAssemblies $references -OutputAssembly $assembly
    [void][Reflection.Assembly]::LoadFrom($assembly)
}

function Throw-HostError([string]$code,[string]$message) {$e=[InvalidOperationException]::new($message);$e.Data['code']=$code;throw $e}
function Write-HostJson([string]$path,$value) {
    $temporary=Join-Path ([IO.Path]::GetDirectoryName($path)) ('.'+[Guid]::NewGuid().ToString('N')+'.tmp')
    [IO.File]::WriteAllText($temporary,($value|ConvertTo-Json -Depth 32 -Compress),[Text.UTF8Encoding]::new($false))
    if([IO.File]::Exists($path)){
        # PS5 converts an untyped $null backup argument to an empty string for
        # File.Replace. Use an explicit same-directory backup, preserving an
        # atomic canonical file without ever deleting it before replacement.
        $backup=Join-Path ([IO.Path]::GetDirectoryName($path)) ('.'+[Guid]::NewGuid().ToString('N')+'.bak')
        for($attempt=0;;$attempt++){
            try{[IO.File]::Replace($temporary,$path,$backup);break}catch{
                $inner=$_.Exception;while($null -ne $inner.InnerException){$inner=$inner.InnerException}
                if($attempt -ge 9 -or ($inner.HResult -band 65535) -notin @(32,33)){throw}
                Start-Sleep -Milliseconds 20
            }
        }
        try{[IO.File]::Delete($backup)}catch{[Console]::Error.WriteLine('A local state backup awaits cleanup: '+$backup)}
    }else{[IO.File]::Move($temporary,$path)}
}
function Save-HostState {Write-HostJson (Join-Path $request.host_home 'state.json') $hostState}
function Save-HostTerminalFailure($record,[string]$stage,[bool]$ready) {
    $failure=New-NativeFailure $record $stage
    foreach($key in $failure.Keys){$hostState[$key]=$failure[$key]}
    $hostState.connected=$false
    if(-not $ready){
        $launchUnconfirmed=$hostState.native_launch_may_have_occurred -eq $true
        $hostState.status=if($launchUnconfirmed){'unknown'}else{'failed'}
        $hostState.busy=$launchUnconfirmed;$hostState.native_operation=$null
        $hostState.initialization_failed=$true;$hostState.execution_not_started=-not $launchUnconfirmed
        $hostState.cad_execution_not_started=$true
        $hostState.code=if($launchUnconfirmed){'SW_OPERATION_UNKNOWN'}else{'SW_HOST_START_FAILED'}
        # This independent startup-only terminal proof never replaces the
        # original request. Readers can use it if canonical-state IO fails too.
        Write-HostJson (Join-Path $request.host_home ('startup-'+$hostState.host_id+'-failure.json')) $hostState
    }else{
        $hostState.status=if($hostState.busy){'unknown'}else{'failed'}
        if($hostState.busy){$hostState.code='SW_OPERATION_UNKNOWN'}
    }
    try{Save-HostState}catch{
        [Console]::Error.WriteLine('The terminal canonical state could not be written: '+$_.Exception.Message)
    }
    $failure.code=$hostState.code;$failure.state=$hostState.status;$failure.busy=$hostState.busy
    $failure.execution_not_started=($hostState.execution_not_started -eq $true)
    foreach($key in @('initialization_failed','cad_execution_not_started','native_launch_state','native_launch_may_have_occurred','native_launch_executable','pid','process_start_ticks','created_app')){
        if($hostState.ContainsKey($key)){$failure[$key]=$hostState[$key]}
    }
    return $failure
}
function Assert-SourceSnapshot {
    $directory=[IO.Path]::GetDirectoryName($env:YANLABS_SOLIDWORKS_SCRIPT)
    foreach($property in $request.source_snapshot.files.psobject.Properties){
        if($property.Name -notin @('cli.py','core.py','host_transport.py','native-com.ps1','host-transport.cs','business-native.cs','general-api.cs')){Throw-HostError 'SW_HOST_SCOPE_INVALID' 'The fixed native source list is invalid'}
        $file=Join-Path $directory $property.Name
        if(-not [IO.File]::Exists($file)){Throw-HostError 'SW_HOST_UPGRADE_REQUIRED' 'A fixed native host input is no longer available'}
        $sha=[Security.Cryptography.SHA256]::Create();try{$hash=([BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($file)))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
        if($hash -cne [string]$property.Value){Throw-HostError 'SW_HOST_UPGRADE_REQUIRED' 'Fixed native host sources changed; retire this host normally before reconnecting'}
    }
}
function Connection-Identity {
    return @{host_id=$hostState.host_id;host_pid=$hostState.host_pid;host_process_start_ticks=$hostState.host_process_start_ticks;pid=$hostState.pid;process_start_ticks=$hostState.process_start_ticks;hwnd=$hostState.hwnd}
}
function Assert-ApplicationIdentity($expected) {
    foreach($key in @('host_id','host_pid','host_process_start_ticks','pid','process_start_ticks','hwnd')){if([string]$expected.$key -cne [string]$hostState[$key]){Throw-HostError 'SW_RECONNECT_REQUIRED' 'The request no longer belongs to the original host/application identity'}}
    $running=@(Get-Process -Name SLDWORKS -ErrorAction SilentlyContinue)
    if($running.Count -ne 1 -or $running[0].Id -ne $hostState.pid -or [string]$running[0].StartTime.ToUniversalTime().Ticks -cne $hostState.process_start_ticks){Throw-HostError 'SW_RECONNECT_REQUIRED' 'The original SOLIDWORKS instance exited or changed; reconnect explicitly, no replacement was launched'}
    if($typedApplication.ProcessId() -ne $hostState.pid -or $typedApplication.MainFrameWindow() -ne [long]$hostState.hwnd -or -not [YanLabsSWConnection]::WindowBelongsToProcess([long]$hostState.hwnd,[int]$hostState.pid)){Throw-HostError 'SW_RECONNECT_REQUIRED' 'The original SOLIDWORKS application frame exited or changed; reconnect explicitly'}
}

try {
    if($request.operation -ne 'host'){Throw-HostError 'SW_HOST_ONLY' 'CAD requests must use the persistent STA host; one-shot COM execution is disabled'}
    if([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -cne $request.windows_sid -or [Diagnostics.Process]::GetCurrentProcess().SessionId -ne $request.windows_session){Throw-HostError 'SW_USER_CONTEXT_REQUIRED' 'The native host must run under the original Windows user and login session'}
    $mutex=[Threading.Mutex]::new($false,('Local\'+$request.pipe_name+'-owner'))
    try {$locked=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$locked=$true}
    if(-not $locked){Throw-HostError 'SW_HOST_BUSY' 'The original same-login SOLIDWORKS host is still running'}
    $hostProcess=[Diagnostics.Process]::GetCurrentProcess()
    $hostState=@{ok=$true;status='starting';connected=$false;busy=$true;native_operation=$null;host_id=[string]$request.host_id;host_pid=$PID;host_process_start_ticks=[string]$hostProcess.StartTime.ToUniversalTime().Ticks;source_sha256=[string]$request.source_snapshot.sha256;native_launch_state='not_requested';native_launch_may_have_occurred=$false;cad_execution_not_started=$true}
    $nativeStage='publish_starting_state'
    Save-HostState
    # Exclude an in-flight pre-host (0.2.99) bridge as well. This mutex never
    # closes or takes over that caller's software/documents.
    $legacyMutex=[Threading.Mutex]::new($false,'Local\YanLabsSolidWorksNativeCOM-v1')
    try{$legacyLocked=$legacyMutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$legacyLocked=$true}
    if(-not $legacyLocked){Throw-HostError 'SW_HOST_BUSY' 'An earlier SOLIDWORKS native bridge still owns its operation; no application was changed'}
    Assert-SourceSnapshot
    $nativeStage='compile_local_pipe_transport'
    $transportSource=Join-Path ([IO.Path]::GetDirectoryName($env:YANLABS_SOLIDWORKS_SCRIPT)) 'host-transport.cs'
    Add-Type -Path $transportSource -ReferencedAssemblies @('System.Core.dll','System.Windows.Forms.dll')
    $nativeStage='inspect_processes'
    $running=@(Get-SolidworksProcesses)
    if($running.Count -gt 1){Throw-HostError 'SW_RECONNECT_REQUIRED' 'This integration requires one SOLIDWORKS application instance; no application was changed'}
    $nativeStage='resolve_official_installation';$installation=Resolve-SolidworksInstallation
    $nativeStage='load_installed_interop';Initialize-SolidworksInterop $installation.pia
    $selected=Select-SolidworksStartup $installation.executable
    $expectedPid=[int]$selected.pid;$expectedStartTicks=[string]$selected.process_start_ticks;$created=[bool]$selected.created_app
    $nativeStage='attach_running_com';$typedApplication=Wait-SolidworksCom $expectedPid $expectedStartTicks
    $application=$typedApplication.NativeObject()
    $nativeStage='set_application_user_control';$typedApplication.SetUserControl();$typedApplication.SetVisible()
    $nativeStage='read_application_pid';$appPid=$typedApplication.ProcessId()
    if($appPid -ne $expectedPid){Throw-HostError 'SW_RECONNECT_REQUIRED' 'The application COM endpoint belongs to another native process'}
    $nativeStage='read_visible_frame';$clock=[Diagnostics.Stopwatch]::StartNew();$hwnd=0
    do{$hwnd=$typedApplication.MainFrameWindow();if([YanLabsSWConnection]::WindowBelongsToProcess([long]$hwnd,[int]$appPid)){break};$hwnd=0;Start-Sleep -Milliseconds 100}while($clock.ElapsedMilliseconds -lt 30000)
    if($hwnd -le 0){Throw-HostError 'SW_RECONNECT_REQUIRED' 'The original SOLIDWORKS process has no verified visible main window'}
    $version=[string]$typedApplication.Revision()
    $hostState.pid=[int]$appPid;$hostState.process_start_ticks=$expectedStartTicks;$hostState.hwnd=[long]$hwnd
    $hostState.version=$version;$hostState.created_app=$created;$hostState.visible=[bool]$typedApplication.IsVisible()
    $nativeStage='compile_typed_business_helper';Initialize-SolidworksBusiness $installation.pia
    $ownedDocuments=[Collections.Generic.Dictionary[string,object]]::new()
    $operationDirectory=Join-Path $request.host_home 'operations';[void][IO.Directory]::CreateDirectory($operationDirectory)
    $hostState.status='connected';$hostState.connected=$true;$hostState.busy=$false;$nativeStage='publish_connected_state';Save-HostState;$hostReady=$true
    $auth=[IO.File]::ReadAllText((Join-Path $request.host_home 'auth.key'),[Text.Encoding]::ASCII)
    $retire=$false
    while(-not $retire){
        $pipe=$null;$envelope=$null;$operationAccepted=$false;$operationCommitted=$false
        try{
            $nativeStage='wait_local_request';$pipe=[YanLabsSWPipe]::new([string]$request.pipe_name,[string]$request.windows_sid)
            $message=$pipe.Receive()|ConvertFrom-Json
            if([string]$message.auth -cne $auth){Throw-HostError 'SW_HOST_AUTH_INVALID' 'The local host request was not authenticated'}
            $envelope=$message;$payload=$message.payload;$operation=[string]$payload.operation
            if([string]$message.operation_id -notmatch '^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-4[a-fA-F0-9]{3}-[89aAbB][a-fA-F0-9]{3}-[a-fA-F0-9]{12}$'){Throw-HostError 'SW_HOST_REQUEST_INVALID' 'The operation identity is invalid'}
            if($operation -notin @('connect','status','disconnect','close-owned-empty','api','run','script','readback','open','cleanup')){Throw-HostError 'SW_HOST_REQUEST_INVALID' 'The native host operation is not supported'}
            if($operation -ne 'disconnect'){
                Assert-SourceSnapshot
                if([string]$message.source_sha256 -cne $hostState.source_sha256){Throw-HostError 'SW_HOST_UPGRADE_REQUIRED' 'The request uses a different fixed native source snapshot'}
                Assert-ApplicationIdentity $message.expected_identity
            }else{foreach($key in @('host_id','host_pid','host_process_start_ticks','pid','process_start_ticks','hwnd')){if([string]$message.expected_identity.$key -cne [string]$hostState[$key]){Throw-HostError 'SW_RECONNECT_REQUIRED' 'The requested host/application retirement identity changed'}}}
            if($hostState.busy -and -not ($operation -eq 'readback' -and $payload.run_id -ceq $hostState.native_operation.run_id)){Throw-HostError 'SW_HOST_BUSY' 'The original native task is still pending; only its readback is permitted'}
            $result=@{};foreach($key in $hostState.Keys){if($key -ne 'native_operation'){$result[$key]=$hostState[$key]}}
            if($operation -in @('disconnect','close-owned-empty')){
                if($operation -eq 'close-owned-empty'){
                    if(-not $hostState.created_app){Throw-HostError 'SW_APP_NOT_OWNED' 'The user SOLIDWORKS application must be retained'}
                    $typedApplication.ExitIfEmpty();$result.closed_owned_application=$true
                }
                $result.connected=$false;$result.status='retired';$result.host_retired=$true;$result.noop=$false
                $result.host_only=($operation -eq 'disconnect');$result.application_closed=($operation -eq 'close-owned-empty');$retire=$true
            }elseif($operation -eq 'api'){
                $nativeStage='reflect_installed_api';$business=[YanLabsSWGeneral]::Reflect($application,[string]$payload.type_name,[string]$payload.member_name)
                foreach($key in $business.Keys){$result[$key]=$business[$key]}
            }elseif($operation -notin @('connect','status')){
                $hostState.status='running';$hostState.busy=$true;$hostState.cad_execution_not_started=$false;$hostState.native_operation=@{status='running';operation_id=[string]$message.operation_id;command=$operation;run_id=[string]$payload.run_id;workspace=[string]$payload.workspace}
                Write-HostJson (Join-Path $operationDirectory ($message.operation_id+'-intent.json')) @{operation_id=[string]$message.operation_id;payload=$payload;connection_identity=(Connection-Identity)}
                Save-HostState;$operationAccepted=$true;$nativeStage='typed_business_dispatch'
                if($payload.business_kind -eq 'script'){
                    $business=[YanLabsSWGeneral]::Dispatch($application,$operation,[string]$payload.workspace,[string]$payload.directory,[string]$payload.source_snapshot_path,[string]$payload.source_sha256,[string]$payload.binding_json,$ownedDocuments,[string]$payload.requested_artifact)
                }else{
                    $spec=$payload.spec;$base=$spec.base;[double[]]$coordinates=@(foreach($hole in $spec.holes){[double]$hole.x;[double]$hole.y;[double]$hole.radius})
                    $business=[YanLabsSWBusiness]::Execute($application,$operation,[string]$payload.directory,[string]$base.profile,[double]$base.width,[double]$base.height,[double]$base.radius,[double]$base.depth,$coordinates,[double]$spec.density_kg_m3,[bool]$spec.export_step)
                }
                foreach($key in $business.Keys){$result[$key]=$business[$key]}
                Assert-ApplicationIdentity $message.expected_identity
                $hostState.status='connected';$hostState.busy=$false;$hostState.native_operation=$null
            }
            foreach($key in @('host_id','host_pid','host_process_start_ticks','pid','process_start_ticks','hwnd','created_app','version')){$result[$key]=$hostState[$key]}
            if(-not $retire){$result.visible=[bool]$typedApplication.IsVisible();$result.connected=$true}
            $result.busy=$false;$result.native_operation=$null;$result.ok=$true
            if($retire){$hostState.status='retired';$hostState.connected=$false}else{$result.status='connected'}
            if($operationAccepted){Write-HostJson (Join-Path $operationDirectory ($message.operation_id+'-receipt.json')) $result;$operationCommitted=$true}
            Save-HostState;$pipe.Send(($result|ConvertTo-Json -Depth 32 -Compress))
        }catch{
            $failure=New-NativeFailure $_ $nativeStage
            if($operationAccepted -and -not $operationCommitted){
                $known=$failure.execution_not_started -eq $true -or $failure.native_outcome_known -eq $true
                $hostState.busy=-not $known;$hostState.status=if($known){'connected'}else{'unknown'}
                if($known){$hostState.native_operation=$null}else{$hostState.native_operation.status='unknown';$failure.code='SW_OPERATION_UNKNOWN'}
                $failure.state=if($known){'failed'}else{'unknown'}
                Write-HostJson (Join-Path $operationDirectory ($envelope.operation_id+'-receipt.json')) $failure
                Save-HostState
            }
            if($null -ne $pipe){try{$pipe.Send(($failure|ConvertTo-Json -Depth 16 -Compress))}catch{}}
        }finally{if($null -ne $pipe){$pipe.Dispose()}}
    }
    exit 0
}catch{
    $failure=New-NativeFailure $_ $nativeStage
    if($locked -and $null -ne $hostState){$failure=Save-HostTerminalFailure $_ $nativeStage $hostReady}
    $failure|ConvertTo-Json -Depth 16 -Compress;exit 1
}finally{
    # Retirement releases only this STA's references. UserControl remains true;
    # no normal command, exception, host idle period or client EOF calls ExitApp.
    if($null -ne $application -and [Runtime.InteropServices.Marshal]::IsComObject($application)){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($application)}
    if($locked){$mutex.ReleaseMutex()};if($null -ne $mutex){$mutex.Dispose()}
    if($legacyLocked){$legacyMutex.ReleaseMutex()};if($null -ne $legacyMutex){$legacyMutex.Dispose()}
}
