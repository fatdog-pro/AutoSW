param(
    [Parameter(Mandatory=$true)][string]$Redist,
    [string]$OutputDirectory = ''
)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSEdition -ne 'Desktop') { throw 'Run compile-only policy QA with Windows PowerShell 5.1, matching the STA host.' }
if (-not $OutputDirectory) {
    $packageRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $OutputDirectory = Join-Path $env:TEMP ('AutoSW-visibility-policy-' + [guid]::NewGuid().ToString('N'))
}
[IO.Directory]::CreateDirectory($OutputDirectory) | Out-Null
# Metadata and managed proxies only: no ProgID, COM activation or native process.
foreach ($file in [IO.Directory]::GetFiles($Redist, 'SolidWorks.Interop.*.dll')) { [Reflection.Assembly]::LoadFrom($file) | Out-Null }
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$library = Join-Path $OutputDirectory 'AutoSWVisibilityPolicy.dll'
$driver = Join-Path $OutputDirectory 'test-visibility-policy.exe'
$bridgeSource = Join-Path $PSScriptRoot '..\bridge\general-api.cs'
& $compiler /nologo /target:library ('/out:' + $library) ('/reference:' + (Join-Path $Redist 'SolidWorks.Interop.sldworks.dll')) /reference:System.Drawing.dll /reference:System.Web.Extensions.dll /reference:Microsoft.CSharp.dll /reference:System.Core.dll $bridgeSource
if ($LASTEXITCODE -ne 0) { throw 'AutoSW bridge policy compilation failed' }
& $compiler /nologo /target:exe ('/out:' + $driver) ('/reference:' + $library) ('/reference:' + (Join-Path $Redist 'SolidWorks.Interop.sldworks.dll')) /reference:System.Web.Extensions.dll /reference:System.Core.dll (Join-Path $PSScriptRoot 'test-visibility-policy.cs')
if ($LASTEXITCODE -ne 0) { throw 'Visibility policy test compilation failed' }
[Reflection.Assembly]::LoadFrom($library) | Out-Null
[Reflection.Assembly]::LoadFrom($driver) | Out-Null
$testExit = [AutoSWVisibilityPolicyTests]::Main(@($OutputDirectory, $Redist))
exit $testExit
