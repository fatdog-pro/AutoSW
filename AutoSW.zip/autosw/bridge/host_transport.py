"""Same-login SOLIDWORKS host transport. Never launches the CAD application.

Only an explicit connect may create the fixed STA host. All other requests bind
to its durable host/application birth identities; an absent host is not a reason
to replay a request or create a replacement application.
"""
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import time
import uuid

FILES = ('cli.py', 'core.py', 'host_transport.py', 'native-com.ps1',
         'host-transport.cs', 'business-native.cs', 'general-api.cs')
IDENTITY_FIELDS = ('host_id', 'host_pid', 'host_process_start_ticks', 'pid',
                   'process_start_ticks', 'hwnd')


def windows_libraries():
    kernel, advapi = ctypes.WinDLL('kernel32', use_last_error=True), ctypes.WinDLL('advapi32', use_last_error=True)
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel.LocalFree.restype = wintypes.HLOCAL
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.ProcessIdToSessionId.argtypes = [wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    kernel.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel.CreateMutexW.restype = wintypes.HANDLE
    kernel.WaitNamedPipeW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD]
    advapi.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    advapi.GetTokenInformation.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    advapi.ConvertSidToStringSidW.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.LPWSTR)]
    advapi.GetUserNameW.argtypes = [wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.DWORD)]
    advapi.SetFileSecurityW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_void_p]
    return kernel, advapi


class HostError(RuntimeError):
    def __init__(self, code, message, unknown=False):
        super().__init__(message)
        self.code, self.unknown = code, unknown
        self.execution_not_started = not unknown


def startup_error(state):
    """Keep native launch uncertainty distinct from a CAD script dispatch."""
    unknown = state.get('status') == 'unknown' or state.get('busy') is True
    error = HostError(state.get('code', 'SW_HOST_START_FAILED'),
                      state.get('error', 'SOLIDWORKS宿主启动失败，原窗口保留'), unknown)
    error.execution_not_started = state.get('execution_not_started') is True
    error.native_details = {key: state[key] for key in (
        'initialization_failed', 'cad_execution_not_started', 'native_launch_state',
        'native_launch_may_have_occurred', 'pid', 'process_start_ticks', 'created_app',
        'source_sha256') if key in state}
    return error


def ensure_auth_key(home):
    """Never rotate a token while an earlier startup/owner may still use it."""
    path = home / 'auth.key'
    if path.is_symlink() or path.exists() and (not path.is_file() or path.stat().st_nlink != 1):
        raise HostError('SW_HOST_AUTH_INVALID', 'The private host authentication file is unsafe')
    try:
        with path.open('x', encoding='ascii') as stream:
            stream.write(secrets.token_hex(32)); stream.flush(); os.fsync(stream.fileno())
    except FileExistsError:
        pass
    token = path.read_text(encoding='ascii')
    if len(token) != 64 or any(char not in '0123456789abcdef' for char in token):
        raise HostError('SW_HOST_AUTH_INVALID', 'The private host token is incomplete; it was not replaced')


def source_snapshot(directory):
    files = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
             for name in FILES if (directory / name).is_file()}
    encoded = json.dumps(files, sort_keys=True, separators=(',', ':')).encode()
    return dict(files=files, sha256=hashlib.sha256(encoded).hexdigest())


def connect_intent(value, snapshot):
    """Internal caller metadata, never a model-selected global-host selector."""
    try:
        if not isinstance(value,dict) or set(value)!={'schema_version','connect_id','binding','source_sha256'} or value['schema_version']!=1:
            raise ValueError()
        identifier=value['connect_id'];binding=value['binding']
        if not isinstance(identifier,str) or str(uuid.UUID(identifier,version=4))!=identifier:
            raise ValueError()
        if not isinstance(binding,dict) or set(binding)!={'account_id','session_id','workspace'}:
            raise ValueError()
        if any(not isinstance(binding[k],str) or not binding[k] or len(binding[k])>200 for k in ('account_id','session_id')):
            raise ValueError()
        workspace=Path(binding['workspace'])
        if not workspace.is_absolute() or not workspace.is_dir():raise ValueError()
        for path in (workspace,*workspace.parents):
            if path.is_symlink() or path.exists() and hasattr(path,'is_junction') and path.is_junction():raise ValueError()
        if value['source_sha256']!=snapshot['sha256']:raise ValueError()
        return dict(schema_version=1,connect_id=identifier,binding=dict(binding),source_sha256=value['source_sha256'])
    except (ValueError,KeyError,TypeError,AttributeError):
        raise HostError('SW_CONNECT_INTENT_INVALID','The internal connect intent does not match its owner/workspace/frozen source') from None


def connect_proof_directory(home, intent):
    parent=home/'connect-attempts';directory=parent/intent['connect_id']
    for path in (parent,directory):
        if path.is_symlink() or path.exists() and hasattr(path,'is_junction') and path.is_junction():
            raise HostError('SW_CONNECT_INTENT_INVALID','Linked connect proofs are not accepted')
    return directory


def connect_proof_write(home, intent, name, value):
    """Exclusive, immutable proof files: an attempt cannot select two hosts."""
    directory=connect_proof_directory(home,intent);directory.mkdir(parents=True,exist_ok=True)
    path=directory/name
    if path.is_symlink() or path.exists() and (not path.is_file() or path.stat().st_nlink!=1):
        raise HostError('SW_CONNECT_INTENT_INVALID','Connect proof is not a regular single-link file')
    encoded=(json.dumps(value,ensure_ascii=True,sort_keys=True,separators=(',',':'))+'\n').encode('utf-8')
    if path.exists():
        if path.read_bytes()!=encoded:
            raise HostError('SW_CONNECT_INTENT_CONFLICT','The original connect intent/proof cannot be overwritten')
    else:
        with path.open('xb') as stream:stream.write(encoded);stream.flush();os.fsync(stream.fileno())


def connect_proof_read(home, intent, name):
    path=connect_proof_directory(home,intent)/name
    try:
        if path.is_symlink() or not path.is_file() or path.stat().st_nlink!=1 or path.stat().st_size>4*1024*1024:
            raise ValueError()
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):
        raise HostError('SW_OPERATION_UNKNOWN','The original connect proof is not yet available; no host was adopted or started',True) from None


def connect_intent_sha(intent):
    return hashlib.sha256(json.dumps(intent,ensure_ascii=True,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def select_connect_host(home, intent, state, startup=None):
    if intent is None:return
    proof=dict(schema_version=1,connect_id=intent['connect_id'],intent_sha256=connect_intent_sha(intent),
               source_sha256=intent['source_sha256'],host_id=state['host_id'])
    if startup is None:
        proof.update(choice='existing',connection_identity={key:state[key] for key in IDENTITY_FIELDS})
    else:
        proof.update(choice='startup',startup_name=startup.name,startup_sha256=hashlib.sha256(startup.read_bytes()).hexdigest())
    connect_proof_write(home,intent,'selected-host.json',proof)


def recover_connect_identity(home, intent, snapshot, sid, session):
    """Read exact intent-specific proof; never calls connect or start_host."""
    original=connect_proof_read(home,intent,'intent.json')
    selected=connect_proof_read(home,intent,'selected-host.json')
    if original!=intent or selected.get('connect_id')!=intent['connect_id'] or \
            selected.get('intent_sha256')!=connect_intent_sha(intent) or selected.get('source_sha256')!=snapshot['sha256']:
        raise HostError('SW_CONNECT_INTENT_INVALID','Connect recovery proof has a different owner, workspace or source')
    state=read_state(home)
    if state.get('host_id')!=selected.get('host_id') or state.get('source_sha256')!=snapshot['sha256']:
        raise HostError('SW_OPERATION_UNKNOWN','The original selected connect host is not confirmed; no replacement was adopted',True)
    if selected.get('choice')=='existing':
        if selected.get('connection_identity')!={key:state.get(key) for key in IDENTITY_FIELDS}:
            raise HostError('SW_OPERATION_UNKNOWN','The existing host no longer matches the original connect proof',True)
    elif selected.get('choice')=='startup':
        expected='startup-'+str(selected.get('host_id'))+'.json'
        if selected.get('startup_name')!=expected:
            raise HostError('SW_CONNECT_INTENT_INVALID','The startup proof name is not the selected original host')
        path=home/expected
        try:
            if path.is_symlink() or not path.is_file() or path.stat().st_nlink!=1 or path.stat().st_size>4*1024*1024:raise ValueError()
            raw=path.read_bytes();startup=json.loads(raw.decode('utf-8'))
            if hashlib.sha256(raw).hexdigest()!=selected.get('startup_sha256') or startup.get('connect_intent')!=intent or \
                    startup.get('host_id')!=selected['host_id'] or startup.get('host_home')!=str(home) or \
                    startup.get('windows_sid')!=sid or startup.get('windows_session')!=session or startup.get('source_snapshot')!=snapshot:
                raise ValueError()
        except (OSError,ValueError,KeyError):
            raise HostError('SW_CONNECT_INTENT_INVALID','The immutable startup proof does not match this original connect') from None
    else:
        raise HostError('SW_CONNECT_INTENT_INVALID','Unknown connect proof kind')
    if state.get('initialization_failed') is True and state.get('native_operation') is None:
        raise startup_error(state)
    if state.get('connected') is not True or any(key not in state for key in IDENTITY_FIELDS):
        raise HostError('SW_OPERATION_UNKNOWN','The original connect is still starting or unconfirmed; no new connect was sent',True)
    verify_state(state,snapshot)
    return {key:state[key] for key in IDENTITY_FIELDS}


def windows_identity():
    if os.name != 'nt':
        raise HostError('SW_WINDOWS_REQUIRED', 'SOLIDWORKS desktop automation requires Windows')
    kernel, advapi = windows_libraries()
    token = wintypes.HANDLE()
    if not advapi.OpenProcessToken(kernel.GetCurrentProcess(), 8, ctypes.byref(token)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        container, length = wintypes.DWORD(), wintypes.DWORD()
        if not advapi.GetTokenInformation(token, 29, ctypes.byref(container), ctypes.sizeof(container), ctypes.byref(length)):
            raise ctypes.WinError(ctypes.get_last_error())
        if container.value:
            raise HostError('SW_USER_CONTEXT_REQUIRED', '请在当前登录用户的本机上下文运行SOLIDWORKS连接；AppContainer无法共用桌面COM与管道')
        needed = wintypes.DWORD()
        advapi.GetTokenInformation(token, 1, None, 0, ctypes.byref(needed))
        buf = ctypes.create_string_buffer(needed.value)
        if not advapi.GetTokenInformation(token, 1, buf, needed, ctypes.byref(needed)):
            raise ctypes.WinError(ctypes.get_last_error())
        sid = ctypes.cast(buf, ctypes.POINTER(ctypes.c_void_p))[0]
        text = wintypes.LPWSTR()
        if not advapi.ConvertSidToStringSidW(ctypes.c_void_p(sid), ctypes.byref(text)):
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            sid_text = text.value
        finally:
            kernel.LocalFree(ctypes.cast(text, wintypes.HLOCAL))
        session = wintypes.DWORD()
        if not kernel.ProcessIdToSessionId(os.getpid(), ctypes.byref(session)):
            raise ctypes.WinError(ctypes.get_last_error())
        username = ctypes.create_unicode_buffer(256)
        length = wintypes.DWORD(256)
        if not advapi.GetUserNameW(username, ctypes.byref(length)):
            raise ctypes.WinError(ctypes.get_last_error())
        if 'codexsandbox' in username.value.casefold() or username.value.casefold().startswith('codex_sandbox'):
            raise HostError('SW_USER_CONTEXT_REQUIRED', '请在当前登录用户的本机上下文接入 SOLIDWORKS')
        return sid_text, session.value
    finally:
        kernel.CloseHandle(token)


def process_observation(pid):
    """Return gone only for a proven missing process, never access denied."""
    if not isinstance(pid, int) or isinstance(pid, bool) or pid <= 0:
        return dict(status='unknown')
    kernel, _ = windows_libraries()
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        return dict(status='gone' if ctypes.get_last_error() == 87 else 'unknown')
    try:
        exit_code = wintypes.DWORD()
        if not kernel.GetExitCodeProcess(wintypes.HANDLE(handle), ctypes.byref(exit_code)):
            return dict(status='unknown')
        if exit_code.value != 259:
            return dict(status='gone')
        creation, exit_time, kernel_time, user_time = (wintypes.FILETIME() for _ in range(4))
        if not kernel.GetProcessTimes(wintypes.HANDLE(handle), ctypes.byref(creation), ctypes.byref(exit_time), ctypes.byref(kernel_time), ctypes.byref(user_time)):
            return dict(status='unknown')
        name = ctypes.create_unicode_buffer(32768)
        length = wintypes.DWORD(len(name))
        if not kernel.QueryFullProcessImageNameW(wintypes.HANDLE(handle), 0, name, ctypes.byref(length)):
            return dict(status='unknown')
        ticks = (creation.dwHighDateTime << 32) + creation.dwLowDateTime + 504911232000000000
        return dict(status='alive', pid=pid, process_start_ticks=str(ticks), executable=name.value)
    finally:
        kernel.CloseHandle(wintypes.HANDLE(handle))


def window_observation(hwnd):
    """Read only the already-bound native frame; never enumerate or adopt one."""
    if not isinstance(hwnd, int) or isinstance(hwnd, bool) or hwnd <= 0 or hwnd > 0x7fffffffffffffff:
        return dict(status='unknown')
    user = ctypes.WinDLL('user32', use_last_error=True)
    user.IsWindow.argtypes = [wintypes.HWND]
    user.IsWindow.restype = wintypes.BOOL
    user.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user.GetWindowThreadProcessId.restype = wintypes.DWORD
    if not user.IsWindow(wintypes.HWND(hwnd)):
        return dict(status='gone')
    owner = wintypes.DWORD()
    if not user.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(owner)):
        return dict(status='unknown')
    return dict(status='alive', hwnd=hwnd, pid=owner.value)


def secure_directory(directory, sid):
    directory.mkdir(parents=True, exist_ok=True)
    kernel, advapi = windows_libraries()
    descriptor = ctypes.c_void_p()
    sddl = 'D:P(A;OICI;FA;;;' + sid + ')(A;OICI;FA;;;SY)'
    if not advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl, 1, ctypes.byref(descriptor), None):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        if not advapi.SetFileSecurityW(str(directory), 0x80000004, descriptor):
            raise ctypes.WinError(ctypes.get_last_error())
    finally:
        kernel.LocalFree(descriptor)


def private_home():
    sid, session = windows_identity()
    digest = hashlib.sha256((sid + ':' + str(session)).encode()).hexdigest()[:24]
    base = os.environ.get('LOCALAPPDATA')
    if not base or not Path(base).is_absolute():
        raise HostError('SW_USER_CONTEXT_REQUIRED', 'The current local application-data directory is unavailable')
    home = Path(base) / 'YanLabs' / ('SolidWorksHost-v2-' + digest)
    for candidate in (home, *home.parents):
        if candidate.is_symlink() or candidate.exists() and hasattr(candidate, 'is_junction') and candidate.is_junction():
            raise HostError('SW_HOST_SCOPE_INVALID', 'Linked host directories are not allowed')
    return home, 'YanLabs-SolidWorks-v2-' + digest, sid, session


def read_state(home):
    file = home / 'state.json'
    if not file.is_file():
        return dict(ok=True, connected=False, status='not_started', busy=False, native_operation=None)
    try:
        # The STA host replaces this exact file atomically. Windows can briefly
        # refuse a reader while the replacement holds its sharing lock. Retry
        # only this read, never a connect, pipe request, backup or CAD operation.
        # Parsing is outside the retry: readable malformed state stays unknown.
        for attempt in range(5):
            try:
                encoded = file.read_text(encoding='utf-8-sig')
                break
            except OSError:
                if attempt == 4:
                    raise
                time.sleep(.05)
        state = json.loads(encoded)
        if not isinstance(state, dict):
            raise ValueError('Invalid host state object')
        host_id = state.get('host_id')
        if state.get('status') == 'starting' and state.get('native_operation') is None and isinstance(host_id, str):
            try:
                if str(uuid.UUID(host_id, version=4)) != host_id:
                    return state
                terminal_file = home / ('startup-' + host_id + '-failure.json')
                if terminal_file.is_file():
                    terminal = json.loads(terminal_file.read_text(encoding='utf-8-sig'))
                    same = isinstance(terminal, dict) and all(terminal.get(key) == state.get(key) for key in ('host_id','host_pid','host_process_start_ticks','source_sha256'))
                    known_failure = same and terminal.get('execution_not_started') is True and terminal.get('status') == 'failed' and terminal.get('busy') is False
                    retained_launch = same and terminal.get('cad_execution_not_started') is True and terminal.get('native_launch_may_have_occurred') is True and terminal.get('status') == 'unknown' and terminal.get('busy') is True
                    if same and terminal.get('initialization_failed') is True and (known_failure or retained_launch) and terminal.get('native_operation') is None:
                        return terminal
            except (ValueError, OSError):
                pass
        return state
    except (OSError, ValueError):
        raise HostError('SW_OPERATION_UNKNOWN', '宿主状态暂时无法读取；原请求保留，不自动启动或重放', True) from None


def original_process_gone(observed, original_ticks):
    """A different birth proves the original exited; access denied never does."""
    return (isinstance(original_ticks, str) and original_ticks.isdecimal() and
            (observed.get('status') == 'gone' or observed.get('status') == 'alive' and
             isinstance(observed.get('process_start_ticks'), str) and
             observed['process_start_ticks'].isdecimal() and observed['process_start_ticks'] != original_ticks))


def archive_departed_unknown(home, state, host, native):
    """Preserve an unresolved predecessor before a separately authorized connect.

    This is not an outcome resolver: no old task, operation receipt or billing
    record is changed. Both original process births must be positively absent.
    The caller holds the same-login launcher mutex throughout this transition.
    """
    try:
        host_id = state['host_id']
        valid_id = isinstance(host_id, str) and str(uuid.UUID(host_id, version=4)) == host_id
        valid_identity = (valid_id and all(isinstance(state.get(key), int) and not isinstance(state.get(key), bool) and state[key] > 0 for key in ('host_pid','pid','hwnd')))
        if not valid_identity or not original_process_gone(host, state.get('host_process_start_ticks')) or not original_process_gone(native, state.get('process_start_ticks')):
            raise ValueError('Both original process births must be proven absent')
        source = home / 'state.json'
        if source.is_symlink() or source.stat().st_size > 4*1024*1024:
            raise ValueError('The original canonical state is not a bounded regular file')
        original = source.read_bytes()
        if json.loads(original.decode('utf-8-sig')) != state:
            raise ValueError('The original canonical state changed before archival')
        digest = hashlib.sha256(original).hexdigest()
        parent = home / 'departed-identities'
        target = parent / (host_id + '-' + digest)
        for candidate in (parent, target):
            if candidate.is_symlink() or candidate.exists() and hasattr(candidate, 'is_junction') and candidate.is_junction():
                raise ValueError('Linked predecessor archives are not allowed')
            candidate.mkdir(exist_ok=True)
        # Exclusive creation never replaces an earlier archive or partial file.
        # A retry may only reuse byte-identical state plus a verified proof.
        state_file = target / 'state.json'
        if state_file.exists():
            if state_file.is_symlink() or state_file.read_bytes() != original:
                raise ValueError('The immutable predecessor snapshot differs')
        else:
            with state_file.open('xb') as stream:
                stream.write(original);stream.flush();os.fsync(stream.fileno())
        proof_file = target / 'departure-proof.json'
        identity = {key: state[key] for key in IDENTITY_FIELDS}
        proof = dict(schema_version=1, archived_at=datetime.now(timezone.utc).isoformat(),
                     state_sha256=digest, original_identity=identity,
                     original_status=state.get('status'), original_busy=state.get('busy'),
                     original_native_operation=state.get('native_operation'),
                     host_observation=host, native_observation=native,
                     original_outcome='unresolved_preserved', billing_resolution='not_assessed',
                     task_replayed=False, permits='independent_explicit_connection_only')
        if proof_file.exists():
            if proof_file.is_symlink():raise ValueError('Linked predecessor proof is not allowed')
            saved=json.loads(proof_file.read_text(encoding='utf-8'))
            for key in ('schema_version','state_sha256','original_identity','original_status','original_busy','original_native_operation','original_outcome','billing_resolution','task_replayed','permits'):
                if saved.get(key) != proof[key]:raise ValueError('The immutable predecessor proof differs')
            if not original_process_gone(saved.get('host_observation',{}),state['host_process_start_ticks']) or not original_process_gone(saved.get('native_observation',{}),state['process_start_ticks']):
                raise ValueError('The predecessor proof does not establish both departures')
        else:
            encoded=(json.dumps(proof,ensure_ascii=True,sort_keys=True,indent=2)+'\n').encode('utf-8')
            with proof_file.open('xb') as stream:
                stream.write(encoded);stream.flush();os.fsync(stream.fileno())
        if source.read_bytes() != original:
            raise ValueError('The canonical state changed during predecessor archival')
        return dict(path=str(target.relative_to(home)),state_sha256=digest,
                    proof_sha256=hashlib.sha256(proof_file.read_bytes()).hexdigest(),
                    original_outcome='unresolved_preserved')
    except (OSError,ValueError,KeyError,TypeError):
        raise HostError('SW_OPERATION_UNKNOWN', '旧连接及任务尚不能完整归档；未创建新连接，原请求与费用状态保留', True) from None


def verify_state(state, snapshot, required=True):
    if state.get('source_sha256') and state['source_sha256'] != snapshot['sha256']:
        raise HostError('SW_HOST_UPGRADE_REQUIRED', 'SOLIDWORKS连接仍由旧版宿主持有；请正常交还连接后显式重新接入')
    if not state.get('host_id'):
        if required:
            raise HostError('SW_RECONNECT_REQUIRED', '尚无持久SOLIDWORKS连接，请先点击接入；本次未启动软件')
        return False
    host = process_observation(state.get('host_pid'))
    native = process_observation(state.get('pid'))
    if host['status'] != 'alive' or host.get('process_start_ticks') != state.get('host_process_start_ticks'):
        if state.get('busy'):
            raise HostError('SW_OPERATION_UNKNOWN', '原宿主已离线且任务状态未决；保留原请求，不重放', True)
        if required:
            raise HostError('SW_RECONNECT_REQUIRED', '原SOLIDWORKS宿主已退出，请显式重新接入；本次未启动软件')
        return False
    if native['status'] != 'alive' or native.get('process_start_ticks') != state.get('process_start_ticks'):
        if native['status'] == 'unknown':
            raise HostError('SW_OPERATION_UNKNOWN', '原SOLIDWORKS进程身份暂时无法核对；原任务保留', True)
        raise HostError('SW_RECONNECT_REQUIRED', '原SOLIDWORKS实例已退出或改变，请显式重新接入；本次未启动软件')
    frame = window_observation(state.get('hwnd'))
    if frame['status'] != 'alive' or frame.get('pid') != state.get('pid'):
        if frame['status'] == 'unknown' or state.get('busy'):
            raise HostError('SW_OPERATION_UNKNOWN', '原SOLIDWORKS主窗口或任务状态尚不能确认；原请求保留，不重绑或重放', True)
        raise HostError('SW_RECONNECT_REQUIRED', '原SOLIDWORKS主窗口已退出或改变，请显式重新接入；本次未启动软件')
    return True


def powershell_environment(script, request):
    powershell = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
    environment = os.environ.copy()
    module_path = environment.get('PSMODULEPATH', '')
    environment['PSMODULEPATH'] = str(powershell.parent / 'Modules') + (os.pathsep + module_path if module_path else '')
    environment.update(YANLABS_SOLIDWORKS_SCRIPT=str(script.resolve()), YANLABS_SOLIDWORKS_REQUEST=str(request.resolve()))
    # A safely quoted, inert resource marker lets the installer identify this
    # system PowerShell as belonging to its exact installation target. It is
    # never model/workspace text; Windows argv carries this Unicode as UTF-16.
    marker = "'" + str(script.resolve()).replace("'", "''") + "'"
    command = "$ErrorActionPreference='Stop'; $yanlabsSolidworksResource=" + marker + "; if([IO.Path]::GetFullPath($env:YANLABS_SOLIDWORKS_SCRIPT) -cne $yanlabsSolidworksResource){throw 'Native resource marker mismatch'}; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); & ([scriptblock]::Create([IO.File]::ReadAllText($env:YANLABS_SOLIDWORKS_SCRIPT,[Text.Encoding]::UTF8))) -RequestPath $env:YANLABS_SOLIDWORKS_REQUEST"
    return [str(powershell), '-NoLogo', '-NoProfile', '-NonInteractive', '-Sta', '-Command', command], environment


def pipe_request(home, pipe_name, envelope):
    # Authenticated bytes stay only in the owner-restricted local pipe. Never put
    # this transport token into the model request, stdout or durable run ledger.
    token = (home / 'auth.key').read_text(encoding='ascii')
    body = json.dumps(dict(envelope, auth=token), ensure_ascii=True, separators=(',', ':')).encode('ascii') + b'\n'
    if len(body) > 2*1024*1024:
        raise HostError('SW_HOST_REQUEST_INVALID', 'Native host request exceeds its transport bound')
    kernel, _ = windows_libraries()
    pipe_path = '\\\\.\\pipe\\' + pipe_name
    deadline = time.monotonic() + 30
    last_error = 0
    while not kernel.WaitNamedPipeW(pipe_path, 250):
        last_error = ctypes.get_last_error()
        if time.monotonic() >= deadline:
            raise HostError('SW_OPERATION_UNKNOWN', '原宿主通信尚未就绪（Win32 ' + str(last_error) + '）；原请求保留，不启动另一实例', True)
        time.sleep(.02)
    try:
        with open(pipe_path, 'r+b', buffering=0) as pipe:
            offset = 0
            while offset < len(body):
                written = pipe.write(body[offset:])
                if not written:
                    raise HostError('SW_OPERATION_UNKNOWN', '原生请求通道中断；不在另一实例重试', True)
                offset += written
            response = bytearray()
            while not response.endswith(b'\n'):
                chunk = pipe.read(8192)
                if not chunk or len(response) + len(chunk) > 4*1024*1024:
                    raise HostError('SW_OPERATION_UNKNOWN', '原生回执通信中断；保留原请求，不重放', True)
                response.extend(chunk)
            return json.loads(response.decode('utf-8-sig'))
    except (OSError, ValueError):
        raise HostError('SW_OPERATION_UNKNOWN', '原生回执尚不能确认；保留原请求，不重放', True) from None


def start_host(home, pipe_name, sid, session, snapshot, script, intent=None):
    kernel, _ = windows_libraries()
    mutex = kernel.CreateMutexW(None, False, 'Local\\' + pipe_name + '-launcher')
    if not mutex:
        raise ctypes.WinError(ctypes.get_last_error())
    owned = False
    try:
        owned = kernel.WaitForSingleObject(wintypes.HANDLE(mutex), 0) in (0, 0x80)
        if not owned:
            raise HostError('SW_HOST_BUSY', '同一登录会话的SOLIDWORKS宿主正在接入，请核对原接入')
        state = read_state(home)
        predecessor_archive = None
        if state.get('host_id'):
            host = process_observation(state.get('host_pid'))
            if state.get('busy') or state.get('status') == 'unknown':
                native = process_observation(state.get('pid'))
                if original_process_gone(host,state.get('host_process_start_ticks')) and original_process_gone(native,state.get('process_start_ticks')):
                    # Explicit connect only, after both original processes ended.
                    # Preserve unknown forever in its immutable predecessor; a
                    # new host cannot adopt, read back or replay that old run.
                    predecessor_archive = archive_departed_unknown(home,state,host,native)
                else:
                    raise HostError('SW_OPERATION_UNKNOWN', '原宿主或SOLIDWORKS仍在运行或身份未决；未创建新连接，原请求保留', True)
            if host['status'] == 'alive' and host.get('process_start_ticks') == state.get('host_process_start_ticks'):
                native = process_observation(state.get('pid'))
                if native['status'] == 'alive' and native.get('process_start_ticks') == state.get('process_start_ticks'):
                    select_connect_host(home,intent,state)
                    return state
                if state.get('busy') or native['status'] == 'unknown':
                    raise HostError('SW_OPERATION_UNKNOWN', '原实例身份或任务状态未决，不能替换宿主或重放', True)
                # This path is reachable only from explicit connect. Retire the
                # old empty connection after a proven native exit; never ask it
                # to create a replacement application on a model's command.
                expected = {key: state[key] for key in IDENTITY_FIELDS}
                reply = pipe_request(home, pipe_name, dict(operation_id=str(uuid.uuid4()),
                    source_sha256=state['source_sha256'], expected_identity=expected, payload=dict(operation='disconnect')))
                if reply.get('host_retired') is not True:
                    raise HostError('SW_RECONNECT_REQUIRED', '原宿主尚未正常交还，未创建另一个连接')
                deadline = time.monotonic() + 10
                while time.monotonic() < deadline and process_observation(state['host_pid'])['status'] != 'gone':
                    time.sleep(.05)
                if process_observation(state['host_pid'])['status'] != 'gone':
                    raise HostError('SW_HOST_BUSY', '原宿主仍在正常释放，请稍后显式接入')
            if state.get('busy') and predecessor_archive is None:
                raise HostError('SW_OPERATION_UNKNOWN', '原宿主退出前仍有未决任务，不自动重建或重放', True)
        secure_directory(home, sid)
        ensure_auth_key(home)
        config = dict(operation='host', host_id=str(uuid.uuid4()), host_home=str(home), pipe_name=pipe_name,
                      windows_sid=sid, windows_session=session, source_snapshot=snapshot)
        if intent is not None:config['connect_intent']=intent
        if predecessor_archive is not None:config['independent_predecessor_archive']=predecessor_archive
        request = home / ('startup-' + config['host_id'] + '.json')
        request.write_text(json.dumps(config, ensure_ascii=True), encoding='utf-8')
        select_connect_host(home,intent,dict(host_id=config['host_id']),request)
        args, environment = powershell_environment(script, request)
        log = (home / ('host-' + config['host_id'] + '.log')).open('ab')
        try:
            child = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                creationflags=subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP, close_fds=True, env=environment)
        finally:
            log.close()
        deadline = time.monotonic() + 180
        while time.monotonic() < deadline:
            state = read_state(home)
            if state.get('host_id') == config['host_id'] and state.get('status') not in ('starting', 'checking'):
                if state.get('connected'):
                    return state
                raise startup_error(state)
            if child.poll() is not None:
                raise HostError('SW_HOST_START_FAILED', 'SOLIDWORKS持久宿主未能启动，请检查本机启动回执')
            time.sleep(.1)
        raise HostError('SW_OPERATION_UNKNOWN', 'SOLIDWORKS宿主仍在启动，保留原接入，不重复启动', True)
    finally:
        if owned:
            kernel.ReleaseMutex(wintypes.HANDLE(mutex))
        kernel.CloseHandle(wintypes.HANDLE(mutex))


def request_host(payload, script):
    home, pipe_name, sid, session = private_home()
    snapshot = source_snapshot(script.parent)
    operation = payload['operation']
    intent=None
    if payload.get('connect_intent') is not None:
        if operation not in ('connect','status'):
            raise HostError('SW_CONNECT_INTENT_INVALID','A connect intent is valid only for explicit connect and read-only recovery')
        intent=connect_intent(payload['connect_intent'],snapshot)
        if operation=='connect':
            secure_directory(home,sid)
            connect_proof_write(home,intent,'intent.json',intent)
        else:
            recovered=recover_connect_identity(home,intent,snapshot,sid,session)
            if payload.get('connection_identity') is not None and payload['connection_identity']!=recovered:
                raise HostError('SW_CONNECT_INTENT_INVALID','The original connect proof conflicts with an accepted identity')
            payload=dict(payload,connection_identity=recovered)
    state = read_state(home)
    if payload.get('connection_identity') is not None and state.get('host_id'):
        expected = {key: state.get(key) for key in IDENTITY_FIELDS}
        if payload['connection_identity'] != expected:
            raise HostError('SW_RECONNECT_REQUIRED', '原请求绑定的SOLIDWORKS宿主已改变；未交还或操作新的连接')
    if operation == 'connect':
        state = start_host(home, pipe_name, sid, session, snapshot, script,intent) if intent is not None else start_host(home,pipe_name,sid,session,snapshot,script)
    if operation == 'status' and not state.get('host_id'):
        return state
    if operation == 'disconnect' and not state.get('host_id'):
        return dict(ok=True, connected=False, status='not_started', busy=False, native_operation=None,
                    noop=True, host_retired=False, host_only=True, application_closed=False)
    if operation in ('status', 'disconnect') and state.get('status') == 'retired' and process_observation(state.get('host_pid'))['status'] == 'gone':
        return dict(ok=True, connected=False, status='not_started', busy=False, native_operation=None,
                    noop=True, host_retired=False, host_already_gone=True, host_only=True, application_closed=False)
    if operation == 'disconnect':
        host = process_observation(state.get('host_pid'))
        gone = host['status'] == 'gone' or host['status'] == 'alive' and host.get('process_start_ticks') != state.get('host_process_start_ticks')
        if gone and not state.get('busy') and state.get('status') != 'unknown':
            return dict(ok=True, connected=False, status='not_started', busy=False, native_operation=None,
                        noop=True, host_retired=False, host_already_gone=True, host_only=True, application_closed=False)
        if host['status'] != 'alive' or host.get('process_start_ticks') != state.get('host_process_start_ticks'):
            raise HostError('SW_OPERATION_UNKNOWN', '原宿主退出状态未能确认，未关闭或启动任何软件', True)
    else:
        verify_state(state, snapshot)
    if operation == 'status' and state.get('busy'):
        return dict(state,connect_id=intent['connect_id']) if intent is not None else state
    if state.get('busy') and not (operation == 'readback' and payload.get('run_id') == (state.get('native_operation') or {}).get('run_id')):
        raise HostError('SW_HOST_BUSY', '原SOLIDWORKS操作仍在运行或核对中，请检查原请求', state.get('status') == 'unknown')
    expected = {key: state[key] for key in IDENTITY_FIELDS}
    if payload.get('connection_identity') and payload['connection_identity'] != expected:
        raise HostError('SW_RECONNECT_REQUIRED', '原请求绑定的SOLIDWORKS实例已经改变；不在新实例重放原操作')
    receipt=pipe_request(home, pipe_name, dict(operation_id=str(uuid.uuid4()), source_sha256=state['source_sha256'] if operation == 'disconnect' else snapshot['sha256'],
                       expected_identity=expected, payload=payload))
    if intent is not None:receipt=dict(receipt,connect_id=intent['connect_id'],connect_recovered=operation=='status')
    return receipt
