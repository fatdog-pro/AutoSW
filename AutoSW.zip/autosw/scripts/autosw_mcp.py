"""Newline-delimited stdio MCP; no HTTP, third-party SDK, sampling or shell."""
import json
import queue
import threading

from autosw_runtime import AutoSWError, is_unknown

MODERN = '2026-07-28'
LEGACY = ('2025-11-25','2025-06-18','2025-03-26','2024-11-05')
INFO = {'name':'autosw','title':'AutoSW','version':'0.2.0'}
CAPABILITIES = {'tools':{'listChanged':False}}
INSTRUCTIONS = ('Use one fixed project workspace. Explicit connect alone may start or attach SOLIDWORKS. '
    'Unknown operations retain their original run; use status/readback, never replay them. '
    'Keep one visible owned main document. For assemblies create the root first; create parts hidden and model in context. '
    'On failure do not disconnect/reconnect, change workspace, launch SLDWORKS/COM yourself or restart a whole assembly blindly. '
    'No UI automation, arbitrary shell, secrets, or unscoped file access is available.')


def schema(properties=None, required=()):
    return {'type':'object','properties':properties or {},'required':list(required),'additionalProperties':False}


def string(maximum=500, **kwargs):
    return dict(type='string',minLength=1,maxLength=maximum,**kwargs)


RUN = string(36,pattern=r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$')
HASH = string(64,pattern=r'^[0-9a-f]{64}$')
TOOLS = [
    ('catalog','Show frozen bridge and actual capability boundaries; no CAD call.',schema()),
    ('connect','Explicitly attach/start the single native SOLIDWORKS session. Never use to recover an unknown run.',schema()),
    ('status','Inspect the accepted native identity and outstanding original run; never starts CAD.',schema()),
    ('api','Read installed official API signatures in the accepted session.',schema({'type_name':string(200),'member':string(200)},('type_name',))),
    ('write_script','Write a reviewed C# Build method body only under sources/. Does not execute it.',schema({
        'path':string(),'source':string(1048576),'expected_sha256':HASH},('path','source'))),
    ('run_script','Execute the exact accepted source hash once for a stable intent key; native original run is durable.',schema({
        'path':string(),'source_sha256':HASH,'operation_key':string(96,pattern=r'^[A-Za-z0-9][A-Za-z0-9_.-]{0,95}$')},
        ('path','source_sha256','operation_key'))),
    ('readback','Reconcile/read the registered original run; never repeat its model or bind a replacement session.',schema({'run_id':RUN},('run_id',))),
    ('open','Open only a completed run’s recorded native artifact in its original accepted session.',schema({'run_id':RUN,'artifact':string()},('run_id',))),
    ('input_inspect','Read identity/hash of a CAD/image/drawing deliberately placed in inputs/. No screen OCR or model modification.',schema({'path':string()},('path',))),
    ('cleanup','Normally close only a completed or known-failed run’s owned saved documents. Unknown work is blocked; no file deletion or application close.',schema({'run_id':RUN},('run_id',))),
    ('disconnect','Normally retire the idle accepted host; preserves SOLIDWORKS and user documents. Rejects unknown work.',schema())]
DEFINITIONS = [{'name':'autosw_'+name,'description':description,'inputSchema':spec,
                'annotations':{'readOnlyHint':name in ('catalog','status','api','input_inspect'),
                    'destructiveHint':False,'idempotentHint':name not in ('connect','write_script','run_script','open','cleanup'),
                    'openWorldHint':False}} for name,description,spec in TOOLS]
BY_NAME = {item['name']:item for item in DEFINITIONS}


class ProtocolError(Exception):
    def __init__(self, code, message, data=None):
        self.code,self.message,self.data = code,message,data


def validate_arguments(spec, arguments):
    import re
    if not isinstance(arguments,dict) or set(arguments)-set(spec['properties']) or any(
            key not in arguments for key in spec['required']):
        raise ProtocolError(-32602,'Invalid tool arguments')
    for key,value in arguments.items():
        rule = spec['properties'][key]
        if not isinstance(value,str) or not rule['minLength']<=len(value)<=rule['maxLength'] or \
                ('pattern' in rule and not re.fullmatch(rule['pattern'],value)):
            raise ProtocolError(-32602,'Invalid argument: '+key)


class Server:
    def __init__(self, runtime):
        self.runtime = runtime
        self.legacy_version,self.initialized = None,False

    def _era(self, method, params):
        meta = params.get('_meta',{})
        if not isinstance(meta,dict):
            raise ProtocolError(-32602,'Invalid _meta')
        version = meta.get('io.modelcontextprotocol/protocolVersion')
        if version is not None:
            if version!=MODERN:
                raise ProtocolError(-32022,'Unsupported protocol version',{'supported':[MODERN,*LEGACY],'requested':version})
            if not isinstance(meta.get('io.modelcontextprotocol/clientCapabilities'),dict):
                raise ProtocolError(-32602,'Missing required per-request clientCapabilities')
            return True
        if method=='initialize':
            return False
        if method=='server/discover' or not self.legacy_version:
            raise ProtocolError(-32602,'Modern requests require protocolVersion and clientCapabilities in params._meta')
        if not self.initialized and method!='ping':
            raise ProtocolError(-32600,'Send notifications/initialized before using tools')
        return False

    def process(self, request):
        request_id = request.get('id') if isinstance(request,dict) else None
        notification = isinstance(request,dict) and 'id' not in request and request.get('jsonrpc')=='2.0' and isinstance(request.get('method'),str)
        try:
            if not isinstance(request,dict) or request.get('jsonrpc')!='2.0' or not isinstance(request.get('method'),str) or \
                any(key not in ('jsonrpc','id','method','params') for key in request) or \
                not notification and (isinstance(request_id,bool) or not isinstance(request_id,(str,int)) or
                    isinstance(request_id,int) and abs(request_id)>=2**53):
                raise ProtocolError(-32600,'Invalid JSON-RPC request')
            params = request.get('params',{})
            if not isinstance(params,dict):
                raise ProtocolError(-32602,'Parameters must be an object')
            method = request['method']
            if notification:
                if method=='notifications/initialized' and self.legacy_version:
                    self.initialized = True
                return None
            modern = self._era(method,params)
            if method=='initialize':
                if modern or self.legacy_version:
                    raise ProtocolError(-32600,'Initialize is supported once for legacy protocol only')
                if not isinstance(params.get('protocolVersion'),str) or not isinstance(params.get('capabilities'),dict) or \
                        not isinstance(params.get('clientInfo'),dict) or not all(
                            isinstance(params['clientInfo'].get(k),str) for k in ('name','version')):
                    raise ProtocolError(-32602,'Invalid initialize parameters')
                self.legacy_version = params['protocolVersion'] if params['protocolVersion'] in LEGACY else LEGACY[0]
                result = dict(protocolVersion=self.legacy_version,capabilities=CAPABILITIES,serverInfo=INFO,instructions=INSTRUCTIONS)
            elif method=='server/discover':
                if set(params)-{'_meta'}:
                    raise ProtocolError(-32602,'Discovery has no method parameters')
                result = dict(supportedVersions=[MODERN,*LEGACY],capabilities=CAPABILITIES,instructions=INSTRUCTIONS)
            elif method=='ping':
                result = {}
            elif method=='tools/list':
                if set(params)-{'_meta','cursor'} or params.get('cursor') not in (None,''):
                    raise ProtocolError(-32602,'Invalid tools cursor or parameters')
                result = {'tools':DEFINITIONS}
            elif method=='tools/call':
                if set(params)-{'_meta','name','arguments'}:
                    raise ProtocolError(-32602,'Unexpected tool call fields')
                name = params.get('name')
                if not isinstance(name,str) or name not in BY_NAME:
                    raise ProtocolError(-32602,'Unknown AutoSW tool')
                arguments = params.get('arguments',{})
                validate_arguments(BY_NAME[name]['inputSchema'],arguments)
                try:
                    output = getattr(self.runtime,name[len('autosw_'):])(**arguments)
                except AutoSWError as error:
                    output = dict(ok=False,code=error.code,error=str(error))
                except Exception:
                    output = dict(ok=False,code='AUTOSW_EXECUTOR_ERROR',error='Executor did not confirm completion; inspect the original run')
                result = dict(content=[{'type':'text','text':json.dumps(output,ensure_ascii=True,separators=(',',':'))}],
                              structuredContent=output,isError=output.get('ok') is not True or
                                  name in ('autosw_run_script','autosw_readback','autosw_open','autosw_cleanup') and is_unknown(output))
                if not modern and self.legacy_version in ('2024-11-05','2025-03-26'):
                    result.pop('structuredContent')
            else:
                raise ProtocolError(-32601,'Method not found')
            if modern:
                result.update(resultType='complete',_meta={'io.modelcontextprotocol/serverInfo':INFO})
            return {'jsonrpc':'2.0','id':request_id,'result':result}
        except ProtocolError as error:
            if notification:
                return None
            body = dict(code=error.code,message=error.message)
            if error.data is not None:
                body['data'] = error.data
            safe_id = request_id if not isinstance(request_id,bool) and isinstance(request_id,(str,int)) else None
            return {'jsonrpc':'2.0','id':safe_id,'error':body}


def serve(runtime, input_stream, output_stream):
    """Read while the sole worker serializes tools. Cancellation never kills CAD.

    A cancelled active native request may finish in its persistent host. Its durable
    original run remains recoverable; the cancelled RPC receives no later message.
    EOF returns promptly without quitting SW or starting replacement work.
    """
    server = Server(runtime)
    guard = threading.Lock()
    active,cancelled = set(),set()
    closed = threading.Event()
    messages = queue.Queue(maxsize=128)

    def emit(value):
        if value is not None and not closed.is_set():
            output_stream.write(json.dumps(value,ensure_ascii=True,separators=(',',':'))+'\n')
            output_stream.flush()

    def work(message, token):
        with guard:
            skip = token in cancelled or closed.is_set()
        response = None if skip else server.process(message)
        with guard:
            if token not in cancelled:
                emit(response)
            active.discard(token); cancelled.discard(token)

    def worker():
        while not closed.is_set():
            item = messages.get()
            if item is None:
                return
            work(*item)

    threading.Thread(target=worker,name='AutoSW',daemon=True).start()

    try:
        while not closed.is_set():
            try:
                line = input_stream.readline(2*1024*1024+1)
            except UnicodeError:
                emit({'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Messages must be UTF-8'}})
                break
            if not line:
                break
            if len(line)>2*1024*1024 or not line.endswith('\n'):
                emit({'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Message exceeds 2 MiB or is not newline-delimited'}})
                if len(line)>2*1024*1024:
                    break
                continue
            try:
                message = json.loads(line,parse_constant=lambda value:(_ for _ in ()).throw(ValueError(value)))
            except (ValueError,UnicodeError):
                emit({'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Invalid JSON'}}); continue
            if isinstance(message,dict) and message.get('jsonrpc')=='2.0' and 'id' not in message and \
                    message.get('method')=='notifications/cancelled':
                cancel_id = message.get('params',{}).get('requestId') if isinstance(message.get('params',{}),dict) else None
                if not isinstance(cancel_id,bool) and isinstance(cancel_id,(str,int)):
                    with guard:
                        if cancel_id in active:
                            cancelled.add(cancel_id)
                continue
            token = message.get('id') if isinstance(message,dict) else None
            if isinstance(token,bool) or not isinstance(token,(str,int)):
                token = object()  # malformed IDs/notifications never alias a real pending ID
            if not isinstance(token,bool) and isinstance(token,(str,int)):
                with guard:
                    if token in active:
                        emit({'jsonrpc':'2.0','id':token,'error':{'code':-32600,'message':'Request ID is already active'}})
                        continue
                    active.add(token)
            try:
                messages.put_nowait((message,token))
            except queue.Full:
                with guard:
                    active.discard(token)
                if isinstance(message,dict) and 'id' in message:
                    emit({'jsonrpc':'2.0','id':token,'error':{'code':-32603,'message':'AutoSW serial queue is full; no native request dispatched'}})
    finally:
        closed.set()
        try:
            messages.put_nowait(None)
        except queue.Full:
            pass
