// AutoSW concept launch vehicle. Metres/radians; aesthetic CAD, no flight/engine design.
// Author: 抖音 萌猪过河. Execute as the AutoSW Build method body.
string[] names={"MainShell","UpperShell","Transition","VentedInterstage","AvionicsCollar","AftSkirt","EngineMount","FairingHalf","BoosterBand","UpperBand","EngineBell","SweptFin","Raceway","ServicePanel","FlangeBolt"};
var parts=new List<IModelDoc2>();
double[][] profiles={
 new double[]{.442,0,.45,0,.45,3.05,.442,3.05},
 new double[]{.393,0,.4,0,.4,1.28,.393,1.28},
 new double[]{.434,0,.45,0,.4,.18,.384,.18},
 new double[]{.384,0,.4,0,.4,.20,.384,.20},
 new double[]{.392,0,.408,0,.408,.024,.4,.024,.4,.116,.408,.116,.408,.14,.392,.14},
 new double[]{.449,0,.47,0,.47,.025,.462,.025,.462,.215,.467,.215,.467,.24,.449,.24},
 new double[]{0,0,.43,0,.43,.03,0,.03},
 null,
 new double[]{.449,0,.458,0,.458,.042,.449,.042},
 new double[]{.399,0,.407,0,.407,.035,.399,.035},
 null,
 new double[]{.446,.08,.90,.02,.77,.30,.446,.72},
 new double[]{-.018,0,.018,0,.023,.025,.023,2.125,.018,2.15,-.018,2.15,-.023,2.125,-.023,.025},
 new double[]{.4505,0,.4595,0,.4595,.22,.4505,.22},
 new double[]{0,0,.004,0,.004,.012,.010,.012,.010,.023,.007,.026,0,.026}
};
double[][] colors={
 new double[]{.93,.95,.97},new double[]{.95,.96,.98},new double[]{.67,.70,.75},
 new double[]{.23,.27,.33},new double[]{.70,.73,.77},new double[]{.24,.28,.34},
 new double[]{.31,.35,.41},new double[]{.97,.97,.95},new double[]{.19,.24,.30},
 new double[]{.25,.30,.36},new double[]{.49,.35,.22},new double[]{.75,.11,.10},
 new double[]{.21,.25,.30},new double[]{.78,.81,.84},new double[]{.62,.66,.70}
};
// One visible main document; parts are created without their own windows.
var a=ctx.NewAssembly("AutoSW_Detailed_Rocket");ctx.Save(a);
IComponent2 root=null;double[] origin=null;
var display=(IModelDocExtension)a.Extension;
if(!display.SetUserPreferenceToggle((int)swUserPreferenceToggle_e.swDisplayOrigins,0,false)||!display.SetUserPreferenceToggle((int)swUserPreferenceToggle_e.swDisplayCoordSystems,0,false))throw new Exception("Cannot hide owned-document reference markers");
var instances=new List<double[]>();
// part index, rotation around Y, translation X/Y/Z, all in model units.
instances.Add(new double[]{1,0,0,3.43,0});instances.Add(new double[]{2,0,0,3.05,0});
instances.Add(new double[]{3,0,0,3.23,0});instances.Add(new double[]{4,0,0,4.71,0});
instances.Add(new double[]{5,0,0,0,0});instances.Add(new double[]{6,0,0,0,0});
instances.Add(new double[]{7,0,0,4.85,0});instances.Add(new double[]{7,Math.PI,0,4.85,0});
foreach(double y in new double[]{.15,1.05,2.92})instances.Add(new double[]{8,0,0,y,0});
foreach(double y in new double[]{3.50,4.63})instances.Add(new double[]{9,0,0,y,0});
instances.Add(new double[]{10,0,0,0,0});
for(int j=0;j<4;j++){double t=j*Math.PI/2;instances.Add(new double[]{10,0,.27*Math.Cos(t),0,.27*Math.Sin(t)});}
for(int j=0;j<4;j++)instances.Add(new double[]{11,j*Math.PI/2,0,0,0});
for(int j=0;j<2;j++){double t=Math.PI/4+j*Math.PI;instances.Add(new double[]{12,t,.449*Math.Sin(t),.35,.449*Math.Cos(t)});}
for(int j=0;j<4;j++)instances.Add(new double[]{13,j*Math.PI/2,0,1.70,0});
for(int j=0;j<16;j++){double t=2*Math.PI*j/16;instances.Add(new double[]{14,0,.451*Math.Cos(t),.19,.451*Math.Sin(t)});}
for(int k=0;k<names.Length;k++){
 var p=ctx.NewPart(names[k],false);parts.Add(p);if(p.Visible)throw new Exception("A background part became visible: "+names[k]);
 ctx.Save(p);ctx.Activate(a);var seed=ctx.AddComponent(a,p,0,0,0);
 if(k==0){root=seed;origin=(double[])root.Transform2.ArrayData;}
 a.ClearSelection2(true);if(!seed.Select4(false,null,false))throw new Exception("Cannot select the owned in-context component");
 int editInfo=0;int editCode=((IAssemblyDoc)a).EditPart2(true,false,ref editInfo);if(editCode!=0)throw new Exception("Cannot enter native part edit: "+editCode);
 var editTarget=(IModelDoc2)((IAssemblyDoc)a).GetEditTarget();if(editTarget==null||editTarget.GetPathName()!=p.GetPathName())throw new Exception("In-context edit target mismatch");
 Feature front=(Feature)p.FirstFeature();while(front!=null&&front.GetTypeName2()!="RefPlane")front=(Feature)front.GetNextFeature();
 if(front==null||!((Feature)seed.GetCorresponding(front)).Select2(false,0))throw new Exception("Missing native front plane: "+names[k]);
 var sk=a.SketchManager;bool oldAdd=sk.AddToDB,oldDisplay=sk.DisplayWhenAdded;
 try{sk.AddToDB=true;sk.DisplayWhenAdded=true;sk.InsertSketch(true);
 if(k==7){
  sk.CreateLine(.412,0,0,.42,0,0);sk.CreateLine(.42,0,0,.42,.20,0);
  sk.Create3PointArc(.42,.20,0,0,1.45,0,.323397577929,.825,0);
  sk.CreateLine(0,1.45,0,0,1.435,0);
  sk.Create3PointArc(0,1.435,0,.412,.20,0,.317127157009,.8175,0);
  sk.CreateLine(.412,.20,0,.412,0,0);
 }else if(k==10){
  sk.Create3PointArc(.040,0,0,.105,-.32,0,.061,-.16,0);
  sk.CreateLine(.105,-.32,0,.100,-.32,0);
  sk.Create3PointArc(.100,-.32,0,.035,0,0,.056,-.16,0);
  sk.CreateLine(.035,0,0,.040,0,0);
 }else{
  var q=profiles[k];for(int j=0;j<q.Length;j+=2){int n=(j+2)%q.Length;sk.CreateLine(q[j],q[j+1],0,q[n],q[n+1],0);}
 }
 ISketchSegment axis=null;if(k!=11&&k!=12)axis=sk.CreateCenterLine(0,-.5,0,0,4,0);
 sk.InsertSketch(true);Feature profile=null;for(var f=(Feature)p.FirstFeature();f!=null;f=(Feature)f.GetNextFeature())if(f.GetTypeName2()=="ProfileFeature")profile=f;
 a.ClearSelection2(true);if(profile==null||!((Feature)seed.GetCorresponding(profile)).Select2(false,0))throw new Exception("Profile not selected: "+names[k]);
 Feature created=null;
 if(k==11||k==12){
  double depth=k==11?.014:.023;int end=k==11?6:0;
  created=a.FeatureManager.FeatureExtrusion3(true,false,false,end,0,depth,0,false,false,false,false,0,0,false,false,false,false,true,false,true,0,0,false);
 }else{
  var sd=((ISelectionMgr)a.SelectionManager).CreateSelectData();sd.Mark=4;
  if(axis==null||!axis.Select4(true,sd))throw new Exception("Revolve axis missing: "+names[k]);
  double angle=k==7?Math.PI:(k==13?.42:2*Math.PI);
  created=a.FeatureManager.FeatureRevolve2(true,true,false,false,false,false,0,0,angle,0,false,false,0,0,0,0,0,true,true,true);
 }
 if(created==null)throw new Exception("Native base feature failed: "+names[k]);created.Name=names[k]+"_Base";a.GraphicsRedraw2();a.ViewZoomtofit2();
 // The vent cuts are features, not painted black rectangles.
 if(k==3){
  a.ClearSelection2(true);if(!((Feature)seed.GetCorresponding(front)).Select2(false,0))throw new Exception("Vent plane selection");sk.InsertSketch(true);
  for(int j=0;j<4;j++){double x=-.30+j*.20;sk.CreateCornerRectangle(x-.05,.04,0,x+.05,.16,0);}
  sk.InsertSketch(true);profile=null;for(var f=(Feature)p.FirstFeature();f!=null;f=(Feature)f.GetNextFeature())if(f.GetTypeName2()=="ProfileFeature")profile=f;
  a.ClearSelection2(true);if(profile==null||!((Feature)seed.GetCorresponding(profile)).Select2(false,0))throw new Exception("Vent profile selection");
  var cut=a.FeatureManager.FeatureCut4(false,false,false,1,1,0,0,false,false,false,false,0,0,false,false,false,false,false,false,true,false,false,false,0,0,false,false);
  if(cut==null)throw new Exception("Interstage through windows failed");cut.Name="EightThroughVentWindows";a.GraphicsRedraw2();
 }
 // A second, merged revolve makes the nozzle attachment flange editable.
 if(k==10){
  a.ClearSelection2(true);if(!((Feature)seed.GetCorresponding(front)).Select2(false,0))throw new Exception("Bell flange plane");sk.InsertSketch(true);
  sk.CreateCornerRectangle(.035,0,0,.070,.025,0);axis=sk.CreateCenterLine(0,-.5,0,0,.5,0);sk.InsertSketch(true);
  profile=null;for(var f=(Feature)p.FirstFeature();f!=null;f=(Feature)f.GetNextFeature())if(f.GetTypeName2()=="ProfileFeature")profile=f;
  a.ClearSelection2(true);if(profile==null||!((Feature)seed.GetCorresponding(profile)).Select2(false,0))throw new Exception("Bell flange profile");var sd=((ISelectionMgr)a.SelectionManager).CreateSelectData();sd.Mark=4;
  if(!axis.Select4(true,sd))throw new Exception("Bell flange axis");var flange=a.FeatureManager.FeatureRevolve2(true,true,false,false,false,false,0,0,2*Math.PI,0,false,false,0,0,0,0,0,true,true,true);
  if(flange==null)throw new Exception("Bell flange revolve failed");flange.Name="ThroatAttachmentFlange";a.GraphicsRedraw2();
 }
 }finally{sk.DisplayWhenAdded=oldDisplay;sk.AddToDB=oldAdd;((IAssemblyDoc)a).EditAssembly();}
 var color=colors[k];p.MaterialPropertyValues=new double[]{color[0],color[1],color[2],.8,.8,.25,.3,0,0};
 p.ForceRebuild3(false);var bodies=((IPartDoc)p).GetBodies2(0,false) as Array;
 if(bodies==null||bodies.Length!=1)throw new Exception("Expected one connected solid: "+names[k]);
 var mass=(double[])((IBody2)bodies.GetValue(0)).GetMassProperties(1000);
 if(mass[3]<=0)throw new Exception("Empty native body: "+names[k]);
 if(k==0&&Math.Abs(mass[3]-Math.PI*(.45*.45-.442*.442)*3.05)>1e-8)throw new Exception("Main shell native volume disagrees with dimensions");
 ctx.Measure(names[k]+".native_part_box",(IPartDoc)p,"IPartDoc","GetPartBox",true);
 ctx.Save(p);

 if(p.Visible)throw new Exception("Background part has an independent visible window: "+names[k]);
 ctx.Measure(names[k]+".independent_window_visible",p,"IModelDoc2","get_Visible");
 ctx.Activate(a);
 bool firstInstance=true;
for(int i=0;i<instances.Count;i++){
 var v=instances[i];int index=(int)v[0];if(index!=k)continue;double c=Math.Cos(v[1]),s=Math.Sin(v[1]);
 var component=firstInstance?seed:ctx.AddComponent(a,parts[index],v[2],v[3],v[4]);firstInstance=false;
 var target=new double[]{c,0,-s,0,1,0,s,0,c,origin[9]+v[2],origin[10]+v[3],origin[11]+v[4],1,0,0,0};
 var tr=(MathTransform)ctx.MathUtility.CreateTransform(target);if(!component.SetTransformAndSolve2(tr))throw new Exception("Native component placement failed: "+i);
 a.ClearSelection2(true);var sd=((ISelectionMgr)a.SelectionManager).CreateSelectData();sd.Mark=1;
 if(!root.Select4(false,sd,false)||!component.Select4(true,sd,false)||((ISelectionMgr)a.SelectionManager).GetSelectedObjectCount2(-1)!=2)throw new Exception("Native lock selection failed: "+i);
 var raw=((IAssemblyDoc)a).CreateMateData((int)swMateType_e.swMateLOCK);var mate=(Feature)((IAssemblyDoc)a).CreateMate(raw);
 if(mate==null)throw new Exception("Native lock mate failed: "+i+" code="+((IMateFeatureData)raw).ErrorStatus);
 mate.Name="Lock_"+names[index]+"_"+i;
 var actual=(double[])component.Transform2.ArrayData;for(int j=0;j<13;j++)if(Math.Abs(actual[j]-target[j])>1e-7)throw new Exception("Mate changed intended placement: "+i);
 if(component.GetConstrainedStatus()!=3)throw new Exception("Component not fully constrained: "+i);
 a.ClearSelection2(true);a.GraphicsRedraw2();a.ViewZoomtofit2();
}

 a.GraphicsRedraw2();a.ViewZoomtofit2();
 if(!a.Visible)throw new Exception("The assembly must remain visible");
}
a.ClearSelection2(true);a.ForceRebuild3(false);ctx.Save(a);
ctx.Measure("rocket.native_component_count",(IAssemblyDoc)a,"IAssemblyDoc","GetComponentCount",false);
ctx.Note("concept","Author: 抖音 萌猪过河. Concept launch vehicle, editable CAD only; not a certified or functional propulsion design.");
ctx.Note("nominal_dimensions","6.62 m overall, 0.90 m main body diameter, four 14 mm thick swept fins; 15 distinct parts, 45 components, 44 native Lock mates.");
ctx.Note("source_units","metres and radians; Y is the rocket longitudinal axis");
ctx.Measure("rocket.main_window_visible",a,"IModelDoc2","get_Visible");
ctx.Measure("rocket.native_assembly_box",(IAssemblyDoc)a,"IAssemblyDoc","GetBox",0);
ctx.SetMainDocument(a);ctx.Export(a,"step");
