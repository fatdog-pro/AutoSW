// Synthetic acceptance: millimetres from the supplied dimensioned drawing are converted to metres.
var a=ctx.NewAssembly("CarrierAndPin");
var carrier=ctx.NewPart("Carrier");ctx.Activate(carrier);
var fp=(Feature)carrier.FirstFeature();while(fp!=null&&fp.GetTypeName2()!="RefPlane")fp=(Feature)fp.GetNextFeature();
if(fp==null||!fp.Select2(false,0))throw new Exception("Carrier reference plane selection failed");
var sk=carrier.SketchManager;sk.InsertSketch(true);sk.CreateCornerRectangle(-0.05,-0.03,0,0.05,0.03,0);sk.InsertSketch(true);
var thickness=carrier.FeatureManager.FeatureExtrusion3(true,false,false,0,0,0.01,0,false,false,false,false,0,0,false,false,false,false,true,true,false,0,0,false);
if(thickness==null)throw new Exception("Carrier extrusion failed");thickness.Name="CarrierThickness";
carrier.ClearSelection2(true);if(!fp.Select2(false,0))throw new Exception("Hole plane selection failed");sk.InsertSketch(true);sk.CreateCircleByRadius(-0.02,0,0,0.005);sk.CreateCircleByRadius(0.02,0,0,0.005);sk.InsertSketch(true);
var holes=carrier.FeatureManager.FeatureCut4(true,false,true,1,1,0.01,0.01,false,false,false,false,0,0,false,false,false,false,false,true,true,false,false,false,0,0,false,false);
if(holes==null)throw new Exception("Two through holes failed");holes.Name="TwoThroughHoles";ctx.ReadDimension("carrier.thickness.m",((IDisplayDimension)thickness.GetFirstDisplayDimension()).GetDimension2(0));ctx.Save(carrier);
var pin=ctx.NewPart("Pin");ctx.Activate(pin);var pp=(Feature)pin.FirstFeature();while(pp!=null&&pp.GetTypeName2()!="RefPlane")pp=(Feature)pp.GetNextFeature();
if(pp==null||!pp.Select2(false,0))throw new Exception("Pin reference plane selection failed");pin.SketchManager.InsertSketch(true);pin.SketchManager.CreateCircleByRadius(0,0,0,0.0045);pin.SketchManager.InsertSketch(true);
var length=pin.FeatureManager.FeatureExtrusion3(true,false,false,0,0,0.03,0,false,false,false,false,0,0,false,false,false,false,true,true,false,0,0,false);
if(length==null)throw new Exception("Pin extrusion failed");length.Name="PinLength";ctx.ReadDimension("pin.length.m",((IDisplayDimension)length.GetFirstDisplayDimension()).GetDimension2(0));ctx.Save(pin);
ctx.Activate(a);var bc=ctx.AddComponent(a,carrier,0,0,0);var pc=ctx.AddComponent(a,pin,0.02,0,0);
if(bc==null||pc==null)throw new Exception("Assembly component insertion failed");ctx.Save(a);
string[] bp=new string[3],ppn=new string[3];int bi=0,pi=0;for(var f=(Feature)carrier.FirstFeature();f!=null&&bi<3;f=(Feature)f.GetNextFeature())if(f.GetTypeName2()=="RefPlane")bp[bi++]=f.Name;for(var f=(Feature)pin.FirstFeature();f!=null&&pi<3;f=(Feature)f.GetNextFeature())if(f.GetTypeName2()=="RefPlane")ppn[pi++]=f.Name;
if(bi!=3||pi!=3)throw new Exception("Actual component reference planes unavailable");
for(int i=0;i<3;i++){
 a.ClearSelection2(true);string first=bp[i]+"@"+bc.GetSelectByIDString(),second=ppn[i]+"@"+pc.GetSelectByIDString();
 if(!a.Extension.SelectByID2(first,"PLANE",0,0,0,false,1,null,0)||!a.Extension.SelectByID2(second,"PLANE",0,0,0,true,1,null,0))throw new Exception("Native mate plane selection failed "+i);
 int err=0;var mate=((IAssemblyDoc)a).AddMate5(i==2?5:0,0,false,i==2?0.02:0,0,0,1,1,0,0,0,false,false,0,out err);
 if(mate==null||err!=(int)swAddMateError_e.swAddMateError_NoError||mate.GetMateEntityCount()!=2)throw new Exception("Native mate failed "+i+" code "+err);
 if(i==2){var dimension=((IDisplayDimension)mate.DisplayDimension).GetDimension2(0);ctx.ReadDimension("assembly.pin_offset.m",dimension);}
}
a.ClearSelection2(true);a.ForceRebuild3(false);ctx.Measure("pin.native_constraint_status",pc,"IComponent2","GetConstrainedStatus");ctx.Measure("pin.transform",pc.Transform2,"IMathTransform","get_ArrayData");
a.ShowNamedView2("",1);a.NameView("QAFront");a.ShowNamedView2("",7);a.NameView("QAIso");ctx.Save(a);
var d=ctx.NewDrawing("CarrierAndPinDrawing");ctx.AddDrawingView(d,a,"QAFront",0.12,0.12,0.5);ctx.AddDrawingView(d,a,"QAIso",0.27,0.12,0.5);ctx.Save(d);ctx.SetMainDocument(a);ctx.Export(a,"step");
