# 脚本上下文

`write-script` 的输入是 `void Build(YanLabsSWContext ctx)` 的 **方法体**，不包含 `using`、类、`Main` 或其他入口。桥自动提供 `System`、`System.Collections.Generic`、官方 `sldworks`/`swconst` 命名空间；`cosworks` 只在本机实际安装时提供。脚本经本机 C# 编译器及执行边界检查，不是任意系统程序。

下表来自同包冻结的 `bridge/general-api.cs`。`ctx` 是本桥受控门面；`IModelDoc2`、`IAssemblyDoc` 等对象的具体厂商方法，仍须用 `api --type ... --member ...` 查询本机实际接口。

| 成员 | 用途 |
| --- | --- |
| `IModelDoc2 NewPart(string name)` | 新建本 run 零件；首文档显示，已有主文档时默认后台 |
| `IModelDoc2 NewPart(string name, bool visible)` | 新建本 run 零件；`false` 后台创建，需使用下方装配内在位编辑流程建模 |
| `IModelDoc2 NewAssembly(string name)` | 新建本 run 装配；首文档显示，后续默认后台 |
| `IModelDoc2 NewDrawing(string name)` | 使用本机有效模板新建工程图；已有主文档时默认后台，通过 ctx 明确切换 |
| `IModelDoc2 OpenInput(string workspaceRelativePath)` | 复制用户提供的 CAD 及引用后编辑，保留源 SHA |
| `IModelDoc2 OpenOwned(string workspaceRelativePath)` | 复制本会话已登记的上一版成果及依赖 |
| `IModelDoc2 CurrentDocument` | 当前受控主文档 |
| `IMathUtility MathUtility` | 原生几何变换工具工厂 |
| `void Activate(IModelDoc2 document)` | 切换唯一的本会话前台文档；先收起已核对所有权的旧显示，不关闭文档 |
| `void SetMainDocument(IModelDoc2 document)` | 指定本次主项目 |
| `string Save(IModelDoc2 document)` | 保存原生文件并检查状态 |
| `string Export(IModelDoc2 document, string extension)` | 导出当前明确显示的本 run 文档；后台文档不会被导出操作偷偷激活 |
| `IComponent2 AddComponent(IModelDoc2 assembly, IModelDoc2 component, double x, double y, double z)` | 添加本次已保存的组件，位置单位米 |
| `IView AddDrawingView(IModelDoc2 drawing, IModelDoc2 model, string viewName, double x, double y, double scale)` | 添加本次已保存模型的原生视图，位置单位米 |
| `double ReadDimension(string label, IDimension dimension)` | 读取实际 `SystemValue` 并登记尺寸证据 |
| `object Measure(string label, object nativeEntity, string apiType, string member, params object[] arguments)` | 调用真实只读 getter 并登记原生数值/状态 |
| `void Note(string key, string value)` | 辅助说明，不能作为测量证明 |
| `object GetSimulationAddin()` | 获取实际插件对象，不单独证明许可 |
| `Dictionary<string,object> CreateSimulationMesh(object study, int meshUnits, double elementSize, double tolerance)` | 在本 run 目录生成真实网格，正尺寸/容差按所选原生单位 |
| `Dictionary<string,object> RunSimulationStudy(object study)` | 受控求解并读回默认位移结果；须真实许可 |
| `Dictionary<string,object> RunSimulationStudy(object study, string quantity, int component, int step, int unit)` | 指定结果种类及原生分量/步/单位的受控求解 |

`name` 使用不超过 80 字符的普通字母、数字、下划线、空格或连字符。文档新建失败时检查模板和真实诊断，不在脚本中另建应用实例。输出原生格式为 SLDPRT、SLDASM、SLDDRW；导出扩展可使用 step/stp、iges/igs、x_t/x_b、stl、pdf、dxf/dwg，是否能由当前文档导出须看实际回执。

`OpenInput`/`OpenOwned` 处理原生 SLDPRT/SLDASM/SLDDRW，以及 STEP/STP、IGES/IGS、X_T/X_B、STL 输入副本。PDF、图片、DXF/DWG 在 `input-inspect` 中可检查文件身份，并不意味着这些文件可直接传给 `OpenInput`；图纸内容由宿主先解析后生成官方 API 建模逻辑。

多轮修改只在新 run 中编辑副本。原生输入通过官方 Pack and Go 复制并重映射工作区内引用，交换格式先复制再导入；不要在输入文件本身调用保存。保留实际 `input_copies` 的映射、复制前后 SHA 和原件未变证据，不用一句“已备份”代替。

不能直接调用文件系统、进程、网络、反射、宏、应用生命周期或另建 COM 对象。包含文件路径的新文档、打开、保存、组件和视图创建操作使用 `ctx`，不能借原生对象返回的应用接口绕过它。配合与一般几何 API 在取得受控文档后直接按官方签名使用；`ctx.AddComponent` 只放入组件，不自动创建配合。

脚本结束时桥保存并按依赖处理 owned 文档，确认卸载后只盘开主项目，避免逐次测试留下大量文档窗口。原生输出完整路径受 SOLIDWORKS 自身长度约束；过深时选更短项目目录，不反复同路径重试或更改 Windows 全局策略。

辅助文档注册不再改变 `CurrentDocument`；主项目由首个文档或 `SetMainDocument` 明确确定。新建、输入副本打开和盘开均先隐藏创建，再执行单前台切换；类型创建标记在 finally 恢复。脚本不能直接设置 `IModelDoc*.Visible` 或调用 `IModelView.Activate` 绕过上下文。普通相机、实体选择与几何 API 仍可使用。

同一宿主中已知失败/先前运行的旧显示也按实际 COM 身份、账户会话、运行目录、路径与类型核对后收起，不保存或关闭其修改。未知 COM 失败不触发后续整理；拒绝重复提交旧 run 时也不会对旧模型再次操作。实际可见性记录在本 run 的 `general-native-visibility.json`，失败整理单独记录，不将隐藏当成卸载。

## 后台零件与装配内在位编辑

用户未要求单独展示零件时，主装配保持前台，用 `ctx.NewPart(name, false)` 创建后台空零件，`ctx.Save(part)` 后通过 `ctx.AddComponent` 加入主装配。不要为了造几何逐件 `ctx.Activate(part)`；直接在隐藏零件上调用草图几何方法在本机曾出现 RPC 错误。

本机已验证的小型流程是：选择主装配中的目标组件，调用装配的 `EditPart2(true, false, ref info)` 并检查返回结果，通过 `GetEditTarget` 核对实际编辑目标就是该零件，再用**主装配文档**的 `SketchManager` 和 `FeatureManager` 创建草图、特征。若编辑目标不符，停止本次操作，不能继续向其他文档写入。完成后调用 `EditAssembly` 返回装配并保存。实际选择、特征参数和返回值仍按本机官方 API 签名处理。

已验证的矩形拉伸使用 `FeatureExtrusion3`，其中 `UseFeatScope=false`、`UseAutoSelect=true`。最终 [火箭源码](../examples/rocket.cs) 进一步实测了在位旋转、拉伸与贯通切除，并在草图中使用 `AddToDB=true` 精确创建模式、`finally` 恢复旧草图设置和退出在位编辑。它们是该冻结示例共同验证的操作组合，不能据此省略其他特征的作用范围与轮廓检查，也不能将 `AddToDB` 写成此前所有失败的唯一根因。主装配在特征或部件完成后 `GraphicsRedraw2` 更新可见模型，隐藏零件保持后台。

2026-11-01 小型原生运行 `1632a4f5-c290-445b-be03-bddb28c4a44f` 读回隐藏零件 `Visible=false`、实体体积 `6e-6 m³`，主项目保存后磁盘重开通过。随后完整火箭运行 `290cfadf-d500-4793-8cbc-4fa44546a9ee` 验收 15 种零件、45 个组件、44 个 Lock 配合、零特征错误和主装配磁盘重开；官方只读检查为 15 个隐藏零件和 1 个可见装配，详见 [火箭摘要](rocket-baseline.json)。这不证明隐藏零件直接建模、所有特征或任意模型均可成功。装配加载的必要引用仍会占用内存；一个可见主装配不等于总文档数只能为 1。

## 读回与错误状态

读回须分清：当前加载对象的结构、保存前后的结构快照、真正盘开的主项目、引用组件，以及实际图纸刷新后保存。具体判断和验证见[工作流](workflow.md)。

错误码按对应官方枚举解释，不能一律把非零当失败。例如 AddMate5 的 swAddMateError_NoError 为 1；请查询本机枚举并用枚举成员比较。ReferenceType2 属于 swSelectType_e，不能混用旧的 mate-geometry 枚举。

ReadDimension 会在最终保存后刷新当前原生数值；要证明修改前的值，应在改动前对实际 SystemValue 做明确检查并保存独立来源/哈希基线，不要把同一个可变 IDimension 的两个标签当作前后快照。
