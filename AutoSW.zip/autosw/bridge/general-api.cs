using System;
using System.Collections;
using System.Collections.Generic;
using System.CodeDom.Compiler;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using Microsoft.CSharp;
using SolidWorks.Interop.sldworks;

// The host compiles this fixed resource to a real, private DLL. Model source is
// only a Build method body and is checked before any native call is dispatched.
public interface IYanLabsSWModel { void Build(YanLabsSWContext ctx); }

public sealed class YanLabsSWOwnedDocument {
    public IModelDoc2 Document;
    public string Path, Name, Owner, Run;
    public int Kind;
    internal Dictionary<string,object> SavedStructure;
}

internal sealed class YanLabsSWScopedSimulation {
    public object Study;
    public string Directory;
}

internal sealed class YanLabsSWFileDigest {
    public string Sha256;
    public long Length, LastWriteTicks;
}

public sealed class YanLabsSWRunState {
    public string Workspace, Directory, Binding, Owner, SourceHash;
    public bool Executed, Completed, NativeStarted;
    public YanLabsSWOwnedDocument Main;
    public readonly List<YanLabsSWOwnedDocument> Documents = new List<YanLabsSWOwnedDocument>();
    public readonly List<Dictionary<string,object>> Exports = new List<Dictionary<string,object>>();
    public readonly Dictionary<string,string> Notes = new Dictionary<string,string>();
    public readonly List<Dictionary<string,object>> Simulations = new List<Dictionary<string,object>>();
    public readonly List<Dictionary<string,object>> SimulationMeshes = new List<Dictionary<string,object>>();
    public readonly List<string> Dependencies = new List<string>();
    public readonly List<Dictionary<string,object>> Measurements = new List<Dictionary<string,object>>();
    public readonly List<Action> MeasurementRefresh = new List<Action>();
    internal readonly List<string> ClosedForVerification = new List<string>();
    internal readonly List<Dictionary<string,object>> DirtyObservations = new List<Dictionary<string,object>>();
    internal readonly List<Dictionary<string,object>> NativeSaveEvents = new List<Dictionary<string,object>>();
    internal Dictionary<string,object> LastDirtyObservation, LastNativeSaveEvent;
    internal int DirtyObservationCount, NativeSaveCount;
    internal readonly Dictionary<string,string> SourceInputHashes = new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
    internal readonly List<Dictionary<string,object>> InputCopies = new List<Dictionary<string,object>>();
    internal readonly List<YanLabsSWScopedSimulation> SimulationScopes = new List<YanLabsSWScopedSimulation>();
}

public sealed class YanLabsSWContext {
    private readonly ISldWorks app;
    private readonly YanLabsSWRunState state;
    private readonly Dictionary<string,object> session;
    public bool NativeStarted { get { return state.NativeStarted; } }
    public IModelDoc2 CurrentDocument { get { if(state.Main==null)throw new InvalidOperationException("Create or open an owned document first");return state.Main.Document; } }
    public string OutputDirectory { get { return state.Directory; } }
    public IMathUtility MathUtility { get { Native("obtain_native_geometry_math_utility");return (IMathUtility)app.GetMathUtility(); } }
    internal YanLabsSWContext(ISldWorks application,YanLabsSWRunState run,Dictionary<string,object> owned) { app=application;state=run;session=owned; }
    private void Native(string stage) { state.NativeStarted=true;YanLabsSWGeneral.SetStage(stage); }
    private static string Label(string name) {
        if(String.IsNullOrWhiteSpace(name)||name.Length>80||!Regex.IsMatch(name,@"^[\p{L}\p{N}_ -]+$"))throw new ArgumentException("Use a short, plain document name");
        return name.Trim().Replace(' ','_');
    }
    private static void MeasurementLabel(string label) {
        if(String.IsNullOrWhiteSpace(label)||label.Length>160)throw new ArgumentException("Use a nonempty measurement label of at most 160 characters", "label");
        foreach(char character in label)if(Char.IsControl(character))throw new ArgumentException("Measurement labels must not contain control characters", "label");
    }
    private string Target(string name,int kind) {
        string extension=kind==1?".sldprt":kind==2?".sldasm":kind==3?".slddrw":null;
        if(extension==null)throw new ArgumentException("Unsupported native document kind");
        string file=Path.Combine(state.Directory,Label(name)+"-"+Path.GetFileName(state.Directory)+extension);
        YanLabsSWGeneral.CheckPathLength(file);return file;
    }
    private YanLabsSWOwnedDocument Owned(IModelDoc2 document) {
        if(document==null)throw new ArgumentNullException("document");
        foreach(YanLabsSWOwnedDocument item in state.Documents)if(YanLabsSWGeneral.SameObject(item.Document,document))return item;
        throw new InvalidOperationException("Only a document created or copied by this run may be changed");
    }
    private IModelDoc2 Register(IModelDoc2 document,string target,string name) {
        if(document==null)throw new InvalidOperationException("SOLIDWORKS did not create the requested document; check its default template");
        int kind=document.GetType();
        if(kind<1||kind>3)throw new InvalidOperationException("Unsupported native document type");
        foreach(YanLabsSWOwnedDocument item in state.Documents)if(YanLabsSWGeneral.SameObject(item.Document,document))throw new InvalidOperationException("The factory returned a document already owned by another operation");
        var owned=new YanLabsSWOwnedDocument{Document=document,Path=target,Name=name,Kind=kind,Owner=state.Owner,Run=state.Directory};
        state.Documents.Add(owned);session[target]=owned;state.Main=owned;
        YanLabsSWGeneral.WriteJournal(state,"document_registered");return document;
    }
    public IModelDoc2 NewPart(string name) {
        string target=Target(name,1);if(File.Exists(target))throw new InvalidOperationException("A native output already exists; it will not be overwritten");
        Native("create_part");return Register((IModelDoc2)app.NewPart(),target,name);
    }
    public IModelDoc2 NewPart(string name,bool visible) {
        string target=Target(name,1);if(File.Exists(target))throw new InvalidOperationException("A native output already exists; it will not be overwritten");
        Native("create_part_with_explicit_visibility");bool previous=app.GetDocumentVisible(1);
        try {
            // This factory flag affects only parts created while it is set.
            // Existing documents and the visible assembly are left untouched.
            app.DocumentVisible(visible,1);return Register((IModelDoc2)app.NewPart(),target,name);
        } finally {app.DocumentVisible(previous,1);}
    }
    public IModelDoc2 NewAssembly(string name) {
        string target=Target(name,2);if(File.Exists(target))throw new InvalidOperationException("A native output already exists; it will not be overwritten");
        Native("create_assembly");return Register((IModelDoc2)app.NewAssembly(),target,name);
    }
    public IModelDoc2 NewDrawing(string name) {
        string target=Target(name,3);if(File.Exists(target))throw new InvalidOperationException("A native output already exists; it will not be overwritten");
        Native("create_drawing");return Register((IModelDoc2)app.NewDrawing(0),target,name);
    }
    public void SetMainDocument(IModelDoc2 document) { state.Main=Owned(document);Activate(document); }
    public void Activate(IModelDoc2 document) {
        YanLabsSWGeneral.SetStage("validate_owned_document_activation");
        Owned(document);Native("activate_owned_document");int error=0;
        IModelDoc2 actual=(IModelDoc2)app.ActivateDoc3(document.GetTitle(),false,0,ref error);
        if(error!=0||actual==null||!YanLabsSWGeneral.SameObject(actual,document))throw new InvalidOperationException("The owned document could not be activated");
    }
    public string Save(IModelDoc2 document) {
        var item=Owned(document);YanLabsSWGeneral.CheckPathLength(item.Path);
        if(item.Kind==2)return SaveAssemblyScope(document);
        if(File.Exists(item.Path)&&!YanLabsSWGeneral.SamePath(document.GetPathName(),item.Path))throw new InvalidOperationException("The output belongs to another document and will not be overwritten");
        Native("save_owned_document");document.ForceRebuild3(false);int error=0,warning=0;
        bool saved=((IModelDocExtension)document.Extension).SaveAs(item.Path,0,1,null,ref error,ref warning);
        if(!saved||error!=0||!File.Exists(item.Path)||document.GetSaveFlag()||!YanLabsSWGeneral.SamePath(document.GetPathName(),item.Path))throw new InvalidOperationException("Native project save failed: "+error);
        YanLabsSWGeneral.WriteJournal(state,"document_saved");return item.Path;
    }
    private List<YanLabsSWOwnedDocument> AdoptAssemblyDependencies(IModelDoc2 document) {
        var root=Owned(document);if(root.Kind!=2)throw new ArgumentException("Assembly dependency adoption requires an owned assembly");
        Native("validate_owned_assembly_save_dependencies");var scope=new List<YanLabsSWOwnedDocument>{root};Array components=((IAssemblyDoc)document).GetComponents(false) as Array;
        if(components==null)return scope;if(components.Length>4096)throw new InvalidOperationException("Native assembly save dependency bound exceeded");
        foreach(object raw in components) {
            IComponent2 component=(IComponent2)raw;IModelDoc2 model=(IModelDoc2)component.GetModelDoc2();if(model==null)throw new InvalidOperationException("An assembly save reference is unresolved; no owned save was attempted");
            string path=model.GetPathName();if(!YanLabsSWGeneral.SamePath(path,component.GetPathName()))throw new InvalidOperationException("Assembly component/document paths differ; no owned save was attempted");
            YanLabsSWOwnedDocument owned=null;foreach(var candidate in state.Documents)if(YanLabsSWGeneral.SameObject(candidate.Document,model)){if(owned!=null&&!Object.ReferenceEquals(owned,candidate))throw new InvalidOperationException("Assembly document registration is ambiguous");owned=candidate;}
            YanLabsSWGeneral.RequireOwnedAssemblyDependency(state,path,owned);
            if(owned==null){int kind=model.GetType();if(kind!=1&&kind!=2)throw new InvalidOperationException("Assembly save dependency has an unsupported native kind");owned=new YanLabsSWOwnedDocument{Document=model,Path=path,Name=Path.GetFileNameWithoutExtension(path),Kind=kind,Owner=state.Owner,Run=state.Directory};state.Documents.Add(owned);session[path]=owned;}
            bool found=false;foreach(var prior in scope)if(YanLabsSWGeneral.SamePath(prior.Path,owned.Path)){if(!YanLabsSWGeneral.SameObject(prior.Document,model))throw new InvalidOperationException("Assembly dependency path refers to different native objects");found=true;break;}if(!found)scope.Add(owned);
        }
        YanLabsSWGeneral.WriteJournal(state,"owned_assembly_dependencies_registered");return scope;
    }
    private List<YanLabsSWOwnedDocument> AssemblyScopeSaveOrder(List<YanLabsSWOwnedDocument> scope) {
        var rows=new List<Dictionary<string,object>>();var paths=new List<string>();
        foreach(var item in scope) {
            Owned(item.Document);var references=new List<string>();
            if(item.Kind==2){Array components=((IAssemblyDoc)item.Document).GetComponents(false) as Array;if(components!=null){if(components.Length>4096)throw new InvalidOperationException("Native assembly save dependency bound exceeded");foreach(object raw in components){string path=((IComponent2)raw).GetPathName();bool found=false;foreach(var child in scope)if(YanLabsSWGeneral.SamePath(child.Path,path)){found=true;break;}if(!found)throw new InvalidOperationException("Assembly save reference is outside the verified owned dependency scope");references.Add(path);}}}
            rows.Add(new Dictionary<string,object>{{"path",item.Path},{"kind",item.Kind},{"references",references}});paths.Add(item.Path);
        }
        var result=new List<YanLabsSWOwnedDocument>();foreach(string path in YanLabsSWGeneral.PlanDocumentSave(rows,paths))foreach(var item in scope)if(YanLabsSWGeneral.SamePath(item.Path,path)){result.Add(item);break;}return result;
    }
    private void SavePublicAssemblyDocument(YanLabsSWOwnedDocument item,int pass) {
        Owned(item.Document);YanLabsSWGeneral.CheckPathLength(item.Path);string actual=item.Document.GetPathName();
        if(YanLabsSWGeneral.SamePath(actual,item.Path)&&File.Exists(item.Path)){SaveExistingOwnedDocument(item,pass,"explicit_public_assembly_save");return;}
        if(pass!=1||File.Exists(item.Path))throw new InvalidOperationException("A native assembly-save target would overwrite another document or repeat SaveAs");
        Native("save_new_owned_assembly_target_once");int error=0,warning=0;bool saved=((IModelDocExtension)item.Document.Extension).SaveAs(item.Path,0,1,null,ref error,ref warning);
        string savedPath=item.Document.GetPathName();bool exists=File.Exists(item.Path),dirty=item.Document.GetSaveFlag();
        var record=new Dictionary<string,object>{{"pass",pass},{"phase","explicit_public_assembly_save"},{"method","SaveAs_once"},{"path",item.Path},{"actual_path",savedPath},{"file_exists",exists},{"saved",saved},{"errors",error},{"warnings",warning},{"dirty_after_save",dirty}};state.NativeSaveCount++;state.LastNativeSaveEvent=record;if(state.NativeSaveEvents.Count<128)state.NativeSaveEvents.Add(record);YanLabsSWGeneral.ObserveDirty(state,"after_public_assembly_SaveAs_once");
        // Dirty is an intermediate observation, not a success certificate. The
        // entire proven dependency closure must be clean before Save returns.
        if(!saved||error!=0||!exists||!YanLabsSWGeneral.SamePath(savedPath,item.Path))throw new InvalidOperationException("Native assembly target SaveAs failed: "+error);
    }
    private string SaveAssemblyScope(IModelDoc2 document) {
        var main=Owned(document);var scope=AdoptAssemblyDependencies(document);var ordered=AssemblyScopeSaveOrder(scope);
        Native("rebuild_owned_assembly_save_scope_once");foreach(var item in ordered){item.Document.ForceRebuild3(false);YanLabsSWGeneral.ObserveDirty(state,"after_public_assembly_scope_rebuild");}
        YanLabsSWGeneral.FinalizeSavedReadback(
            delegate(int pass){Native("save_owned_assembly_dependency_scope_pass_"+pass);foreach(var item in ordered)if(pass==1||item.Document.GetSaveFlag())SavePublicAssemblyDocument(item,pass);},
            delegate{},delegate{},delegate{foreach(var item in scope)if(item.Document==null||item.Document.GetSaveFlag()||!YanLabsSWGeneral.SamePath(item.Document.GetPathName(),item.Path)||!File.Exists(item.Path))return false;return true;},3);
        YanLabsSWGeneral.WriteJournal(state,"owned_assembly_scope_saved_clean");return main.Path;
    }
    public string Export(IModelDoc2 document,string extension) {
        var item=Owned(document);string suffix=(extension??"").Trim().TrimStart('.').ToLowerInvariant();
        if(Array.IndexOf(new[]{"step","stp","iges","igs","x_t","x_b","stl","pdf","dxf","dwg"},suffix)<0)throw new ArgumentException("Unsupported CAD export extension");
        Save(document);Activate(document);string output=Path.ChangeExtension(item.Path,suffix);YanLabsSWGeneral.CheckPathLength(output);
        Native("export_"+suffix);document.ClearSelection2(true);int error=0,warning=0;
        bool saved=((IModelDocExtension)document.Extension).SaveAs(output,0,1,null,ref error,ref warning);
        if(!saved||error!=0||!File.Exists(output)||new FileInfo(output).Length==0)throw new InvalidOperationException("Native CAD export failed: "+error);
        state.Exports.Add(new Dictionary<string,object>{{"path",output},{"kind",suffix=="step"||suffix=="stp"?"step":"export"},{"role","export"},{"save_warnings",warning}});
        return output;
    }
    public IComponent2 AddComponent(IModelDoc2 assembly,IModelDoc2 component,double x,double y,double z) {
        var parent=Owned(assembly);var child=Owned(component);
        if(parent.Kind!=2||child.Kind==3)throw new ArgumentException("AddComponent requires an owned assembly and a part/subassembly");
        YanLabsSWGeneral.Finite(x);YanLabsSWGeneral.Finite(y);YanLabsSWGeneral.Finite(z);Save(component);Activate(assembly);Native("add_owned_component");
        IComponent2 result=(IComponent2)((IAssemblyDoc)assembly).AddComponent5(child.Path,0,"",false,"",x,y,z);
        if(result==null)throw new InvalidOperationException("SOLIDWORKS did not add the owned component");return result;
    }
    public IView AddDrawingView(IModelDoc2 drawing,IModelDoc2 model,string viewName,double x,double y,double scale) {
        var target=Owned(drawing);var source=Owned(model);if(target.Kind!=3||source.Kind==3)throw new ArgumentException("A drawing view requires an owned drawing and owned part/assembly");
        if(String.IsNullOrWhiteSpace(viewName)||viewName.Length>160||Regex.IsMatch(viewName,@"[\x00-\x1f]"))throw new ArgumentException("Use an existing native named view, such as *Front, *Top or *Isometric");
        YanLabsSWGeneral.Finite(x);YanLabsSWGeneral.Finite(y);YanLabsSWGeneral.Finite(scale);if(scale<=0||scale>1000)throw new ArgumentException("Drawing scale must be positive and finite");
        Save(model);Activate(drawing);Native("create_owned_model_drawing_view");IView view=(IView)((IDrawingDoc)drawing).CreateDrawViewFromModelView3(source.Path,viewName,x,y,0);
        if(view==null)throw new InvalidOperationException("Native model drawing view creation failed");view.ScaleDecimal=scale;return view;
    }
    public IModelDoc2 OpenOwned(string workspaceRelativePath) {
        string source=YanLabsSWGeneral.WorkspaceFile(state.Workspace,workspaceRelativePath);
        YanLabsSWGeneral.RegisteredOwnedPath(session,source,state.Owner);
        return OpenInputCopy(workspaceRelativePath,"OpenOwned");
    }
    public IModelDoc2 OpenInput(string workspaceRelativePath) {
        return OpenInputCopy(workspaceRelativePath,"OpenInput");
    }
    private IModelDoc2 OpenInputCopy(string workspaceRelativePath,string entryPoint) {
        string source=YanLabsSWGeneral.WorkspaceFile(state.Workspace,workspaceRelativePath),ext=Path.GetExtension(source).ToLowerInvariant();
        int kind=ext==".sldprt"?1:ext==".sldasm"?2:ext==".slddrw"?3:0;
        if(kind==0&&Array.IndexOf(new[]{".step",".stp",".igs",".iges",".x_t",".x_b",".stl"},ext)<0)throw new ArgumentException("Only provided CAD inputs can be imported");
        YanLabsSWGeneral.ProtectSourceInput(state,source);
        var mapping=new List<Dictionary<string,object>>();var evidence=new Dictionary<string,object>{{"entry_point",entryPoint},{"source_project",source},{"copy_method",kind==0?"byte_copy_before_native_import":"native_PackAndGo_reference_remap"},{"source_to_copy_map",mapping},{"copy_completed",false}};state.InputCopies.Add(evidence);YanLabsSWGeneral.VerifySourceInputs(state,"before_copy");
        string inputDirectory=Path.Combine(state.Directory,"copied-inputs");Directory.CreateDirectory(inputDirectory);
        string copy=Path.Combine(inputDirectory,"input-"+Guid.NewGuid().ToString("N")+ext);YanLabsSWGeneral.CheckPathLength(copy);
        var inputBaseline=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(var live in YanLabsSWGeneral.LoadedDocuments(app)){string file=live.GetPathName();if(!String.IsNullOrWhiteSpace(file))inputBaseline.Add(Path.GetFullPath(file));}
        var inputAllowedHere=new HashSet<string>(StringComparer.OrdinalIgnoreCase){Path.GetFullPath(source)};
        var inputLoadedHere=new List<string>();
        Native("copy_and_open_provided_cad");IModelDoc2 openedSource=null;bool openedHere=false;
        try {
            if(kind!=0) {
                openedSource=YanLabsSWGeneral.FindLoaded(app,source);int error=0,warning=0;
                if(openedSource==null){openedSource=(IModelDoc2)app.OpenDoc6(source,kind,1,"",ref error,ref warning);openedHere=true;foreach(var live in YanLabsSWGeneral.LoadedDocuments(app)){string file=live.GetPathName();if(!String.IsNullOrWhiteSpace(file)&&!inputBaseline.Contains(Path.GetFullPath(file)))inputLoadedHere.Add(Path.GetFullPath(file));}}
                if(openedSource==null||error!=0||!YanLabsSWGeneral.SamePath(openedSource.GetPathName(),source)||openedSource.GetSaveFlag())throw new InvalidOperationException("Input project is unavailable, has a different path or has unsaved changes; it was not modified");
                IModelDocExtension extension=(IModelDocExtension)openedSource.Extension;PackAndGo pack=extension.GetPackAndGo();IPackAndGo pg=(IPackAndGo)pack;
                object namesObject;if(!pg.GetDocumentNames(out namesObject))throw new InvalidOperationException("Native Pack and Go did not enumerate references");
                Array names=namesObject as Array;if(names==null||names.Length==0||names.Length>4096)throw new InvalidOperationException("Native dependency list is invalid or too large");
                string[] targets=new string[names.Length];
                for(int index=0;index<names.Length;index++) {
                    string original=Path.GetFullPath(Convert.ToString(names.GetValue(index)));
                    if(!YanLabsSWGeneral.Inside(state.Workspace,original)||!File.Exists(original))throw new InvalidOperationException("Provide the referenced CAD files in this workspace before importing the assembly/drawing");
                    YanLabsSWGeneral.ProtectSourceInput(state,original);
                    inputAllowedHere.Add(original);
                    string target=Path.Combine(inputDirectory,"copy-"+index+"-"+Guid.NewGuid().ToString("N")+Path.GetExtension(original));YanLabsSWGeneral.CheckPathLength(target);targets[index]=target;
                    mapping.Add(new Dictionary<string,object>{{"source",original},{"copy",target},{"source_sha256_before_copy",state.SourceInputHashes[original]},{"native_save_status",null}});
                    if(YanLabsSWGeneral.SamePath(original,source))copy=target;
                }
                YanLabsSWGeneral.ValidateInputCopyMap(state.Workspace,state.Directory,mapping);
                foreach(var live in YanLabsSWGeneral.LoadedDocuments(app))if(inputAllowedHere.Contains(live.GetPathName())&&live.GetSaveFlag())throw new InvalidOperationException("A provided source/reference has unsaved changes; its memory was not copied or saved");
                YanLabsSWGeneral.VerifySourceInputs(state,"before_native_PackAndGo");
                if(!pg.SetDocumentSaveToNames(targets))throw new InvalidOperationException("Native dependency remapping was rejected");
                object configuredNames,configuredStatus;if(!pg.GetDocumentSaveToNames(out configuredNames,out configuredStatus))throw new InvalidOperationException("Native dependency remapping could not be read back");YanLabsSWGeneral.VerifyConfiguredCopyMap(mapping,configuredNames as Array);evidence["native_target_mapping_readback_verified"]=true;
                Array statuses=extension.SavePackAndGo(pack) as Array;
                evidence["native_save_status_count"]=statuses==null?0:statuses.Length;if(statuses!=null)for(int index=0;index<Math.Min(statuses.Length,mapping.Count);index++)mapping[index]["native_save_status"]=Convert.ToInt32(statuses.GetValue(index));
                YanLabsSWGeneral.VerifySourceInputs(state,"after_native_PackAndGo_response");
                if(statuses==null||statuses.Length!=names.Length)throw new InvalidOperationException("Native Pack and Go did not return every reference status");
                for(int index=0;index<statuses.Length;index++)if(Convert.ToInt32(statuses.GetValue(index))!=0||!File.Exists(targets[index]))throw new InvalidOperationException("Native dependency copy failed; source files were retained");
                if(!YanLabsSWGeneral.SamePath(openedSource.GetPathName(),source)||openedSource.GetSaveFlag())throw new InvalidOperationException("Native copying changed the source's in-memory path/dirty state; the source was not saved");
                foreach(var live in YanLabsSWGeneral.LoadedDocuments(app))if(inputAllowedHere.Contains(live.GetPathName())&&live.GetSaveFlag())throw new InvalidOperationException("Native copying left a source/reference dirty; the source was retained, not saved");
                evidence["loaded_source_documents_clean_after_copy"]=true;
                foreach(string target in targets)if(!YanLabsSWGeneral.SamePath(target,copy))state.Dependencies.Add(target);
            } else {mapping.Add(new Dictionary<string,object>{{"source",source},{"copy",copy},{"source_sha256_before_copy",state.SourceInputHashes[source]},{"native_save_status",null}});YanLabsSWGeneral.ValidateInputCopyMap(state.Workspace,state.Directory,mapping);YanLabsSWGeneral.VerifySourceInputs(state,"before_byte_copy");File.Copy(source,copy,false);if(YanLabsSWGeneral.FileHash(copy)!=state.SourceInputHashes[source])throw new InvalidOperationException("Provided input changed during byte copy; no native import was attempted");}
            foreach(var row in mapping){row["copy_sha256_after_creation"]=YanLabsSWGeneral.FileHash(Convert.ToString(row["copy"]));row["source_sha256_after_copy"]=YanLabsSWGeneral.FileHash(Convert.ToString(row["source"]));}evidence["opened_copy_path"]=copy;evidence["copy_completed"]=true;YanLabsSWGeneral.VerifySourceInputs(state,"after_copy");
        } finally {if(openedHere&&openedSource!=null&&!openedSource.GetSaveFlag()){inputLoadedHere.RemoveAll(delegate(string file){return !inputAllowedHere.Contains(file);});YanLabsSWGeneral.CloseOwnedSet(app,inputLoadedHere);}}
        int openError=0,openWarning=0;IModelDoc2 result=kind==0?(IModelDoc2)app.LoadFile4(copy,"r",null,ref openError):(IModelDoc2)app.OpenDoc6(copy,kind,1,"",ref openError,ref openWarning);
        if(result==null||openError!=0)throw new InvalidOperationException("Copied CAD input could not be opened: "+openError);
        int actualKind=result.GetType();string label="imported_"+(state.Documents.Count+1);IModelDoc2 registered=Register(result,Target(label,actualKind),label);evidence["registered_native_output"]=Owned(registered).Path;if(actualKind==2)AdoptAssemblyDependencies(registered);YanLabsSWGeneral.VerifySourceInputs(state,"after_opening_copy");return registered;
    }
    public object GetSimulationAddin() {
        Save(CurrentDocument);Activate(CurrentDocument);Native("load_simulation_addin");int major=Int32.Parse(app.RevisionNumber().Split('.')[0],CultureInfo.InvariantCulture);
        object addin=app.GetAddInObject("SldWorks.Simulation."+(major-15));if(addin==null)addin=app.GetAddInObject("SldWorks.Simulation");
        if(addin==null) {
            string installation=Path.GetDirectoryName(typeof(ISldWorks).Assembly.Location);installation=Directory.GetParent(Directory.GetParent(installation).FullName).FullName;
            string implementation=Path.Combine(installation,"Simulation","cosworks.dll");
            if(!File.Exists(implementation))throw new InvalidOperationException("SOLIDWORKS Simulation is not installed; no solve or license success is claimed");
            int loaded=app.LoadAddIn(implementation);addin=app.GetAddInObject("SldWorks.Simulation."+(major-15));if(addin==null)addin=app.GetAddInObject("SldWorks.Simulation");
            if(addin==null)throw new InvalidOperationException("Simulation add-in was not available after load (return "+loaded+"); check its installation/license");
        }
        return addin;
    }
    public Dictionary<string,object> RunSimulationStudy(object study) {return RunSimulationStudy(study,"displacement",3,0,0);}
    private string SimulationDirectory(object study) {
        if(study==null)throw new ArgumentNullException("study");
        foreach(var scope in state.SimulationScopes)if(Object.ReferenceEquals(scope.Study,study)||YanLabsSWGeneral.SameObject(scope.Study,study))return scope.Directory;
        if(state.SimulationScopes.Count>=64)throw new InvalidOperationException("Native Simulation study limit reached");
        string directory=Path.Combine(state.Directory,"simulation-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(directory);
        state.SimulationScopes.Add(new YanLabsSWScopedSimulation{Study=study,Directory=directory});return directory;
    }
    public Dictionary<string,object> CreateSimulationMesh(object study,int meshUnits,double elementSize,double tolerance) {
        if(study==null)throw new ArgumentNullException("study");YanLabsSWGeneral.Finite(elementSize);YanLabsSWGeneral.Finite(tolerance);
        if(elementSize<=0||tolerance<=0)throw new ArgumentException("Simulation mesh size and tolerance must be positive in the selected native unit system");
        Save(CurrentDocument);Activate(CurrentDocument);Native("create_native_simulation_mesh");
        Dictionary<string,object> actual=YanLabsSWGeneral.MeshSimulation(study,meshUnits,elementSize,tolerance,SimulationDirectory(study));state.SimulationMeshes.Add(actual);return actual;
    }
    public Dictionary<string,object> RunSimulationStudy(object study,string quantity,int component,int step,int unit) {
        if(study==null)throw new ArgumentNullException("study");Save(CurrentDocument);Activate(CurrentDocument);Native("run_native_simulation_study");
        Dictionary<string,object> actual=YanLabsSWGeneral.SolveSimulation(study,quantity,component,step,unit,SimulationDirectory(study));state.Simulations.Add(actual);return actual;
    }
    public void Note(string key,string value) {if(String.IsNullOrWhiteSpace(key)||key.Length>80||(value??"").Length>2000)throw new ArgumentException("Note is too large");state.Notes[key]=value??"";}
    public object Measure(string label,object nativeEntity,string apiType,string member,params object[] arguments) {
        MeasurementLabel(label);if(nativeEntity==null)throw new ArgumentNullException("nativeEntity");
        if(state.Measurements.Count>=1024)throw new InvalidOperationException("Native measurement limit reached");
        Type selected=null;foreach(Assembly assembly in YanLabsSWScriptCompiler.PiaAssemblies())foreach(Type candidate in assembly.GetExportedTypes())if(candidate.IsInterface&&(candidate.Name==apiType||candidate.FullName==apiType)){if(selected!=null&&selected!=candidate)throw new ArgumentException("Use the full official API interface name");selected=candidate;}
        if(selected==null||!selected.IsInstanceOfType(nativeEntity))throw new ArgumentException("The measured entity does not implement the requested installed official API");
        if(String.IsNullOrEmpty(member)||!Regex.IsMatch(member,@"^(Get|get_)[A-Za-z0-9_]+$"))throw new ArgumentException("Measure only accepts an installed read-only Get/get_ API member");
        object[] args=arguments??new object[0];MethodInfo getter=null;
        foreach(MethodInfo method in selected.GetMethods())if(method.Name==member&&method.GetParameters().Length==args.Length){if(getter!=null)throw new ArgumentException("Ambiguous read-only API overload");getter=method;}
        if(getter==null||getter.ReturnType==typeof(void)||YanLabsSWScriptCompiler.BlockReason(getter)!=null)throw new ArgumentException("This native member cannot be used as a read-only measurement");
        ParameterInfo[] parameters=getter.GetParameters();for(int index=0;index<args.Length;index++){
            if(parameters[index].ParameterType.IsByRef||parameters[index].IsOut)throw new ArgumentException("Use a pure value-returning native getter");
            object argument=args[index];if(argument!=null&&!(argument is string)&&!(argument is bool)&&!argument.GetType().IsPrimitive&&!argument.GetType().IsEnum)throw new ArgumentException("Measurement arguments must be plain numeric, Boolean, enum or configuration values");
            if(argument is double)YanLabsSWGeneral.Finite((double)argument);if(argument is float)YanLabsSWGeneral.Finite((float)argument);
        }
        Native("read_native_measurement");object value;
        try{value=getter.Invoke(nativeEntity,args);}catch(TargetInvocationException error){throw error.InnerException??error;}
        object actual=YanLabsSWGeneral.NumericalValue(value);
        var measurement=new Dictionary<string,object>{{"label",label},{"api_type",selected.FullName},{"member",member},{"arguments",args},{"value",actual},{"validated_after_save",false},{"provenance","actual official native API return"}};state.Measurements.Add(measurement);
        state.MeasurementRefresh.Add(delegate{object saved;try{saved=getter.Invoke(nativeEntity,args);}catch(TargetInvocationException error){throw error.InnerException??error;}measurement["value"]=YanLabsSWGeneral.NumericalValue(saved);measurement["validated_after_save"]=true;measurement["readback_timing"]="after native rebuild/save, before main document close/reopen";});return actual;
    }
    public double ReadDimension(string label,IDimension dimension) {
        MeasurementLabel(label);if(dimension==null)throw new ArgumentNullException("dimension");if(state.Measurements.Count>=1024)throw new InvalidOperationException("Native measurement limit reached");
        Native("read_native_dimension");double value=dimension.SystemValue;YanLabsSWGeneral.Finite(value);
        var measurement=new Dictionary<string,object>{{"label",label},{"api_type","SolidWorks.Interop.sldworks.IDimension"},{"member","get_SystemValue"},{"dimension",dimension.FullName},{"value",value},{"validated_after_save",false},{"unit_system","native system units; length metres, angle radians"},{"provenance","actual official native dimension return"}};state.Measurements.Add(measurement);
        state.MeasurementRefresh.Add(delegate{double saved=dimension.SystemValue;YanLabsSWGeneral.Finite(saved);measurement["value"]=saved;measurement["validated_after_save"]=true;measurement["readback_timing"]="after native rebuild/save, before main document close/reopen";});return value;
    }
    private void CaptureReferencedDocuments() {
        var originals=new List<YanLabsSWOwnedDocument>(state.Documents);
        foreach(var item in originals)if(item.Kind==2){Array components=((IAssemblyDoc)item.Document).GetComponents(false) as Array;if(components==null)continue;foreach(object value in components){IModelDoc2 document=(IModelDoc2)((IComponent2)value).GetModelDoc2();if(document==null)continue;string file=document.GetPathName();if(String.IsNullOrWhiteSpace(file)||!YanLabsSWGeneral.Inside(state.Directory,file))throw new InvalidOperationException("An assembly references a document outside this run; the input must first be copied with ctx.OpenInput");bool found=false;foreach(var own in state.Documents)if(YanLabsSWGeneral.SameObject(own.Document,document)){found=true;break;}if(!found){var own=new YanLabsSWOwnedDocument{Document=document,Path=file,Name=Path.GetFileNameWithoutExtension(file),Kind=document.GetType(),Owner=state.Owner,Run=state.Directory};state.Documents.Add(own);session[file]=own;}}}
    }
    private List<YanLabsSWOwnedDocument> OrderedOwnedDocuments() {
        var paths=new List<string>();foreach(var item in state.Documents)paths.Add(item.Path);var ordered=new List<YanLabsSWOwnedDocument>();
        foreach(string path in YanLabsSWGeneral.OwnedSaveOrder(app,paths))foreach(var item in state.Documents)if(YanLabsSWGeneral.SamePath(item.Path,path)){ordered.Add(item);break;}
        if(ordered.Count!=state.Documents.Count)throw new InvalidOperationException("Not every owned document has an exact final-save identity");return ordered;
    }
    private void SaveCurrentOwnedDocuments(List<YanLabsSWOwnedDocument> ordered,int pass) {
        Native("save_owned_native_without_rebuild_pass_"+pass);
        foreach(var item in ordered){if(pass>1&&item.Document!=null&&!item.Document.GetSaveFlag())continue;SaveExistingOwnedDocument(item,pass,"before_project_disk_reopen");}
    }
    private void SaveExistingOwnedDocument(YanLabsSWOwnedDocument item,int pass,string phase) {
        IModelDoc2 document=item.Document;Owned(document);if(!YanLabsSWGeneral.SamePath(document.GetPathName(),item.Path)||!File.Exists(item.Path))throw new InvalidOperationException("Final Save3 requires an already saved exact owned native path");int error=0,warning=0;bool saved=document.Save3(1,ref error,ref warning);var save=new Dictionary<string,object>{{"pass",pass},{"phase",phase},{"method","Save3"},{"path",item.Path},{"actual_path",document.GetPathName()},{"file_exists",File.Exists(item.Path)},{"saved",saved},{"errors",error},{"warnings",warning},{"dirty_after_save",document.GetSaveFlag()}};state.NativeSaveCount++;state.LastNativeSaveEvent=save;if(state.NativeSaveEvents.Count<128)state.NativeSaveEvents.Add(save);YanLabsSWGeneral.ObserveDirty(state,"after_Save3_pass_"+pass+"_call_"+state.NativeSaveCount);if(!saved||error!=0||!YanLabsSWGeneral.SamePath(document.GetPathName(),item.Path)||!File.Exists(item.Path))throw new InvalidOperationException("Final native Save3 failed: "+error);
    }
    private Dictionary<string,string> SavedNativeHashes() {
        var hashes=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);var paths=new List<string>();foreach(var item in state.Documents)paths.Add(item.Path);paths.AddRange(state.Dependencies);
        foreach(string path in paths){string ext=Path.GetExtension(path).ToLowerInvariant();if(ext!=".sldprt"&&ext!=".sldasm"&&ext!=".slddrw")continue;if(!YanLabsSWGeneral.Inside(state.Directory,path)||!File.Exists(path))throw new InvalidOperationException("Disk reopen references must be saved native files belonging to this run");if(!hashes.ContainsKey(path))hashes[path]=YanLabsSWGeneral.FileHash(path);}return hashes;
    }
    private List<Dictionary<string,object>> ProtectedLoadedDocuments() {
        var baseline=new List<Dictionary<string,object>>();foreach(var doc in YanLabsSWGeneral.LoadedDocuments(app))baseline.Add(new Dictionary<string,object>{{"document",doc},{"path",doc.GetPathName()},{"kind",doc.GetType()},{"dirty",doc.GetSaveFlag()}});return baseline;
    }
    private void ValidateFreshDrawingRefreshScope(List<Dictionary<string,object>> protectedDocuments,Dictionary<string,string> hashes,string expectedMainHash) {
        List<IModelDoc2> loaded=YanLabsSWGeneral.LoadedDocuments(app);bool mainFound=false;
        foreach(var original in protectedDocuments){IModelDoc2 found=null;foreach(var doc in loaded)if(YanLabsSWGeneral.SameObject(original["document"],doc)){found=doc;break;}if(found==null||!String.Equals(found.GetPathName(),Convert.ToString(original["path"]),StringComparison.OrdinalIgnoreCase)||found.GetType()!=Convert.ToInt32(original["kind"])||found.GetSaveFlag()!=Convert.ToBoolean(original["dirty"]))throw new InvalidOperationException("An existing user document changed during disk open; native drawing refresh was not saved");}
        foreach(var doc in loaded){bool original=false;foreach(var row in protectedDocuments)if(YanLabsSWGeneral.SameObject(row["document"],doc)){original=true;break;}if(original)continue;string path=doc.GetPathName();if(String.IsNullOrWhiteSpace(path)||!hashes.ContainsKey(path)||!YanLabsSWGeneral.Inside(state.Directory,path))throw new InvalidOperationException("A newly loaded drawing reference is outside the verified run; native refresh was not saved");string ext=Path.GetExtension(path).ToLowerInvariant();int expectedKind=ext==".sldprt"?1:ext==".sldasm"?2:ext==".slddrw"?3:0;if(doc.GetType()!=expectedKind)throw new InvalidOperationException("A drawing reference loaded with an unexpected native type; native refresh was not saved");if(!YanLabsSWGeneral.SamePath(path,state.Main.Path)&&doc.GetSaveFlag())throw new InvalidOperationException("A native drawing reference has unsaved changes; only the freshly opened drawing may be refreshed");if(YanLabsSWGeneral.SamePath(path,state.Main.Path)){if(!YanLabsSWGeneral.SameObject(doc,state.Main.Document))throw new InvalidOperationException("Fresh drawing object identity changed; native refresh was not saved");mainFound=true;}}
        if(!mainFound)throw new InvalidOperationException("The freshly opened owned drawing is no longer loaded; native refresh was not saved");
        foreach(var row in hashes){string expected=YanLabsSWGeneral.SamePath(row.Key,state.Main.Path)?expectedMainHash:row.Value;if(YanLabsSWGeneral.FileHash(row.Key)!=expected)throw new InvalidOperationException("An original native artifact changed outside the controlled drawing save; native refresh was not saved");}
    }
    private Dictionary<string,object> RecordFreshDiskOpen(bool initiallyDirty,Dictionary<string,string> hashes,List<Dictionary<string,object>> protectedDocuments) {
        var main=state.Main;string initialHash=hashes[main.Path],currentHash=initialHash;
        bool currentDirty=main.Document.GetSaveFlag();var evidence=new Dictionary<string,object>{{"actual_disk_open",true},{"path",main.Path},{"clean_on_initial_disk_open",!initiallyDirty},{"dirty_after_reopen_activation",currentDirty},{"native_refresh_saved_after_reopen",false},{"disk_open_artifact_sha256",initialHash},{"final_artifact_sha256",initialHash},{"final_artifact_independently_reopened",true},{"second_disk_open_performed",false}};
        string record=Path.Combine(state.Directory,"general-native-reopen-observation.json");YanLabsSWGeneral.WriteJson(record,evidence);
        if(!currentDirty){evidence["final_current_document_clean"]=true;YanLabsSWGeneral.WriteJson(record,evidence);return evidence;}
        Native("validate_fresh_drawing_native_refresh_scope");ValidateFreshDrawingRefreshScope(protectedDocuments,hashes,currentHash);YanLabsSWGeneral.RequireFreshDrawingRefresh(main.Kind,currentDirty,true,true,true,true,true);
        // Opening a drawing can update its views using SOLIDWORKS' existing
        // settings. Only this newly returned owned drawing is saved; no global
        // update preference or existing in-memory user document is changed.
        Native("export_freshly_reopened_drawing_preview");YanLabsSWGeneral.Preview(main.Document,state.Directory);YanLabsSWGeneral.ObserveDirty(state,"after_fresh_drawing_reopen_preview");
        int saveStart=state.NativeSaveCount;int passes=YanLabsSWGeneral.FinalizeSavedReadback(
            delegate(int pass){Native("save_fresh_drawing_native_refresh_pass_"+pass);ValidateFreshDrawingRefreshScope(protectedDocuments,hashes,currentHash);SaveExistingOwnedDocument(main,pass,"fresh_drawing_native_refresh_after_disk_open");currentHash=YanLabsSWGeneral.FileHash(main.Path);evidence["native_refresh_saved_after_reopen"]=true;evidence["final_artifact_sha256"]=currentHash;evidence["final_artifact_independently_reopened"]=false;YanLabsSWGeneral.WriteJson(record,evidence);},
            delegate{Native("validate_fresh_drawing_references_after_refresh_save");ValidateFreshDrawingRefreshScope(protectedDocuments,hashes,currentHash);},
            delegate{Native("inspect_saved_fresh_drawing_native_refresh");main.SavedStructure=YanLabsSWGeneral.Inspect(main.Document);YanLabsSWGeneral.ObserveDirty(state,"after_fresh_drawing_refresh_structure_readback");},
            delegate{ValidateFreshDrawingRefreshScope(protectedDocuments,hashes,currentHash);return !main.Document.GetSaveFlag();},3);
        evidence["native_refresh_save_passes"]=passes;evidence["native_refresh_save_calls"]=state.NativeSaveCount-saveStart;evidence["final_current_document_clean"]=!main.Document.GetSaveFlag();evidence["verification_note"]="The initial artifact was genuinely opened from disk. The fresh drawing became dirty during native open/activation, then only that owned drawing was saved with Save3 and checked clean with stable final hashes. Existing native update settings were unchanged. The updated final bytes were not independently opened a second time.";YanLabsSWGeneral.WriteJson(record,evidence);return evidence;
    }
    internal Dictionary<string,object> Complete() {
        if(state.Main==null||state.Documents.Count==0)throw new InvalidOperationException("The script did not create or open a native project");
        Native("capture_owned_native_references");
        CaptureReferencedDocuments();
        foreach(var item in state.Documents)if(!YanLabsSWGeneral.SamePath(item.Document.GetPathName(),item.Path)||!File.Exists(item.Path))Save(item.Document);
        YanLabsSWGeneral.ObserveDirty(state,"after_initial_native_paths_saved");
        List<YanLabsSWOwnedDocument> ordered=OrderedOwnedDocuments();
        Native("rebuild_owned_documents_before_preview");int rebuildCall=0;foreach(var item in ordered){Owned(item.Document);item.Document.ForceRebuild3(false);YanLabsSWGeneral.ObserveDirty(state,"after_explicit_rebuild_call_"+(++rebuildCall));}YanLabsSWGeneral.ObserveDirty(state,"after_explicit_rebuild_before_preview");
        var main=state.Main;
        YanLabsSWGeneral.FinalizeOwnedPreview(
            delegate{Activate(main.Document);Native("prepare_owned_native_preview");main.Document.ClearSelection2(true);if(YanLabsSWGeneral.UseModelOrientationForPreview(main.Kind))main.Document.ShowNamedView2("",7);main.Document.ViewZoomtofit2();YanLabsSWGeneral.ObserveDirty(state,"after_preview_view_preparation");},
            delegate{Native("export_saved_native_preview");YanLabsSWGeneral.Preview(main.Document,state.Directory);YanLabsSWGeneral.ObserveDirty(state,"after_native_preview_export");},
            delegate{YanLabsSWGeneral.FinalizeSavedReadback(
                delegate(int pass){SaveCurrentOwnedDocuments(ordered,pass);},
                delegate{Native("refresh_final_saved_native_measurements");foreach(Action refresh in state.MeasurementRefresh)refresh();YanLabsSWGeneral.ObserveDirty(state,"after_final_measurement_refresh");},
                delegate{Native("inspect_final_saved_native_documents");foreach(var item in state.Documents)item.SavedStructure=YanLabsSWGeneral.Inspect(item.Document);YanLabsSWGeneral.ObserveDirty(state,"after_final_structure_readback");},
                delegate{return YanLabsSWGeneral.ObserveDirty(state,"check_final_readback_saved_clean");},3);});
        state.MeasurementRefresh.Clear();state.SimulationScopes.Clear();
        Native("verify_saved_project_reopen");
        // A drawing/assembly can keep its referenced model in memory after its
        // window closes. Close only this run's clean documents in dependency
        // order; certify an actual unload before claiming a disk reopen.
        var closePaths=new List<string>();foreach(var item in state.Documents)closePaths.Add(item.Path);
        foreach(string dependency in state.Dependencies)if(YanLabsSWGeneral.FindLoaded(app,dependency)!=null&&!closePaths.Exists(delegate(string file){return YanLabsSWGeneral.SamePath(file,dependency);}))closePaths.Add(dependency);
        try{state.ClosedForVerification.AddRange(YanLabsSWGeneral.CloseOwnedSet(app,closePaths,delegate(string phase){foreach(var item in state.Documents)item.Document=YanLabsSWGeneral.FindLoaded(app,item.Path);YanLabsSWGeneral.ObserveDirty(state,phase);}));}
        finally{foreach(var item in state.Documents)item.Document=YanLabsSWGeneral.FindLoaded(app,item.Path);}
        Native("confirm_saved_main_project_unloaded");
        if(YanLabsSWGeneral.FindLoaded(app,main.Path)!=null)throw new InvalidOperationException("Saved native project remains loaded through a reference; no disk reopen was certified");
        Native("capture_saved_disk_reopen_scope");Dictionary<string,string> reopenHashes=SavedNativeHashes();List<Dictionary<string,object>> protectedDocuments=ProtectedLoadedDocuments();
        int error=0,warning=0;
        Native("reopen_saved_main_project_from_disk");
        IModelDoc2 reopened=(IModelDoc2)app.OpenDoc6(main.Path,main.Kind,1,"",ref error,ref warning);
        if(reopened==null||error!=0||!YanLabsSWGeneral.SamePath(reopened.GetPathName(),main.Path)||reopened.GetType()!=main.Kind)throw new InvalidOperationException("Saved native project did not reopen with its exact path/type: "+error);
        bool initiallyDirty=reopened.GetSaveFlag();
        main.Document=reopened;
        // Closing an assembly can unload components that had no independent
        // document window. Never inspect those stale RCWs after reopening it.
        Native("refresh_reopened_native_references");
        foreach(var item in state.Documents)if(item!=main){IModelDoc2 live=YanLabsSWGeneral.FindLoaded(app,item.Path);if(live!=null&&(!YanLabsSWGeneral.SamePath(live.GetPathName(),item.Path)||live.GetType()!=item.Kind))throw new InvalidOperationException("Reopened owned reference identity changed");item.Document=live;}
        // OpenDoc6 restores the main project's required references. Auxiliary
        // drawings/parts stay saved on disk rather than accumulating UI windows.
        Activate(main.Document);
        Dictionary<string,object> reopenEvidence=RecordFreshDiskOpen(initiallyDirty,reopenHashes,protectedDocuments);
        Native("inspect_reopened_saved_native_result");
        Dictionary<string,object> receipt=YanLabsSWGeneral.Result(app,state,true);
        YanLabsSWGeneral.AddReopenEvidence(receipt,reopenEvidence);
        Native("verify_reopened_native_documents_remain_clean");YanLabsSWGeneral.ObserveDirty(state,"after_reopened_native_result_readback");foreach(var item in state.Documents)if(item.Document!=null&&item.Document.GetSaveFlag())throw new InvalidOperationException("A reopened owned native document became dirty during result inspection; no saved result was certified");
        receipt["native_save_diagnostics"]=new Dictionary<string,object>{{"path",Path.Combine(state.Directory,"general-native-dirty-observations.json")},{"observations",state.DirtyObservationCount},{"save_calls",state.NativeSaveCount},{"final_saved_state_before_close_verified",true}};
        receipt["native_document_lifecycle"]=new Dictionary<string,object>{{"all_run_documents_unloaded_before_main_reopen",true},{"closed_owned_paths",state.ClosedForVerification},{"explicitly_reopened_path",main.Path},{"auxiliary_window_policy","Saved auxiliary documents stay on disk; required references are loaded by the main native project, not reopened as extra independent windows"}};
        Native("verify_original_input_bytes_before_delivery");var sourceChecks=YanLabsSWGeneral.VerifySourceInputs(state,"before_delivery_manifest");if(sourceChecks.Count>0)receipt["input_copy_evidence"]=new Dictionary<string,object>{{"path",Path.Combine(state.Directory,"input-copy-evidence.json")},{"input_copy_count",state.InputCopies.Count},{"verified_source_count",sourceChecks.Count},{"source_bytes_preserved",true}};
        Native("persist_verified_native_result_manifest");
        YanLabsSWGeneral.WriteJson(Path.Combine(state.Directory,"general-result-manifest.json"),receipt);state.Completed=true;return receipt;
    }
}

public static class YanLabsSWGeneral {
    public static string Stage {get;private set;}
    internal static void SetStage(string stage){Stage=stage;}
    private static JavaScriptSerializer Serializer(){return new JavaScriptSerializer{MaxJsonLength=4*1024*1024,RecursionLimit=64};}
    internal static void WriteJson(string path,object value){string temp=Path.Combine(Path.GetDirectoryName(path),"."+Guid.NewGuid().ToString("N")+".tmp");File.WriteAllText(temp,Serializer().Serialize(value),new UTF8Encoding(false));if(File.Exists(path))File.Delete(path);File.Move(temp,path);}
    internal static string Hash(byte[] data){using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(data)).Replace("-","").ToLowerInvariant();}
    private static string StreamHash(FileStream stream,long length) {
        // Read only the observed length, so a concurrent writer cannot keep this
        // verification alive indefinitely by appending data.
        using(var hash=SHA256.Create()) {
            byte[] buffer=new byte[65536];long remaining=length;stream.Position=0;
            while(remaining>0){int read=stream.Read(buffer,0,(int)Math.Min(buffer.Length,remaining));if(read<=0)throw new IOException("Native output changed during verification");hash.TransformBlock(buffer,0,read,null,0);remaining-=read;}
            hash.TransformFinalBlock(new byte[0],0,0);return BitConverter.ToString(hash.Hash).Replace("-","").ToLowerInvariant();
        }
    }
    internal static YanLabsSWFileDigest StableFileDigest(string path) {
        // SOLIDWORKS retains write access to its saved open documents. Permit
        // that existing handle, but deny delete/rename during both reads and
        // reject a changing file instead of certifying a stale snapshot.
        using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite)) {
            var info=new FileInfo(path);info.Refresh();long length=stream.Length,ticks=info.LastWriteTimeUtc.Ticks;
            if(!info.Exists||info.Length!=length)throw new IOException("Native output changed before verification");
            string first=StreamHash(stream,length);info.Refresh();
            if(stream.Length!=length||!info.Exists||info.Length!=length||info.LastWriteTimeUtc.Ticks!=ticks)throw new IOException("Native output changed during verification");
            string second=StreamHash(stream,length);info.Refresh();
            if(first!=second||stream.Length!=length||!info.Exists||info.Length!=length||info.LastWriteTimeUtc.Ticks!=ticks)throw new IOException("Native output did not remain stable across verification reads");
            return new YanLabsSWFileDigest{Sha256=second,Length=length,LastWriteTicks=ticks};
        }
    }
    internal static string FileHash(string path){return StableFileDigest(path).Sha256;}
    internal static bool SamePath(string a,string b){return !String.IsNullOrWhiteSpace(a)&&!String.IsNullOrWhiteSpace(b)&&String.Equals(Path.GetFullPath(a),Path.GetFullPath(b),StringComparison.OrdinalIgnoreCase);}
    internal static void RequireOwnedAssemblyDependency(YanLabsSWRunState state,string path,YanLabsSWOwnedDocument known) {
        if(state==null||String.IsNullOrWhiteSpace(path)||!Path.IsPathRooted(path)||!Inside(state.Directory,path)||!File.Exists(path))throw new InvalidOperationException("Assembly save references must be saved native files inside this exact run; external sources were retained");
        for(string current=Path.GetFullPath(path);Inside(state.Directory,current);current=Path.GetDirectoryName(current))if((File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new InvalidOperationException("Linked assembly save dependencies are not owned native targets");
        if(known!=null){if(known.Owner!=state.Owner||!SamePath(known.Run,state.Directory)||!SamePath(known.Path,path)||(known.Kind!=1&&known.Kind!=2))throw new InvalidOperationException("Assembly save reference has conflicting registered ownership");return;}
        int matched=0;foreach(var copy in state.InputCopies){object complete,verified;if(!copy.TryGetValue("copy_completed",out complete)||!Object.Equals(complete,true)||!copy.TryGetValue("native_target_mapping_readback_verified",out verified)||!Object.Equals(verified,true))continue;object raw;if(!copy.TryGetValue("source_to_copy_map",out raw))continue;var rows=raw as List<Dictionary<string,object>>;if(rows==null)throw new InvalidOperationException("Assembly save native-copy authority is invalid");foreach(var row in rows){object target;if(row.TryGetValue("copy",out target)&&SamePath(Convert.ToString(target),path))matched++;}}
        if(matched!=1)throw new InvalidOperationException("Assembly save reference is not a unique verified native-copy target or an already owned document");
    }
    internal static YanLabsSWOwnedDocument RegisteredOwnedPath(Dictionary<string,object> registry,string source,string owner) {
        if(registry==null||String.IsNullOrWhiteSpace(source)||String.IsNullOrWhiteSpace(owner))throw new InvalidOperationException("The requested project is not registered to this account/session");
        YanLabsSWOwnedDocument selected=null;
        foreach(var registration in registry) {
            // Windows native paths are case-insensitive. Titles and run-cache
            // keys are not path authority and cannot confer document ownership.
            if(!Path.IsPathRooted(registration.Key)||!SamePath(registration.Key,source))continue;
            var item=registration.Value as YanLabsSWOwnedDocument;
            if(item==null||!String.Equals(item.Owner,owner,StringComparison.Ordinal)||!SamePath(item.Path,source)||String.IsNullOrWhiteSpace(item.Run)||!Inside(item.Run,source))throw new InvalidOperationException("The registered native path has conflicting ownership or run identity");
            if(selected!=null) {
                if(!SamePath(selected.Run,item.Run)||selected.Kind!=item.Kind||(selected.Document!=null&&item.Document!=null&&!SameObject(selected.Document,item.Document)))throw new InvalidOperationException("The registered native path has ambiguous run/document identity");
                // A saved document can be released and re-registered by a later
                // readback. An absent old pointer is not a conflicting COM ID;
                // OpenInputCopy still verifies the actual exact source/clean
                // document before copying, without modifying the original.
                if(selected.Document==null&&item.Document!=null)selected=item;
            } else selected=item;
        }
        if(selected==null)throw new InvalidOperationException("The requested project is not registered to this account/session");
        return selected;
    }
    internal static bool Inside(string root,string file){return Path.GetFullPath(file).StartsWith(Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase);}
    internal static void CheckPathLength(string path){if(Path.GetFullPath(path).Length>255)throw new ArgumentException("SOLIDWORKS output path exceeds 255 UTF-16 units; choose a shorter workspace");}
    internal static void Finite(double value){if(Double.IsNaN(value)||Double.IsInfinity(value))throw new ArgumentException("A finite native parameter is required");}
    internal static object NumericalValue(object value){if(value is bool)return value;if(value is Array){Array input=(Array)value;if(input.Rank!=1||input.Length>100000)throw new InvalidOperationException("Native numerical measurement is too large");var output=new object[input.Length];for(int index=0;index<input.Length;index++)output[index]=NumericalValue(input.GetValue(index));return output;}if(value==null||value is string||!value.GetType().IsPrimitive||value is char||value is IntPtr||value is UIntPtr)throw new InvalidOperationException("Native measurement did not return a numerical/Boolean value");Finite(Convert.ToDouble(value,CultureInfo.InvariantCulture));return value;}
    internal static string WorkspaceFile(string root,string relative){
        if(String.IsNullOrWhiteSpace(relative)||Path.IsPathRooted(relative)||Regex.IsMatch(relative,@"[\x00-\x1f:*?\""<>|]"))throw new ArgumentException("Use a workspace-relative CAD path");
        foreach(string segment in relative.Replace('\\','/').Split('/'))if(segment.Length==0||segment==".."||segment.EndsWith(".",StringComparison.Ordinal)||segment.EndsWith(" ",StringComparison.Ordinal))throw new ArgumentException("CAD path segments must not use Windows trailing-dot/space aliases");
        string file=Path.GetFullPath(Path.Combine(root,relative));if(!Inside(root,file)||!File.Exists(file))throw new ArgumentException("The provided workspace CAD file is missing");for(string current=file;Inside(root,current);current=Path.GetDirectoryName(current))if((File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new ArgumentException("Linked CAD input paths are not allowed");return file;
    }
    internal static string ProtectSourceInput(YanLabsSWRunState state,string path) {
        string full=Path.GetFullPath(path),prefix=Path.GetFullPath(state.Workspace).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;if(!Inside(state.Workspace,full))throw new InvalidOperationException("A copied CAD source must be inside the provided workspace");full=WorkspaceFile(state.Workspace,full.Substring(prefix.Length));string actual=FileHash(full),expected;if(state.SourceInputHashes.TryGetValue(full,out expected)&&expected!=actual){VerifySourceInputs(state,"source_changed_before_copy");throw new InvalidOperationException("A protected source changed before another copy");}state.SourceInputHashes[full]=actual;return actual;
    }
    internal static void ValidateInputCopyMap(string workspace,string directory,List<Dictionary<string,object>> rows) {
        if(rows==null||rows.Count==0||rows.Count>4096)throw new InvalidOperationException("The input copy mapping is empty or exceeds its bound");var sources=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var targets=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var row in rows){string source=Path.GetFullPath(Convert.ToString(row["source"])),target=Path.GetFullPath(Convert.ToString(row["copy"]));if(!Inside(workspace,source)||!Inside(directory,target)||SamePath(source,target)||!sources.Add(source)||!targets.Add(target)||File.Exists(target))throw new InvalidOperationException("CAD copy paths must be unique new run-owned targets and distinct from provided sources");CheckPathLength(target);}
    }
    internal static void VerifyConfiguredCopyMap(List<Dictionary<string,object>> rows,Array actual) {
        if(actual==null||actual.Rank!=1||actual.Length!=rows.Count)throw new InvalidOperationException("Native Pack and Go target-name readback is incomplete");for(int index=0;index<rows.Count;index++)if(!SamePath(Convert.ToString(rows[index]["copy"]),Convert.ToString(actual.GetValue(index))))throw new InvalidOperationException("Native Pack and Go did not retain the exact requested source-to-copy mapping");
    }
    internal static List<Dictionary<string,object>> VerifySourceInputs(YanLabsSWRunState state,string phase) {
        var checks=new List<Dictionary<string,object>>();if(state.SourceInputHashes.Count==0)return checks;bool unchanged=true;var paths=new List<string>(state.SourceInputHashes.Keys);paths.Sort(StringComparer.OrdinalIgnoreCase);var currentHashes=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
        foreach(string source in paths){string actual=null,error=null;try{if(File.Exists(source))actual=FileHash(source);}catch(IOException failure){error=failure.Message;}currentHashes[source]=actual;bool equal=actual==state.SourceInputHashes[source];if(!equal)unchanged=false;var row=new Dictionary<string,object>{{"source",source},{"source_sha256_before_copy",state.SourceInputHashes[source]},{"source_sha256_at_verification",actual},{"source_bytes_unchanged",equal}};if(error!=null)row["verification_error"]=error;checks.Add(row);}
        foreach(var copy in state.InputCopies){var rows=(List<Dictionary<string,object>>)copy["source_to_copy_map"];foreach(var row in rows){string target=Convert.ToString(row["copy"]);row["copy_exists_at_verification"]=File.Exists(target);if(phase=="before_delivery_manifest"){row["source_sha256_at_delivery"]=currentHashes[Convert.ToString(row["source"])];if(File.Exists(target))row["copy_sha256_at_delivery"]=FileHash(target);}}}
        WriteJson(Path.Combine(state.Directory,"input-copy-evidence.json"),new Dictionary<string,object>{{"phase",phase},{"source_sha256",state.SourceHash},{"owner_sha256",state.Owner},{"binding_sha256",Hash(Encoding.UTF8.GetBytes(state.Binding??""))},{"source_bytes_preserved",unchanged},{"source_checks",checks},{"input_copies",state.InputCopies}});
        if(!unchanged)throw new InvalidOperationException("A protected original CAD input changed or disappeared; copies are retained and no unchanged-source certificate was issued");return checks;
    }
    internal static bool SameObject(object a,object b){if(a==null||b==null)return false;if(Object.ReferenceEquals(a,b))return true;IntPtr x=IntPtr.Zero,y=IntPtr.Zero;try{x=Marshal.GetIUnknownForObject(a);y=Marshal.GetIUnknownForObject(b);return x==y;}finally{if(x!=IntPtr.Zero)Marshal.Release(x);if(y!=IntPtr.Zero)Marshal.Release(y);}}
    internal static List<IModelDoc2> LoadedDocuments(ISldWorks app) {
        var result=new List<IModelDoc2>();Array all=app.GetDocuments() as Array;
        if(all!=null){if(all.Length>4096)throw new InvalidOperationException("Loaded document limit exceeded; no documents were closed");foreach(object raw in all){var doc=raw as IModelDoc2;if(doc==null)throw new InvalidOperationException("Native loaded-document enumeration is incomplete");result.Add(doc);}}
        return result;
    }
    internal static IModelDoc2 FindLoaded(ISldWorks app,string path) {
        IModelDoc2 found=null;foreach(var doc in LoadedDocuments(app))if(SamePath(doc.GetPathName(),path)){if(found!=null)throw new InvalidOperationException("Multiple loaded documents share the requested native path");found=doc;}return found;
    }
    internal static bool UseModelOrientationForPreview(int kind){if(kind<1||kind>3)throw new ArgumentException("Unsupported native preview document kind");return kind==1||kind==2;}
    internal static void FinalizeOwnedPreview(Action prepare,Action preview,Action finalizeSavedReadback){prepare();preview();finalizeSavedReadback();}
    internal static int FinalizeSavedReadback(Action<int> savePass,Action measurements,Action structure,Func<bool> savedClean,int maximumPasses) {
        if(maximumPasses<1||maximumPasses>3)throw new ArgumentException("Final native save stabilization is limited to one through three passes");
        for(int pass=1;pass<=maximumPasses;pass++){savePass(pass);measurements();structure();if(savedClean())return pass;}
        SetStage("final_owned_native_saved_state_unstable");throw new InvalidOperationException("Owned native documents did not remain saved and clean after bounded Save3/readback passes; they were retained");
    }
    internal static bool RequireFreshDrawingRefresh(int kind,bool dirty,bool freshlyOpened,bool referencesOwned,bool referencesClean,bool artifactsUnchanged,bool protectedDocumentsUnchanged) {
        if(!dirty)return false;
        if(kind!=3||!freshlyOpened||!referencesOwned||!referencesClean||!artifactsUnchanged||!protectedDocumentsUnchanged)throw new InvalidOperationException("Only a freshly disk-opened owned drawing with clean owned references and unchanged protected documents/artifacts may save a native view refresh");return true;
    }
    internal static void AddReopenEvidence(Dictionary<string,object> result,Dictionary<string,object> evidence) {
        string path=Convert.ToString(evidence["path"]),sha=Convert.ToString(evidence["final_artifact_sha256"]);bool found=false;
        foreach(var artifact in (List<Dictionary<string,object>>)result["artifacts"])if(SamePath(Convert.ToString(artifact["path"]),path)&&Convert.ToString(artifact["kind"])=="native"){if(found||Convert.ToString(artifact["sha256"])!=sha)throw new InvalidOperationException("Native artifact changed after disk reopen verification");found=true;}
        if(!found)throw new InvalidOperationException("The disk-reopened artifact is absent from the delivered native manifest");
        result["clean_on_initial_disk_open"]=evidence["clean_on_initial_disk_open"];result["native_refresh_saved_after_reopen"]=evidence["native_refresh_saved_after_reopen"];result["disk_reopen_verification"]=evidence;
        foreach(var row in (List<Dictionary<string,object>>)result["native_documents"])if(SamePath(Convert.ToString(row["path"]),path)){row["clean_on_initial_disk_open"]=evidence["clean_on_initial_disk_open"];row["reopened_artifact_sha256"]=evidence["disk_open_artifact_sha256"];row["artifact_saved_after_reopen"]=evidence["native_refresh_saved_after_reopen"];row["final_artifact_independently_reopened"]=evidence["final_artifact_independently_reopened"];}
    }
    internal static bool ObserveDirty(YanLabsSWRunState state,string phase) {
        var full=new List<Dictionary<string,object>>();int dirty=0,unavailable=0;
        foreach(var item in state.Documents){bool loaded=item.Document!=null;if(!loaded)unavailable++;bool changed=loaded&&item.Document.GetSaveFlag();if(changed)dirty++;full.Add(new Dictionary<string,object>{{"path",item.Path},{"kind",item.Kind},{"available",loaded},{"dirty",loaded?(object)changed:null}});}
        var sample=full.Count<=32?full:full.GetRange(0,32);var observation=new Dictionary<string,object>{{"phase",phase},{"at_utc",DateTime.UtcNow.ToString("o",CultureInfo.InvariantCulture)},{"document_count",full.Count},{"dirty_count",dirty},{"unavailable_count",unavailable},{"all_available_and_clean",dirty==0&&unavailable==0},{"documents",sample},{"document_sample_truncated",full.Count>sample.Count},{"full_state_sha256",Hash(Encoding.UTF8.GetBytes(Serializer().Serialize(full)))}};
        state.DirtyObservationCount++;state.LastDirtyObservation=observation;if(state.DirtyObservations.Count<64)state.DirtyObservations.Add(observation);
        WriteJson(Path.Combine(state.Directory,"general-native-dirty-observations.json"),new Dictionary<string,object>{{"source_sha256",state.SourceHash},{"owner_sha256",state.Owner},{"binding_sha256",Hash(Encoding.UTF8.GetBytes(state.Binding??""))},{"observation_count",state.DirtyObservationCount},{"observations",state.DirtyObservations},{"last_observation",state.LastDirtyObservation},{"observation_list_truncated",state.DirtyObservationCount>state.DirtyObservations.Count},{"save_call_count",state.NativeSaveCount},{"save_calls",state.NativeSaveEvents},{"last_save_call",state.LastNativeSaveEvent},{"save_list_truncated",state.NativeSaveCount>state.NativeSaveEvents.Count}});return dirty==0&&unavailable==0;
    }
    private static List<string> DocumentReferences(IModelDoc2 doc) {
        var result=new List<string>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        Action<string> add=delegate(string file){if(String.IsNullOrWhiteSpace(file))return;if(!Path.IsPathRooted(file))throw new InvalidOperationException("A native reference has no absolute identity; no documents were closed");string full=Path.GetFullPath(file);if(seen.Add(full))result.Add(full);};
        // SearchFlag=false reads stored dependencies without changing the
        // application's current directory or applying external search rules.
        Array stored=doc.GetDependencies2(false,false,false) as Array;
        if(stored!=null){if(stored.Length>8192||stored.Length%2!=0)throw new InvalidOperationException("Native dependency enumeration is invalid");for(int i=1;i<stored.Length;i+=2)add(Convert.ToString(stored.GetValue(i)));}
        if(doc.GetType()==2){Array components=((IAssemblyDoc)doc).GetComponents(false) as Array;if(components!=null){if(components.Length>4096)throw new InvalidOperationException("Native component dependency limit exceeded");foreach(object raw in components)add(((IComponent2)raw).GetPathName());}}
        if(doc.GetType()==3){Array sheets=((IDrawingDoc)doc).GetViews() as Array;if(sheets!=null)foreach(object raw in sheets){Array views=raw as Array;if(views==null)throw new InvalidOperationException("Native drawing references were not returned");for(int index=1;index<views.Length;index++)add(((IView)views.GetValue(index)).GetReferencedModelName());}}
        return result;
    }
    private static List<Dictionary<string,object>> DocumentCloseSnapshot(ISldWorks app) {
        var rows=new List<Dictionary<string,object>>();List<IModelDoc2> documents=LoadedDocuments(app);foreach(var doc in documents)rows.Add(new Dictionary<string,object>{{"path",doc.GetPathName()},{"title",doc.GetTitle()},{"kind",doc.GetType()},{"dirty",false},{"visible",doc.Visible},{"references",DocumentReferences(doc)}});for(int index=0;index<rows.Count;index++)rows[index]["dirty"]=documents[index].GetSaveFlag();return rows;
    }
    // Pure planning is tested without creating COM objects. Every native close
    // re-enumerates and revalidates the full plan so stale RCWs are never used.
    internal static List<string> PlanDocumentClose(List<Dictionary<string,object>> rows,List<string> requested) {
        if(rows==null||requested==null||rows.Count>4096||requested.Count>4096)throw new InvalidOperationException("Invalid bounded document close plan");
        var targets=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(string file in requested){if(String.IsNullOrWhiteSpace(file)||!Path.IsPathRooted(file))throw new InvalidOperationException("Close targets require exact saved native paths");targets.Add(Path.GetFullPath(file));}
        var byPath=new Dictionary<string,Dictionary<string,object>>(StringComparer.OrdinalIgnoreCase);var titles=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
        foreach(var row in rows){string title=Convert.ToString(row["title"]),file=Convert.ToString(row["path"]);if(!titles.ContainsKey(title))titles[title]=0;titles[title]++;if(!String.IsNullOrWhiteSpace(file)){file=Path.GetFullPath(file);if(byPath.ContainsKey(file))throw new InvalidOperationException("Loaded native path identity is not unique; close refused");byPath[file]=row;}}
        foreach(string file in targets){Dictionary<string,object> row;if(!byPath.TryGetValue(file,out row))continue;string title=Convert.ToString(row["title"]);if(Convert.ToBoolean(row["dirty"])||String.IsNullOrWhiteSpace(title)||titles[title]!=1)throw new InvalidOperationException("Owned document identity/clean state not confirmed; close refused");}
        foreach(var row in rows){string file=Convert.ToString(row["path"]);bool owned=!String.IsNullOrWhiteSpace(file)&&targets.Contains(Path.GetFullPath(file));if(!owned&&!Convert.ToBoolean(row["visible"]))throw new InvalidOperationException("An unrelated hidden native document may be affected by CloseDoc; it was retained and no close was attempted");var references=(List<string>)row["references"];if(!owned)foreach(string dependency in references)if(targets.Contains(Path.GetFullPath(dependency)))throw new InvalidOperationException("Another native document still references this run; no document was closed");}
        return DependencyCloseOrder(byPath,targets);
    }
    private static List<string> DependencyCloseOrder(Dictionary<string,Dictionary<string,object>> byPath,HashSet<string> targets) {
        var remaining=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(string file in targets)if(byPath.ContainsKey(file))remaining.Add(file);var ordered=new List<string>();
        while(remaining.Count>0){string next=null;int rank=Int32.MaxValue;foreach(string file in remaining){bool hasParent=false;foreach(string other in remaining){if(String.Equals(file,other,StringComparison.OrdinalIgnoreCase))continue;foreach(string dependency in (List<string>)byPath[other]["references"])if(SamePath(dependency,file)){hasParent=true;break;}if(hasParent)break;}if(hasParent)continue;int kind=Convert.ToInt32(byPath[file]["kind"]),candidate=kind==3?0:kind==2?1:2;if(next==null||candidate<rank||(candidate==rank&&String.Compare(file,next,StringComparison.OrdinalIgnoreCase)<0)){next=file;rank=candidate;}}if(next==null)throw new InvalidOperationException("Native document reference cycle prevents a verified unload; no close plan was accepted");ordered.Add(next);remaining.Remove(next);}
        return ordered;
    }
    internal static List<string> PlanDocumentSave(List<Dictionary<string,object>> rows,List<string> requested) {
        if(rows==null||requested==null||rows.Count>4096||requested.Count>4096)throw new InvalidOperationException("Invalid bounded document save plan");
        var byPath=new Dictionary<string,Dictionary<string,object>>(StringComparer.OrdinalIgnoreCase);foreach(var row in rows){string path=Convert.ToString(row["path"]);if(String.IsNullOrWhiteSpace(path))continue;path=Path.GetFullPath(path);if(byPath.ContainsKey(path))throw new InvalidOperationException("Loaded native path identity is not unique; save refused");byPath[path]=row;}
        var targets=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(string path in requested){if(String.IsNullOrWhiteSpace(path)||!Path.IsPathRooted(path))throw new InvalidOperationException("Final save targets require exact owned native paths");string full=Path.GetFullPath(path);if(!targets.Add(full)||!byPath.ContainsKey(full))throw new InvalidOperationException("An owned final-save document is unavailable or ambiguous");}
        // Saving a child can dirty its referring assembly/drawing. Save children
        // first and parents last; this does not relax the later dirty close gate.
        List<string> ordered=DependencyCloseOrder(byPath,targets);ordered.Reverse();return ordered;
    }
    internal static List<string> OwnedSaveOrder(ISldWorks app,List<string> paths){return PlanDocumentSave(DocumentCloseSnapshot(app),paths);}
    internal static List<string> CloseOwnedSet(ISldWorks app,List<string> paths,Action<string> observe=null) {
        if(paths.Count==0)return new List<string>();
        SetStage("plan_owned_native_document_unload");
        var snapshot=DocumentCloseSnapshot(app);if(observe!=null)observe("after_initial_close_dependency_snapshot");List<string> ordered=PlanDocumentClose(snapshot,paths);var closed=new List<string>();
        foreach(string path in ordered){SetStage("refresh_loaded_document_before_owned_close");IModelDoc2 live=FindLoaded(app,path);if(live==null)continue;SetStage("revalidate_owned_native_document_close");snapshot=DocumentCloseSnapshot(app);if(observe!=null)observe("after_close_dependency_snapshot_"+closed.Count);PlanDocumentClose(snapshot,paths);if(!SamePath(live.GetPathName(),path)||live.GetSaveFlag())throw new InvalidOperationException("Owned document changed before close; it was retained");string title=live.GetTitle();SetStage("close_owned_native_document");app.CloseDoc(title);SetStage("confirm_owned_native_document_unloaded");if(FindLoaded(app,path)!=null)throw new InvalidOperationException("Owned document remains loaded through a native reference; closure is not confirmed");closed.Add(path);}
        SetStage("confirm_owned_native_document_set_unloaded");foreach(string path in paths)if(FindLoaded(app,path)!=null)throw new InvalidOperationException("Owned document set did not unload completely");return closed;
    }
    internal static void CloseExact(ISldWorks app,IModelDoc2 doc,string path){if(doc==null||!SamePath(doc.GetPathName(),path)||doc.GetSaveFlag())throw new InvalidOperationException("Owned document identity/clean state not confirmed; close refused");CloseOwnedSet(app,new List<string>{path});}
    internal static List<string> PartialCleanupScope(YanLabsSWRunState state,string owner,string directory) {
        // This authority comes only from this persistent host's authenticated
        // live run cache. A disk journal, title or missing manifest is not enough.
        if(state==null||!state.Executed||state.Completed||state.Owner!=owner||!SamePath(state.Directory,directory)||state.Documents.Count==0)throw new InvalidOperationException("Partial cleanup requires the original authenticated live host run state; the original result is not certified");
        var paths=new List<string>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var item in state.Documents){if(item==null||item.Owner!=owner||!SamePath(item.Run,directory)||String.IsNullOrWhiteSpace(item.Path)||!Inside(directory,item.Path)||item.Kind<1||item.Kind>3)throw new InvalidOperationException("Partial cleanup document ownership/run scope is not confirmed");string file=Path.GetFullPath(item.Path);if(!seen.Add(file))throw new InvalidOperationException("Partial cleanup has ambiguous registered document paths");paths.Add(file);}
        return paths;
    }
    private static Dictionary<string,object> CleanupPartialRun(ISldWorks app,YanLabsSWRunState state,string owner,string directory) {
        SetStage("validate_partial_failed_run_cleanup_scope");List<string> paths=PartialCleanupScope(state,owner,directory);List<IModelDoc2> loaded=LoadedDocuments(app);
        // Match cached COM identity before reading it. An unsaved registered
        // document may not yet have its target path; it must be retained.
        foreach(var item in state.Documents){IModelDoc2 actual=null;foreach(var doc in loaded)if(SameObject(item.Document,doc)){actual=doc;break;}IModelDoc2 byPath=FindLoaded(app,item.Path);if(actual==null){if(byPath!=null)throw new InvalidOperationException("A loaded document at this path is not the cached failed-run object; it was retained");continue;}if(!SamePath(actual.GetPathName(),item.Path)||actual.GetType()!=item.Kind||actual.GetSaveFlag()||!File.Exists(item.Path)||!SameObject(actual,byPath))throw new InvalidOperationException("Failed-run document is unsaved, changed or not the original cached object; it was retained");}
        List<string> closed=CloseOwnedSet(app,paths);foreach(var item in state.Documents)item.Document=null;state.MeasurementRefresh.Clear();state.SimulationScopes.Clear();
        return new Dictionary<string,object>{{"ok",true},{"partial_failure_cleanup",true},{"original_run_completed",false},{"task_result_certified",false},{"closed_owned_documents",true},{"closed_paths",closed},{"all_owned_paths_unloaded",true},{"application_closed",false},{"original_request_preserved",true}};
    }
    internal static void Preview(IModelDoc2 document,string directory){string bmp=Path.Combine(directory,"preview.bmp"),png=Path.Combine(directory,"preview.png");if(!document.SaveBMP(bmp,1200,900))throw new InvalidOperationException("Native preview export failed");using(var image=Image.FromFile(bmp))image.Save(png,ImageFormat.Png);File.Delete(bmp);}
    private static string Kind(int kind){return kind==1?"part":kind==2?"assembly":kind==3?"drawing":"unknown";}
    private static Dictionary<string,object> Artifact(string path,string kind,string role){var digest=StableFileDigest(path);if(digest.Length==0)throw new InvalidOperationException("Expected nonempty native output is missing");return new Dictionary<string,object>{{"path",path},{"sha256",digest.Sha256},{"bytes",digest.Length},{"kind",kind},{"role",role},{"stable_file_reads",2},{"file_last_write_utc_ticks",digest.LastWriteTicks}};}
    internal static void WriteJournal(YanLabsSWRunState state,string phase){var docs=new List<Dictionary<string,object>>();foreach(var item in state.Documents)docs.Add(new Dictionary<string,object>{{"path",item.Path},{"name",item.Name},{"document_type",Kind(item.Kind)},{"saved",SamePath(item.Document.GetPathName(),item.Path)&&File.Exists(item.Path)},{"title",item.Document.GetTitle()}});WriteJson(Path.Combine(state.Directory,"general-native-journal.json"),new Dictionary<string,object>{{"phase",phase},{"source_sha256",state.SourceHash},{"binding_sha256",Hash(Encoding.UTF8.GetBytes(state.Binding))},{"owner_sha256",state.Owner},{"documents",docs}});}
    private static Dictionary<string,object> FeatureRow(IFeature feature,ref int count,int depth){if(++count>10000||depth>32)throw new InvalidOperationException("Native feature traversal exceeded its bound");string type=feature.GetTypeName2();bool warning;int error=feature.GetErrorCode2(out warning);var row=new Dictionary<string,object>{{"name",feature.Name},{"type",type=="ICE"?feature.GetTypeName():type},{"raw_type_name2",type},{"native_error_code",error},{"native_is_warning",warning}};var children=new List<Dictionary<string,object>>();IFeature child=(IFeature)feature.GetFirstSubFeature();while(child!=null){children.Add(FeatureRow(child,ref count,depth+1));child=(IFeature)child.GetNextSubFeature();}if(children.Count>0)row["children"]=children;return row;}
    private static List<Dictionary<string,object>> Features(IModelDoc2 document){var list=new List<Dictionary<string,object>>();int count=0;IFeature item=(IFeature)document.FirstFeature();while(item!=null){list.Add(FeatureRow(item,ref count,0));item=(IFeature)item.GetNextFeature();}return list;}
    private static void CollectMates(List<Dictionary<string,object>> features,List<Dictionary<string,object>> mates){foreach(var row in features){string type=Convert.ToString(row["type"]);if(type.StartsWith("Mate",StringComparison.Ordinal)&&type!="MateGroup"&&type!="MateReference")mates.Add(new Dictionary<string,object>{{"name",row["name"]},{"type",type}});object children;if(row.TryGetValue("children",out children))CollectMates((List<Dictionary<string,object>>)children,mates);}}
    internal static void OptionalNativeRead(Dictionary<string,object> row,string name,Func<object> read) {
        try{row[name]=read();}catch(COMException error){row[name]=null;row[name+"_read_error"]=new Dictionary<string,object>{{"type",error.GetType().FullName},{"hresult","0x"+error.HResult.ToString("x8")},{"message",error.Message}};}catch(NotSupportedException error){row[name]=null;row[name+"_read_error"]=new Dictionary<string,object>{{"type",error.GetType().FullName},{"message",error.Message}};}
    }
    private static string NativeEnumName(string name,int value){foreach(var assembly in YanLabsSWScriptCompiler.PiaAssemblies()){Type type=assembly.GetType("SolidWorks.Interop.swconst."+name,false);if(type!=null&&type.IsEnum)return Enum.GetName(type,value);}return null;}
    internal static Dictionary<string,object> MateReferenceType(int value) {
        // IMateEntity2.ReferenceType2 returns swSelectType_e, not the older
        // swMateEntityTypes_e family. Preserve the native number even when the
        // installed enum has no name; never infer geometry from a guessed enum.
        return new Dictionary<string,object>{{"reference_type",value},{"reference_type_name",NativeEnumName("swSelectType_e",value)},{"reference_type_enum","SolidWorks.Interop.swconst.swSelectType_e"},{"reference_type_provenance","Actual IMateEntity2.ReferenceType2 return; classified with its documented swSelectType_e enumeration"}};
    }
    internal static object MateEntityParameters(object raw){if(raw==null)return null;Array values=raw as Array;if(values==null||values.Rank!=1||values.Length>128)throw new InvalidOperationException("Native mate entity parameters are not a bounded one-dimensional array");return NumericalValue(values);}
    private static Dictionary<string,object> ComponentReadback(IComponent2 component) {
        var row=new Dictionary<string,object>{{"instance_name",component.Name2},{"document_path",component.GetPathName()},{"reference_provenance","actual IComponent2 return"}};
        OptionalNativeRead(row,"fixed",delegate{return component.IsFixed();});OptionalNativeRead(row,"suppression_state",delegate{return component.GetSuppression2();});
        OptionalNativeRead(row,"native_constrained_status",delegate{return component.GetConstrainedStatus();});if(row["native_constrained_status"]!=null)row["native_constrained_status_name"]=NativeEnumName("swConstrainedStatus_e",Convert.ToInt32(row["native_constrained_status"]));
        row["constrained_status_note"]="Component-level IComponent2.GetConstrainedStatus enumeration; not a degree-of-freedom count or individual mate solve certificate";
        OptionalNativeRead(row,"transform_array",delegate{IMathTransform transform=(IMathTransform)component.Transform2;return transform==null?null:NumericalValue(transform.ArrayData);});return row;
    }
    private static List<Dictionary<string,object>> MateDimensions(IMate2 mate,int type) {
        var dimensions=new List<Dictionary<string,object>>();for(int index=0;index<(type==10?2:1);index++){var row=new Dictionary<string,object>{{"index",index}};int current=index;OptionalNativeRead(row,"native_dimension",delegate{IDisplayDimension display=(IDisplayDimension)mate.get_DisplayDimension2(current);if(display==null)return null;IDimension dimension=(IDimension)display.GetDimension2(0);if(dimension==null)return null;double value=dimension.SystemValue;Finite(value);return new Dictionary<string,object>{{"full_name",dimension.FullName},{"dimension_type",dimension.GetType()},{"system_value",value},{"units","native system units; length metres, angle radians"},{"provenance","IMate2.DisplayDimension2 / IDisplayDimension.GetDimension2 / IDimension.SystemValue"}};});dimensions.Add(row);}return dimensions;
    }
    private static Dictionary<string,object> MateReadback(IFeature feature,IMate2 mate) {
        bool warning;int error=feature.GetErrorCode2(out warning),type=mate.Type,alignment=mate.Alignment,count=mate.GetMateEntityCount();if(count<0||count>128)throw new InvalidOperationException("Native mate entity count exceeded its bound");
        var row=new Dictionary<string,object>{{"feature_name",feature.Name},{"feature_type",feature.GetTypeName2()},{"native_mate_readback_available",true},{"mate_type",type},{"mate_type_name",NativeEnumName("swMateType_e",type)},{"alignment",alignment},{"alignment_name",NativeEnumName("swMateAlign_e",alignment)},{"native_feature_error_code",error},{"native_feature_is_warning",warning},{"entity_count",count},{"mate_solver_status",null},{"mate_solver_status_api_available",false},{"dangling",null},{"dangling_api_available",false},{"status_note","Installed IMate2 exposes no generic solver status or dangling getter. Feature error=0 and entity/reference presence do not certify a solved/non-dangling mate."},{"provenance","actual IFeature.GetSpecificFeature2 -> IMate2 official native readback"}};
        OptionalNativeRead(row,"feature_suppressed_current_configuration",delegate{return feature.IsSuppressed();});var entities=new List<Dictionary<string,object>>();
        for(int index=0;index<count;index++){IMateEntity2 entity=(IMateEntity2)mate.MateEntity(index);var item=new Dictionary<string,object>{{"index",index},{"native_entity_available",entity!=null}};if(entity!=null){int referenceType=entity.ReferenceType2;foreach(var classification in MateReferenceType(referenceType))item[classification.Key]=classification.Value;OptionalNativeRead(item,"entity_parameter_count",delegate{return entity.GetEntityParamsSize();});OptionalNativeRead(item,"entity_parameters",delegate{return MateEntityParameters(entity.EntityParams);});item["entity_parameter_units"]="Native assembly-coordinate parameters from IMateEntity2.EntityParams; no inferred geometry or conversion";OptionalNativeRead(item,"reference",delegate{object reference=entity.Reference;string api=reference==null?null:reference is IFace2?"IFace2":reference is IEdge?"IEdge":reference is IVertex?"IVertex":reference is IRefPlane?"IRefPlane":reference is IRefAxis?"IRefAxis":reference is ISketchPoint?"ISketchPoint":"unclassified_native_reference";return new Dictionary<string,object>{{"present",reference!=null},{"api_type",api},{"presence_is_not_dangling_status",true}};});OptionalNativeRead(item,"reference_component",delegate{IComponent2 component=(IComponent2)entity.ReferenceComponent;return component==null?null:ComponentReadback(component);});}entities.Add(item);}
        row["entities"]=entities;row["dimensions"]=MateDimensions(mate,type);if(type==5||type==6){OptionalNativeRead(row,"minimum_variation",delegate{double value=mate.MinimumVariation;Finite(value);return value;});OptionalNativeRead(row,"maximum_variation",delegate{double value=mate.MaximumVariation;Finite(value);return value;});OptionalNativeRead(row,"flipped",delegate{return mate.Flipped;});}return row;
    }
    private static void NativeMateFeatures(IFeature feature,List<Dictionary<string,object>> rows,HashSet<string> seen,ref int traversed,int depth) {
        if(++traversed>10000||depth>32)throw new InvalidOperationException("Native mate traversal exceeded its bound");string type=feature.GetTypeName2();if(type=="ICE")type=feature.GetTypeName();if(type.StartsWith("Mate",StringComparison.Ordinal)&&type!="MateGroup"&&type!="MateReference"&&seen.Add(feature.Name+"\n"+type)){IMate2 mate=feature.GetSpecificFeature2() as IMate2;if(mate!=null)rows.Add(MateReadback(feature,mate));else rows.Add(new Dictionary<string,object>{{"feature_name",feature.Name},{"feature_type",type},{"native_mate_readback_available",false},{"note","This native feature did not return an IMate2 object; no mate entity/solve facts were inferred"}});}IFeature child=(IFeature)feature.GetFirstSubFeature();while(child!=null){NativeMateFeatures(child,rows,seen,ref traversed,depth+1);child=(IFeature)child.GetNextSubFeature();}
    }
    private static Dictionary<string,object> AssemblyReadback(IModelDoc2 document) {
        Array parts=((IAssemblyDoc)document).GetComponents(false) as Array;if(parts!=null&&parts.Length>4096)throw new InvalidOperationException("Native component readback exceeded its bound");var components=new List<Dictionary<string,object>>();if(parts!=null)foreach(object raw in parts)components.Add(ComponentReadback((IComponent2)raw));var mates=new List<Dictionary<string,object>>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);int traversed=0;IFeature feature=(IFeature)document.FirstFeature();while(feature!=null){NativeMateFeatures(feature,mates,seen,ref traversed,0);feature=(IFeature)feature.GetNextFeature();}int available=0;foreach(var mate in mates)if(Convert.ToBoolean(mate["native_mate_readback_available"]))available++;return new Dictionary<string,object>{{"components",components},{"mate_details",mates},{"native_mate_count",available},{"mate_readback_provenance","Actual installed IAssemblyDoc/IMate2/IMateEntity2 API values; feature-name counts alone are not mate validation"}};
    }
    internal static Dictionary<string,object> Inspect(IModelDoc2 document){int kind=document.GetType();var features=Features(document);var data=new Dictionary<string,object>{{"document_type",Kind(kind)},{"document_dirty",document.GetSaveFlag()},{"features",features}};if(kind==1){Array solids=((IPartDoc)document).GetBodies2(0,false) as Array,sheets=((IPartDoc)document).GetBodies2(1,false) as Array;int count=solids==null?0:solids.Length;double volume=0,area=0;if(solids!=null)foreach(object raw in solids){Array values=((IBody2)raw).GetMassProperties(1000) as Array;if(values==null||values.Length<6)throw new InvalidOperationException("Native body mass properties are unavailable");double v=Convert.ToDouble(values.GetValue(3)),a=Convert.ToDouble(values.GetValue(4));Finite(v);Finite(a);if(v<=0)throw new InvalidOperationException("Native solid has no positive volume");volume+=v;area+=a;}data["body_count"]=count;data["solid_body_count"]=count;data["surface_body_count"]=sheets==null?0:sheets.Length;data["volume_m3"]=volume;data["surface_area_m2"]=area;data["mass_validation"]="volume only; no assigned-material mass is inferred";}else if(kind==2){Array parts=((IAssemblyDoc)document).GetComponents(false) as Array,top=((IAssemblyDoc)document).GetComponents(true) as Array;data["component_count"]=parts==null?0:parts.Length;data["top_level_component_count"]=top==null?0:top.Length;var mates=new List<Dictionary<string,object>>();CollectMates(features,mates);data["mate_count"]=mates.Count;data["mate_features"]=mates;foreach(var detail in AssemblyReadback(document))data[detail.Key]=detail.Value;}else if(kind==3){Array sheets=((IDrawingDoc)document).GetSheetNames() as Array,groups=((IDrawingDoc)document).GetViews() as Array;data["drawing_sheet_count"]=sheets==null?0:sheets.Length;var views=new List<Dictionary<string,object>>();if(groups!=null)for(int index=0;index<groups.Length;index++){Array sheetViews=groups.GetValue(index) as Array;if(sheetViews==null)throw new InvalidOperationException("Native drawing sheet/view hierarchy was not returned");for(int inner=1;inner<sheetViews.Length;inner++){IView view=(IView)sheetViews.GetValue(inner);views.Add(new Dictionary<string,object>{{"sheet",sheets!=null&&index<sheets.Length?sheets.GetValue(index):index},{"name",view.GetName2()},{"type",view.Type},{"referenced_model",view.GetReferencedModelName()},{"scale",view.ScaleDecimal}});}}data["drawing_model_view_count"]=views.Count;data["drawing_model_views"]=views;}return data;}
    internal static void DescribeOpenedDocument(Dictionary<string,object> result,Dictionary<string,object> selectedStructure,bool selectedFromDisk) {
        bool mainDirty=Convert.ToBoolean(result["document_dirty"])||(result.ContainsKey("saved")&&!Convert.ToBoolean(result["saved"])),selectedDirty=Convert.ToBoolean(selectedStructure["document_dirty"]);
        result["main_document_dirty"]=mainDirty;result["main_document_saved"]=!mainDirty;
        result["opened_project_dirty"]=selectedDirty;result["opened_project_saved"]=!selectedDirty;result["opened_project_structure"]=selectedStructure;
        result["opened_project_source"]=selectedFromDisk?"opened_from_disk":"existing_memory";
        result["opened_project_from_disk"]=selectedFromDisk;result["opened_project_disk_artifact_verified"]=true;
        result["opened_project_memory_matches_disk_verified"]=selectedFromDisk&&!selectedDirty;
        result["saved"]=!mainDirty&&!selectedDirty;
        result["opened_project_verification_note"]=selectedDirty?"Existing unsaved edits were retained; the original disk artifact was verified separately, not the displayed modified version":selectedFromDisk?"This selected document was opened from the verified original artifact in this call":"Existing in-memory document was retained; its structure was read directly, without claiming a new disk reopen";
    }
    internal static Dictionary<string,object> Result(ISldWorks app,YanLabsSWRunState state,bool reopened){
        var artifacts=new List<Dictionary<string,object>>();var native=new List<Dictionary<string,object>>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach(var item in state.Documents){if(!seen.Add(item.Path))continue;if(item.Document!=null&&item.Document.GetSaveFlag())throw new InvalidOperationException("Owned native document changed after saving; no final saved result was certified");var artifact=Artifact(item.Path,"native",item==state.Main?"main":"component");artifacts.Add(artifact);var structure=item.Document==null?item.SavedStructure:Inspect(item.Document);if(structure!=null&&Convert.ToBoolean(structure["document_dirty"]))throw new InvalidOperationException("Owned native document changed during final verification");var row=new Dictionary<string,object>{{"path",item.Path},{"sha256",artifact["sha256"]},{"bytes",artifact["bytes"]},{"name",item.Name},{"document_type",Kind(item.Kind)},{"role",item==state.Main?"main":"component"},{"structure",structure},{"structure_verified",structure!=null},{"structure_source",item.Document!=null?"current_loaded_document":"after_save_before_verified_close"},{"reopened",reopened&&item==state.Main}};if(item.Document==null)row["verification_note"]="Saved auxiliary document was inspected after save and closed for memory release; no current inspection or independent disk reopen is claimed";native.Add(row);}
        foreach(string file in state.Dependencies){string ext=Path.GetExtension(file).ToLowerInvariant();if(!seen.Add(file)||Array.IndexOf(new[]{".sldprt",".sldasm",".slddrw"},ext)<0)continue;var artifact=Artifact(file,"native","reference");artifacts.Add(artifact);native.Add(new Dictionary<string,object>{{"path",file},{"sha256",artifact["sha256"]},{"bytes",artifact["bytes"]},{"name",Path.GetFileNameWithoutExtension(file)},{"document_type",ext==".sldprt"?"part":ext==".sldasm"?"assembly":"drawing"},{"role","reference"},{"structure_verified",false},{"reopened",false},{"verification_note","Native Pack and Go copied this reference; this unloaded document has not independently been inspected/reopened"}});}
        foreach(var item in state.Exports)if(seen.Add((string)item["path"]))artifacts.Add(Artifact((string)item["path"],(string)item["kind"],"export"));string preview=Path.Combine(state.Directory,"preview.png");if(File.Exists(preview))artifacts.Add(Artifact(preview,"preview","preview"));var result=Inspect(state.Main.Document);result["ok"]=true;result["saved"]=true;result["reopened"]=reopened;result["project"]=state.Main.Path;result["preview"]=preview;result["native_documents"]=native;result["artifacts"]=artifacts;result["outputs"]=artifacts;result["source_sha256"]=state.SourceHash;result["binding_sha256"]=Hash(Encoding.UTF8.GetBytes(state.Binding));result["owner_sha256"]=state.Owner;result["notes"]=state.Notes;result["simulation_runs"]=state.Simulations;result["simulation_meshes"]=state.SimulationMeshes;result["native_measurements"]=state.Measurements;result["save_errors"]=0;result["pid"]=app.GetProcessID();return result;
    }
    private static string Owner(string binding,string workspace,string runDirectory){var map=Serializer().DeserializeObject(binding) as Dictionary<string,object>;if(map==null||map.Count!=4||!map.ContainsKey("account_id")||!map.ContainsKey("session_id")||!map.ContainsKey("workspace")||!map.ContainsKey("run_id")||!SamePath(Convert.ToString(map["workspace"]),workspace)||!String.Equals(Convert.ToString(map["run_id"]),Path.GetFileName(runDirectory),StringComparison.OrdinalIgnoreCase))throw new ArgumentException("Native run binding does not match workspace/run");if(String.IsNullOrWhiteSpace(Convert.ToString(map["account_id"]))||String.IsNullOrWhiteSpace(Convert.ToString(map["session_id"])))throw new ArgumentException("Native account/session identity is missing");return Hash(Encoding.UTF8.GetBytes(Convert.ToString(map["account_id"])+"\n"+Convert.ToString(map["session_id"])+"\n"+Path.GetFullPath(workspace).ToUpperInvariant()));}
    private static bool ContainsComFailure(Exception error){for(Exception item=error;item!=null;item=item.InnerException)if(item is COMException)return true;return false;}
    public static Dictionary<string,object> Dispatch(object raw,string operation,string workspace,string runDirectory,string sourceSnapshotPath,string sourceSha256,string bindingJson,Dictionary<string,object> sessionOwnedDocuments,string requestedArtifact=null) {
        YanLabsSWRunState state=null;bool native=false;
        try {
            SetStage("validate_general_request");workspace=Path.GetFullPath(workspace);runDirectory=Path.GetFullPath(runDirectory);
            if(!Directory.Exists(workspace)||!Directory.Exists(runDirectory)||!Inside(workspace,runDirectory)||!Regex.IsMatch(Path.GetFileName(runDirectory),@"^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-4[a-fA-F0-9]{3}-[89abAB][a-fA-F0-9]{3}-[a-fA-F0-9]{12}$"))throw new ArgumentException("Invalid native run directory");
            string owner=Owner(bindingJson,workspace,runDirectory),key="__run__:"+runDirectory;ISldWorks app=(ISldWorks)raw;object cached;
            if(sessionOwnedDocuments.TryGetValue(key,out cached)){state=cached as YanLabsSWRunState;if(state==null||state.Owner!=owner)throw new InvalidOperationException("Native run belongs to another account/session");}
            if(operation=="script") {
                if(state!=null&&state.Executed)throw new InvalidOperationException("This native run was already dispatched; inspect it instead of replaying source");
                if(!Inside(runDirectory,sourceSnapshotPath)||!File.Exists(sourceSnapshotPath))throw new ArgumentException("Frozen model source must belong to this run");
                byte[] source=File.ReadAllBytes(sourceSnapshotPath);if(source.Length==0||source.Length>1024*1024||Hash(source)!=sourceSha256)throw new ArgumentException("Frozen model source bytes do not match their recorded hash");
                SetStage("compile_model_api_source");IYanLabsSWModel model=YanLabsSWScriptCompiler.Compile(new UTF8Encoding(false,true).GetString(source),runDirectory);
                state=new YanLabsSWRunState{Workspace=workspace,Directory=runDirectory,Binding=bindingJson,Owner=owner,SourceHash=sourceSha256,Executed=true};sessionOwnedDocuments[key]=state;WriteJournal(state,"source_compiled");
                var context=new YanLabsSWContext(app,state,sessionOwnedDocuments);SetStage("execute_model_native_api");model.Build(context);return context.Complete();
            }
            if(operation!="readback"&&operation!="open"&&operation!="cleanup")throw new ArgumentException("Unsupported general native operation");
            string manifestPath=Path.Combine(runDirectory,"general-result-manifest.json");if(!File.Exists(manifestPath)){if(operation=="cleanup")return CleanupPartialRun(app,state,owner,runDirectory);throw new InvalidOperationException("The original native run has no complete saved result; partial owned documents are retained, not rebuilt");}
            var manifest=Serializer().DeserializeObject(File.ReadAllText(manifestPath,Encoding.UTF8)) as Dictionary<string,object>;
            if(manifest==null||Convert.ToString(manifest["binding_sha256"])!=Hash(Encoding.UTF8.GetBytes(bindingJson))||Convert.ToString(manifest["owner_sha256"])!=owner)throw new InvalidOperationException("Saved native result binding does not match this account/session/run");
            object[] documents=manifest["native_documents"] as object[];if(documents==null||documents.Length==0)throw new InvalidOperationException("Saved native document manifest is missing");
            if(state==null){state=new YanLabsSWRunState{Workspace=workspace,Directory=runDirectory,Binding=bindingJson,Owner=owner,SourceHash=Convert.ToString(manifest["source_sha256"]),Executed=true,Completed=true};sessionOwnedDocuments[key]=state;}
            string selected=String.IsNullOrWhiteSpace(requestedArtifact)?Convert.ToString(manifest["project"]):Path.GetFullPath(requestedArtifact);bool selectedFound=false;
            foreach(object rawRow in documents){var row=rawRow as Dictionary<string,object>;string file=Path.GetFullPath(Convert.ToString(row["path"]));if(!Inside(runDirectory,file)||!File.Exists(file)||FileHash(file)!=Convert.ToString(row["sha256"]))throw new InvalidOperationException("Original native artifact bytes have changed or disappeared");if(SamePath(file,selected))selectedFound=true;}
            if(!selectedFound)throw new InvalidOperationException("Requested native file was not produced by this original run");
            if(operation=="cleanup") {var paths=new List<string>();foreach(object rawRow in documents)paths.Add(Convert.ToString(((Dictionary<string,object>)rawRow)["path"]));SetStage("close_owned_native_document_set");native=true;List<string> closed=CloseOwnedSet(app,paths);foreach(var item in state.Documents)item.Document=null;return new Dictionary<string,object>{{"ok",true},{"closed_owned_documents",true},{"closed_paths",closed},{"all_owned_paths_unloaded",true},{"project",manifest["project"]},{"application_closed",false}};}
            state.Documents.Clear();IModelDoc2 selectedDoc=null;bool mainFromDisk=false,selectedFromDisk=false;
            foreach(object rawRow in documents){var row=(Dictionary<string,object>)rawRow;string file=Convert.ToString(row["path"]),kind=Convert.ToString(row["document_type"]);int type=kind=="part"?1:kind=="assembly"?2:3;IModelDoc2 doc=FindLoaded(app,file);if(doc==null&&(SamePath(file,selected)||SamePath(file,Convert.ToString(manifest["project"])))){int error=0,warning=0;native=true;doc=(IModelDoc2)app.OpenDoc6(file,type,1,"",ref error,ref warning);if(doc==null||error!=0)throw new InvalidOperationException("Owned native project reopen failed: "+error);if(SamePath(file,selected))selectedFromDisk=true;if(SamePath(file,Convert.ToString(manifest["project"])))mainFromDisk=true;}if(doc!=null){var own=new YanLabsSWOwnedDocument{Document=doc,Path=file,Name=Convert.ToString(row["name"]),Kind=type,Owner=owner,Run=runDirectory};state.Documents.Add(own);sessionOwnedDocuments[file]=own;if(SamePath(file,Convert.ToString(manifest["project"])))state.Main=own;if(SamePath(file,selected))selectedDoc=doc;}}
            if(state.Main==null||selectedDoc==null)throw new InvalidOperationException("Original main/selected native document was not reopened");
            if(operation=="open"){int error=0;native=true;app.ActivateDoc3(selectedDoc.GetTitle(),false,0,ref error);if(error!=0)throw new InvalidOperationException("Owned native document could not be activated");}
            var result=Inspect(state.Main.Document);result["ok"]=true;result["saved"]=!state.Main.Document.GetSaveFlag();result["project"]=manifest["project"];result["opened_project"]=selected;result["opened"]=true;result["opened_from_disk"]=mainFromDisk;result["opened_project_from_disk"]=selectedFromDisk;result["reopened"]=mainFromDisk;result["preview"]=manifest["preview"];result["native_documents"]=manifest["native_documents"];result["native_documents_provenance"]="Original saved result manifest; per-document reopened flags describe original execution, not this call";result["artifacts"]=manifest["artifacts"];result["outputs"]=manifest["outputs"];result["source_sha256"]=manifest["source_sha256"];result["binding_sha256"]=Hash(Encoding.UTF8.GetBytes(bindingJson));result["owner_sha256"]=owner;result["native_measurements"]=manifest["native_measurements"];result["pid"]=app.GetProcessID();DescribeOpenedDocument(result,Inspect(selectedDoc),selectedFromDisk);return result;
        } catch(Exception error){error.Data["native_stage"]=Stage;bool started=native||(state!=null&&state.NativeStarted);error.Data["execution_not_started"]=!started;error.Data["native_outcome_known"]=!ContainsComFailure(error);throw;}
    }
    private static string SimulationScopeCode() {
        string[][] folders={new[]{"Static","StaticStudyOptions","ICWStaticStudyOptions","ResultFolder"},new[]{"Frequency","FrequencyStudyOptions","ICWFrequencyStudyOptions","ResultFolder"},new[]{"Buckling","BucklingStudyOptions","ICWBucklingStudyOptions","ResultFolder"},new[]{"Thermal","ThermalStudyOptions","ICWThermalStudyOptions","ResultFolder"},new[]{"Nonlinear","NonLinearStudyOptions","ICWNonLinearStudyOptions","ResultFolderPath"},new[]{"DropTest","DropTestStudyOptions","ICWDropTestStudyOptions","ResultFolder"},new[]{"Fatigue","FatigueStudyOptions","ICWFatigueStudyOptions","ResultFolder"},new[]{"Dynamic","DynamicStudyOptions","ICWDynamicStudyOptions","ResultFolderPath"}};
        var routes=new StringBuilder();foreach(string[] route in folders)routes.Append("case (int)swsAnalysisStudyType_e.swsAnalysisStudyType"+route[0]+": {"+route[2]+" o=("+route[2]+")s."+route[1]+";o."+route[3]+"=directory;actual=o."+route[3]+";break;}");
        return "private static void Scope(ICWStudy s,string directory){string actual=null;switch(s.AnalysisType){"+routes+"default:throw new InvalidOperationException(\"This study type has no verified scoped result-folder route; no mesh or solve was attempted\");}if(!String.Equals(Path.GetFullPath(actual).TrimEnd('\\\\'),Path.GetFullPath(directory).TrimEnd('\\\\'),StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException(\"Native Simulation result folder was not confined to this run; no mesh or solve was attempted\");s.OffLoad=false;if(s.OffLoad)throw new InvalidOperationException(\"Only local owned Simulation execution is available\");}";
    }
    private static Dictionary<string,object> InvokeSimulationBridge(string operationCode,object[] arguments) {
        string pia=Path.Combine(Path.GetDirectoryName(typeof(ISldWorks).Assembly.Location),"SolidWorks.Interop.cosworks.dll");if(!File.Exists(pia))throw new InvalidOperationException("Installed Simulation API is unavailable");
        string code="using System;using System.IO;using System.Collections.Generic;using SolidWorks.Interop.cosworks;public static class YanLabsTypedSimulation {"+SimulationScopeCode()+operationCode+"}";
        var parameters=new CompilerParameters(new[]{"System.dll",pia}){GenerateInMemory=true,GenerateExecutable=false};CompilerResults compiled;using(var provider=new CSharpCodeProvider())compiled=provider.CompileAssemblyFromSource(parameters,code);if(compiled.Errors.HasErrors)throw new InvalidOperationException("Installed Simulation API compilation failed: "+compiled.Errors[0].ErrorText);
        try{return (Dictionary<string,object>)compiled.CompiledAssembly.GetType("YanLabsTypedSimulation").GetMethod("Run").Invoke(null,arguments);}catch(TargetInvocationException error){throw error.InnerException??error;}
    }
    internal static Dictionary<string,object> MeshSimulation(object study,int units,double size,double tolerance,string directory) {
        string code="public static Dictionary<string,object> Run(object value,int units,double size,double tolerance,string directory){ICWStudy s=(ICWStudy)value;Scope(s,directory);int status=s.CreateMesh(units,size,tolerance);if(status!=0)throw new InvalidOperationException(\"Simulation CreateMesh returned \"+status);ICWMesh m=(ICWMesh)s.Mesh;if(m==null||m.NodeCount<=0||m.ElementCount<=0)throw new InvalidOperationException(\"Simulation meshing did not return a positive native mesh\");return new Dictionary<string,object>{{\"operation\",\"mesh\"},{\"mesh_return_code\",status},{\"analysis_type\",s.AnalysisType},{\"node_count\",m.NodeCount},{\"element_count\",m.ElementCount},{\"mesh_units\",units},{\"element_size\",size},{\"tolerance\",tolerance},{\"result_directory\",directory},{\"solver_executed\",false},{\"license_verified_by_this_solve\",false}};}";
        return InvokeSimulationBridge(code,new object[]{study,units,size,tolerance,directory});
    }
    internal static Dictionary<string,object> SolveSimulation(object study,string quantity,int component,int step,int unit,string directory) {
        string method=quantity=="displacement"?"r.GetMinMaxDisplacement(component,step,null,unit,out e)":quantity=="stress"?"r.GetMinMaxStress(component,0,step,null,unit,out e)":quantity=="strain"?"r.GetMinMaxStrain(component,0,step,null,out e)":quantity=="thermal"?"r.GetMinMaxThermal(component,step,null,unit,out e)":null;if(method==null)throw new ArgumentException("Use displacement, stress, strain or thermal numerical readback");
        string code="public static Dictionary<string,object> Run(object value,int component,int step,int unit,string directory){ICWStudy s=(ICWStudy)value;Scope(s,directory);int solve=s.RunAnalysis();if(solve!=0)throw new InvalidOperationException(\"Simulation RunAnalysis returned \"+solve);ICWMesh m=(ICWMesh)s.Mesh;ICWResults r=(ICWResults)s.Results;if(m==null||r==null||m.NodeCount<=0||m.ElementCount<=0)throw new InvalidOperationException(\"Simulation did not return a positive native mesh/results\");int e=0;object raw="+method+";Array a=raw as Array;if(e!=0||a==null||a.Length<4)throw new InvalidOperationException(\"Actual Simulation numerical result readback failed: \"+e);double[] data=new double[a.Length];for(int i=0;i<a.Length;i++){data[i]=Convert.ToDouble(a.GetValue(i));if(Double.IsNaN(data[i])||Double.IsInfinity(data[i]))throw new InvalidOperationException(\"Non-finite Simulation result\");}return new Dictionary<string,object>{{\"solver_return_code\",solve},{\"analysis_type\",s.AnalysisType},{\"node_count\",m.NodeCount},{\"element_count\",m.ElementCount},{\"result_error\",e},{\"native_minmax_array\",data},{\"result_directory\",directory},{\"license_verified_by_this_solve\",true}};}";
        var result=InvokeSimulationBridge(code,new object[]{study,component,step,unit,directory});result["quantity"]=quantity;result["component_enum"]=component;result["step"]=step;result["unit_enum"]=unit;return result;
    }
    public static Dictionary<string,object> Discovery(object raw){string folder=Path.GetDirectoryName(typeof(ISldWorks).Assembly.Location);var data=new Dictionary<string,object>{{"api","official installed SOLIDWORKS COM/.NET interop"},{"model_source","C# Build method body; owned-document context"},{"general_geometry",true},{"assemblies",true},{"drawings",true},{"simulation_api_present",File.Exists(Path.Combine(folder,"SolidWorks.Interop.cosworks.dll"))},{"simulation_license_verified",false},{"simulation_note","A DLL/add-in object is not a successful licensed solve; RunSimulationStudy checks the actual solver and numerical results"}};if(raw!=null){var app=(ISldWorks)raw;data["pid"]=app.GetProcessID();data["revision"]=app.RevisionNumber();}return data;}
    public static Dictionary<string,object> Reflect(object raw,string typeName,string memberName){var result=Discovery(raw);var assemblies=YanLabsSWScriptCompiler.PiaAssemblies();if(String.IsNullOrWhiteSpace(typeName)){
        var commonNames=new HashSet<string>(new[]{"IModelDoc2","ISketchManager","IFeatureManager","IRefPlane","IEntity","ISelectionMgr","IFeature","IPartDoc","IBody2","IFace2","IEdge","IAssemblyDoc","IComponent2","IMate2","IDrawingDoc","IView","ISheet","IDimension","IExtrudeFeatureData2","IRevolveFeatureData2","ILoftFeatureData","IRefPlaneFeatureData","ICosmosWorks","ICWModelDoc","ICWStudyManager","ICWStudy","ICWMesh","ICWResults","ICwAddincallback","swEndConditions_e","swRefPlaneReferenceConstraints_e","swMateType_e","swMateAlign_e"},StringComparer.Ordinal);
        var common=new List<string>();var counts=new List<Dictionary<string,object>>();int count=0;foreach(Assembly assembly in assemblies){int local=0;foreach(Type type in assembly.GetExportedTypes())if(type.IsInterface||type.IsEnum){local++;if(commonNames.Contains(type.Name))common.Add(type.FullName);}count+=local;counts.Add(new Dictionary<string,object>{{"assembly",assembly.GetName().Name},{"interface_enum_count",local}});}common.Sort(StringComparer.Ordinal);var methods=new List<string>();foreach(MethodInfo method in typeof(YanLabsSWContext).GetMethods(BindingFlags.Public|BindingFlags.Instance|BindingFlags.DeclaredOnly))methods.Add(method.ToString());result["installed_interface_enum_count"]=count;result["assemblies"]=counts;result["common_types"]=common;result["context_type"]="YanLabsSWContext";result["context_methods"]=methods;result["query_hint"]="Use api --type IFeatureManager --member InsertProtrusionBlend2 (or any exact installed official type/member). This summary does not enumerate the whole SDK.";return result;
        }if(!Regex.IsMatch(typeName,@"^[A-Za-z_][A-Za-z0-9_.]{0,180}$")||(!String.IsNullOrEmpty(memberName)&&!Regex.IsMatch(memberName,@"^[A-Za-z_][A-Za-z0-9_]{0,160}$")))throw new ArgumentException("Invalid API metadata query");Type selected=null;if(typeName=="YanLabsSWContext")selected=typeof(YanLabsSWContext);else foreach(var assembly in assemblies)foreach(var type in assembly.GetExportedTypes())if(type.Name==typeName||type.FullName==typeName){if(selected!=null&&selected!=type)throw new ArgumentException("Ambiguous API type; use the full namespace");selected=type;}if(selected==null)throw new ArgumentException("Requested type is not in the installed official API");var members=new List<Dictionary<string,object>>();foreach(var method in selected.GetMethods()){if(!String.IsNullOrEmpty(memberName)&&method.Name!=memberName)continue;var parameters=new List<Dictionary<string,object>>();foreach(var parameter in method.GetParameters())parameters.Add(new Dictionary<string,object>{{"name",parameter.Name},{"type",parameter.ParameterType.ToString()},{"out",parameter.IsOut},{"optional",parameter.IsOptional}});string reason=YanLabsSWScriptCompiler.BlockReason(method);members.Add(new Dictionary<string,object>{{"name",method.Name},{"signature",method.ToString()},{"return_type",method.ReturnType.ToString()},{"parameters",parameters},{"script_allowed",reason==null},{"context_wrapper_required",reason}});}result["type"]=selected.FullName;result["members"]=members;if(selected.IsEnum){var values=new Dictionary<string,object>();foreach(string name in Enum.GetNames(selected))values[name]=Convert.ToInt64(Enum.Parse(selected,name));result["enum_values"]=values;}return result;}
}

public static class YanLabsSWScriptCompiler {
    private static readonly Dictionary<short,OpCode> Opcodes=BuildOpcodes();
    private static Dictionary<short,OpCode> BuildOpcodes(){var result=new Dictionary<short,OpCode>();foreach(var field in typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static))if(field.FieldType==typeof(OpCode)){OpCode op=(OpCode)field.GetValue(null);result[op.Value]=op;}return result;}
    // C# emits RVA-backed data containers for ordinary numeric array
    // literals. Accept only that exact compiler shape, never model helper classes
    // or general ldtoken/reflection access; model writes to static fields are denied.
    private static bool CompilerDataType(Type type){
        if(type==null)return false;
        if(type.IsNested){Type root=type.DeclaringType;return root!=null&&root.Name.StartsWith("<PrivateImplementationDetails>",StringComparison.Ordinal)&&root.IsDefined(typeof(System.Runtime.CompilerServices.CompilerGeneratedAttribute),false)&&type.IsValueType&&type.IsExplicitLayout&&type.StructLayoutAttribute.Size>0&&type.StructLayoutAttribute.Size<=1024*1024&&type.GetFields(BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).Length==0&&type.GetMethods(BindingFlags.DeclaredOnly|BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).Length==0;}
        if(!type.IsClass||type.IsPublic||!type.Name.StartsWith("<PrivateImplementationDetails>",StringComparison.Ordinal)||!type.IsDefined(typeof(System.Runtime.CompilerServices.CompilerGeneratedAttribute),false))return false;
        if(type.GetMethods(BindingFlags.DeclaredOnly|BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).Length!=0||type.GetConstructors(BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).Length!=0)return false;
        foreach(FieldInfo field in type.GetFields(BindingFlags.DeclaredOnly|BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic))if(!field.IsStatic||(field.Attributes&FieldAttributes.HasFieldRVA)==0||!CompilerDataType(field.FieldType))return false;return true;
    }
    private static bool CompilerDataField(FieldInfo field){return field!=null&&CompilerDataType(field.DeclaringType)&&field.IsStatic&&(field.Attributes&FieldAttributes.HasFieldRVA)!=0&&CompilerDataType(field.FieldType);}
    internal static List<Assembly> PiaAssemblies(){string root=Path.GetDirectoryName(typeof(ISldWorks).Assembly.Location);var assemblies=new List<Assembly>{typeof(ISldWorks).Assembly};foreach(string file in Directory.GetFiles(root,"SolidWorks.Interop.*.dll")){Assembly assembly=Assembly.LoadFrom(file);if(!assemblies.Contains(assembly))assemblies.Add(assembly);}return assemblies;}
    private static bool DesktopInputOrControlType(Type type){if(type==null)return false;string full=type.FullName??"";if(!full.StartsWith("SolidWorks.Interop.",StringComparison.Ordinal))return false;return Regex.IsMatch(type.Name,@"(?i)^(I?(Mouse|Keyboard|Frame|ModelWindow|LightDialog|Print3DDialog|CommandManager|CommandGroup|CommandTab(Box)?|TaskpaneView|TreeControlItem|UserProgressBar|UserNotificationDefinition|JournalManager|FeatMgrView)(Class)?|I?PropertyManagerPage.*|D(Mouse|Keyboard|TaskpaneView)Events.*)$");}
    private static bool AllowedType(Type type){if(type==null)return true;if(type.IsByRef||type.IsArray)return AllowedType(type.GetElementType());if(type.IsPointer)return false;if(type.IsGenericParameter)return true;if(type.IsGenericType){foreach(var argument in type.GetGenericArguments())if(!AllowedType(argument))return false;}if(DesktopInputOrControlType(type))return false;string name=type.FullName??type.Name;if(type.Assembly==typeof(ISldWorks).Assembly||name.StartsWith("SolidWorks.Interop."))return true;if(type==typeof(YanLabsSWContext)||type==typeof(IYanLabsSWModel))return true;if(name=="YanLabsUserModel"||CompilerDataType(type))return true;if(type.IsPrimitive&&type!=typeof(IntPtr)&&type!=typeof(UIntPtr))return true;if(type==typeof(void)||type==typeof(object)||type==typeof(string)||type==typeof(decimal)||type==typeof(Math)||type==typeof(Convert)||type==typeof(Array)||type==typeof(Enum)||type==typeof(Exception)||type==typeof(InvalidOperationException)||type==typeof(ArgumentException)||type==typeof(ArgumentNullException)||type==typeof(IDisposable)||type==typeof(StringComparison)||type==typeof(StringSplitOptions)||type==typeof(MidpointRounding))return true;if(name.StartsWith("System.Collections.Generic.")||name=="System.Collections.IEnumerable"||name=="System.Collections.IEnumerator"||name=="System.Text.StringBuilder"||name=="System.Globalization.CultureInfo"||name=="System.Globalization.NumberStyles")return true;return false;}
    internal static string BlockReason(MethodBase method){
        if(method.DeclaringType==typeof(System.Runtime.CompilerServices.RuntimeHelpers)&&method.IsStatic&&method.Name=="InitializeArray"){ParameterInfo[] p=method.GetParameters();if(p.Length==2&&p[0].ParameterType==typeof(Array)&&p[1].ParameterType==typeof(RuntimeFieldHandle))return null;}
        Type type=method.DeclaringType;if(DesktopInputOrControlType(type))return "Mouse/keyboard input, desktop windows and UI controls are unavailable; use semantic owned CAD APIs";if(!AllowedType(type))return "Use only owned CAD APIs, numeric/collection helpers and the fixed context";
        foreach(var parameter in method.GetParameters())if(!AllowedType(parameter.ParameterType))return "Unsupported reflected/pointer/system type";MethodInfo info=method as MethodInfo;if(info!=null&&!AllowedType(info.ReturnType))return "Unsupported reflected/pointer/system return type";
        if(type==typeof(YanLabsSWContext))return method.IsPublic&&method.Name!="GetType"?null:"Use public context operations";
        string name=method.Name,full=type.FullName??"";if(type==typeof(object)&&Array.IndexOf(new[]{".ctor","ToString","Equals","ReferenceEquals","GetHashCode"},name)<0)return "Object reflection/runtime access is unavailable";
        if(full.StartsWith("SolidWorks.Interop.")){
            if(method.IsConstructor)return "Official COM objects must come from the scoped native context, never CoClass constructors";
            if(typeof(ISldWorks).IsAssignableFrom(type)||type.Name=="ISldWorks"||type.Name=="SldWorks")return "Application lifetime/document operations must use ctx";
            // Native entity selection and deterministic model-view APIs remain
            // available. Official PIA mouse drivers or interactive viewport modes
            // are still desktop input and must never become a GUI fallback.
            if(Regex.IsMatch(name,@"(?i)(Mouse|Keyboard|SendKeys?|Keybd|Keystroke|ScreenShot|ScreenCapture|CaptureScreen|CaptureDesktop|CopyFromScreen|GetDesktop|SendInput|PostMessage|SendMessage|SetFocus|Foreground|WindowHandle|GetViewHWnd|GetFeatureTreeRootItem)"))return "Desktop input, screen capture and UI/window automation are unavailable in model source";
            if(Regex.IsMatch(name,@"(?i)(^I?(Add|Get|Delete)Control[0-9]*$|CreateFeatureMgr(View|Control|Window)|DisplayWindowFromHandle|GetFeatureMgrViewHWnd|ControlTab|CommandTab|ModelTab|FeatureManagerTab|PropertyManagerTabIndex|DimXpertManagerTabIndex|DisplayManagerTabIndex|FeatureManagerTreeTabIndex)"))return "Embedded executable/window controls and desktop tab automation are unavailable in model source";
            if(Regex.IsMatch(type.Name,@"(?i)^I?CwAddincallback(Class)?$")&&!String.Equals(name,"get_CosmosWorks",StringComparison.OrdinalIgnoreCase))return "Use the owned Simulation document API; application UI callbacks are not scoped model operations";
            if(Regex.IsMatch(type.Name,@"(?i)^I?CosmosWorks(Class)?$")&&name!="get_ActiveDoc"&&name!="get_VersionNumber")return "Only the current owned Simulation document and version are exposed by the application object";
            if(Regex.IsMatch(name,@"(?i)(Macro|ActiveX|ConnectToSW|DisconnectFromSW)")||name.Contains("OLE")||Regex.IsMatch(name,@"CreateFeatureMgr(Control|WindowFromHandle)"))return "Macros, embedded executable controls and add-in lifecycle operations are unavailable in model source";
            if(full.StartsWith("SolidWorks.Interop.cosworks.")&&Regex.IsMatch(name,@"(?i)(^I?(Run|MeshAndRun|CreateMesh)|AnalysisDatabase|DistributedSimulation|set_OffLoad|SetSimulationOption)"))return "Use ctx.CreateSimulationMesh and ctx.RunSimulationStudy for scoped local mesh/solve and actual result readback";
            if(Regex.IsMatch(name,@"(?i)(RunMacro|RunCommand|RunAnalysis|Execute|Shell|CloseDoc|CloseAll|ExitApp|OpenDoc|NewDocument|NewPart|NewAssembly|NewDrawing|GetSwApp|GetFirstDocument|GetDocuments|ActivateDoc|GetPackAndGo|UnloadAddIn|GetAddInObject|InsertObject|CreateOLE|GetNextDocument|IGetNextDocument|AddComponents?|ReplaceComponents?|CreateDrawViewFromModelView|Create[13](st|rd)AngleViews)"))return "Use the scoped context for application, file, solve or lifecycle operations";
            if(Regex.IsMatch(name,@"(?i)^I?(Save|Load|Open|Close|Print|Export|Import)"))return "Native file/lifecycle operations require a scoped context wrapper";
            if(Regex.IsMatch(type.Name,@"^I?ModelDoc[0-9]*$")&&(name=="GetNext"||name=="IGetNext"))return "Document traversal must use ctx";
            // COM property-put arguments are often named Retval/value, not the
            // property's file path. Inspect both the member and input metadata.
            bool numericCurveBuilder=Regex.IsMatch(type.Name,@"^I?ModelDoc[0-9]*$")&&Array.IndexOf(new[]{"InsertCurveFileBegin","InsertCurveFilePoint","InsertCurveFileEnd"},name)>=0;
            bool logicalFeatureFolder=Regex.IsMatch(type.Name,@"^I?FeatureManager$")&&name=="MoveToFolder";
            ParameterInfo[] sketchToggleParameters=method.GetParameters();
            bool sketchDatabaseToggle=type==typeof(ISketchManager)&&name=="set_AddToDB"&&info!=null&&!info.IsStatic&&info.ReturnType==typeof(void)&&sketchToggleParameters.Length==1&&sketchToggleParameters[0].ParameterType==typeof(bool);
            if(!numericCurveBuilder&&!name.StartsWith("get_",StringComparison.Ordinal)&&!Regex.IsMatch(name,@"^I?Get")&&Regex.IsMatch(name,@"(?i)((?<!pro)file|library|macro|database|folderpath|directory)"))return "Native file references, libraries and paths require a scoped context wrapper";
            foreach(var parameter in method.GetParameters()){
                if(parameter.IsOut)continue;
                // The official Boolean sketch-mode setter calls its flag
                // ToDatabase; it accepts no database or file path.
                if(!logicalFeatureFolder&&!(sketchDatabaseToggle&&parameter.Name=="ToDatabase")&&Regex.IsMatch(parameter.Name??"",@"(?i)((?<!pro)file|folder|directory|macro|document.?name|doc.?name|model.?name|template|database|library)"))return "File-bearing native operations require a scoped context wrapper";
                if(!logicalFeatureFolder&&parameter.ParameterType==typeof(string)&&Regex.IsMatch(name+" "+(parameter.Name??""),@"(?i)(path|folder|directory|database|library)"))return "String-valued native paths require a scoped context wrapper";
            }
        }
        return null;
    }
    private static void CheckType(Type type){if(!AllowedType(type))throw new InvalidOperationException("Model source uses a prohibited type: "+type.FullName);}
    private static void Audit(MethodBase method){if((method.Attributes&MethodAttributes.PinvokeImpl)!=0)throw new InvalidOperationException("Native imports are unavailable in model source");MethodBody body=method.GetMethodBody();if(body==null)return;foreach(var local in body.LocalVariables)CheckType(local.LocalType);byte[] il=body.GetILAsByteArray();int cursor=0;while(cursor<il.Length){short code=il[cursor++];if(code==0xfe)code=(short)(0xfe00|il[cursor++]);OpCode op;if(!Opcodes.TryGetValue(code,out op))throw new InvalidOperationException("Unknown model IL opcode");if(op==OpCodes.Calli||op==OpCodes.Jmp||op==OpCodes.Ldftn||op==OpCodes.Ldvirtftn||op==OpCodes.Localloc)throw new InvalidOperationException("Function pointers, unsafe code and runtime metadata access are unavailable");if(op==OpCodes.Ldtoken&&!CompilerDataField(method.Module.ResolveMember(BitConverter.ToInt32(il,cursor)) as FieldInfo))throw new InvalidOperationException("Runtime metadata tokens are unavailable except compiler numeric-array constants");int size=0;switch(op.OperandType){case OperandType.InlineNone:size=0;break;case OperandType.ShortInlineBrTarget:case OperandType.ShortInlineI:case OperandType.ShortInlineVar:size=1;break;case OperandType.InlineVar:size=2;break;case OperandType.InlineI8:case OperandType.InlineR:size=8;break;case OperandType.InlineSwitch:int count=BitConverter.ToInt32(il,cursor);if(count<0||count>(il.Length-cursor-4)/4)throw new InvalidOperationException("Invalid model switch");size=4+count*4;break;default:size=4;break;}if(cursor+size>il.Length)throw new InvalidOperationException("Invalid model IL operand");if(op.OperandType==OperandType.InlineMethod){MethodBase called=method.Module.ResolveMethod(BitConverter.ToInt32(il,cursor));string blocked=BlockReason(called);if(blocked!=null)throw new InvalidOperationException("Model API call blocked: "+called.DeclaringType.FullName+"."+called.Name+" — "+blocked);}else if(op.OperandType==OperandType.InlineType)CheckType(method.Module.ResolveType(BitConverter.ToInt32(il,cursor)));else if(op.OperandType==OperandType.InlineField){FieldInfo field=method.Module.ResolveField(BitConverter.ToInt32(il,cursor));CheckType(field.DeclaringType);CheckType(field.FieldType);if(op==OpCodes.Stsfld)throw new InvalidOperationException("Global mutable model state is unavailable");}cursor+=size;}}
    public static IYanLabsSWModel Compile(string source,string outputDirectory){if(String.IsNullOrWhiteSpace(source)||Encoding.UTF8.GetByteCount(source)>1024*1024)throw new ArgumentException("Model source must be a nonempty C# method body under 1 MiB");string own=typeof(YanLabsSWContext).Assembly.Location;if(String.IsNullOrWhiteSpace(own)||!File.Exists(own))throw new InvalidOperationException("The trusted native host API must be loaded from its private compiled DLL");var refs=new List<string>{"System.dll","System.Core.dll",own};bool simulation=false;foreach(var assembly in PiaAssemblies()){refs.Add(assembly.Location);if(assembly.GetName().Name=="SolidWorks.Interop.cosworks")simulation=true;}string wrapped="using System;using System.Collections.Generic;using SolidWorks.Interop.sldworks;using SolidWorks.Interop.swconst;"+(simulation?"using SolidWorks.Interop.cosworks;":"")+"public sealed class YanLabsUserModel:IYanLabsSWModel {public void Build(YanLabsSWContext ctx){\n"+source+"\n}}";var parameters=new CompilerParameters(refs.ToArray()){GenerateExecutable=false,GenerateInMemory=true,CompilerOptions="/optimize+ /unsafe-",TempFiles=new TempFileCollection(outputDirectory,false)};CompilerResults compiled;using(var provider=new CSharpCodeProvider())compiled=provider.CompileAssemblyFromSource(parameters,wrapped);if(compiled.Errors.HasErrors){var errors=new List<string>();foreach(CompilerError error in compiled.Errors)if(!error.IsWarning){errors.Add("line "+Math.Max(1,error.Line-1)+": "+error.ErrorText);if(errors.Count>=8)break;}throw new InvalidOperationException("SOLIDWORKS model source compilation failed: "+String.Join(" | ",errors.ToArray()));}Type[] types=compiled.CompiledAssembly.GetTypes();Type model=null;foreach(Type candidate in types){if(candidate.Name=="YanLabsUserModel"){if(model!=null)throw new InvalidOperationException("Multiple model entrypoints are unavailable");model=candidate;}else if(!CompilerDataType(candidate))throw new InvalidOperationException("Provide only the Build method body; additional model types or fields are unavailable");}if(model==null||model.GetFields(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static).Length!=0)throw new InvalidOperationException("Provide only the Build method body; additional model types or fields are unavailable");foreach(var method in model.GetMethods(BindingFlags.DeclaredOnly|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static))Audit(method);foreach(var constructor in model.GetConstructors(BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static))Audit(constructor);return (IYanLabsSWModel)Activator.CreateInstance(model);}
}
