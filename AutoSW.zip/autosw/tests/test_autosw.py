"""Offline protocol/scope tests. Fake native runner; never COM/UI/model/network."""
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import queue
import time
import unittest
import uuid

sys.dont_write_bytecode = True
SCRIPTS = Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(SCRIPTS))
from autosw_runtime import CORE_FILES, IDENTITY, Runtime, AutoSWError, public, relative_path
from autosw_mcp import Server, MODERN, LEGACY, DEFINITIONS, serve

CONNECTION = dict(host_id='d3f529b0-b053-44df-946c-1a15a1417398',host_pid=101,
    host_process_start_ticks='639000000000000001',pid=202,process_start_ticks='639000000000000002',hwnd=303)


class Fixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='AutoSW-offline-')
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.workspace = self.base/'中文项目'; self.workspace.mkdir()
        self.package = self.base/'package'; (self.package/'bridge').mkdir(parents=True)
        files = {}
        for name in CORE_FILES:
            data = ('offline fixture only '+name).encode()
            (self.package/'bridge'/name).write_bytes(data)
            files[name] = hashlib.sha256(data).hexdigest()
        aggregate = hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        (self.package/'bridge-manifest.json').write_text(json.dumps(dict(files=files,sha256=aggregate)))
        self.calls = []; self.next_receipt = None; self.connect_receipt = None
        self.runtime = self.make_runtime()

    def make_runtime(self):
        return Runtime(self.workspace,self.package,_runner=self.runner,_private=(self.base/'private','local-offline-owner'))

    def runner(self,args):
        self.calls.append(args)
        command = args[4]
        intent=json.loads(args[args.index('--connect-intent-json')+1]) if '--connect-intent-json' in args else None
        def decorated(body):
            body=copy.deepcopy(body)
            if intent:
                if body.get('connect_id') in (None,'AUTO'):body['connect_id']=intent['connect_id']
                body.setdefault('source_sha256',intent['source_sha256'])
            return body
        if command=='connect':
            if self.connect_receipt is not None:
                code,body=self.connect_receipt;return code,decorated(body)
            return 0,decorated(dict(ok=True,connected=True,status='idle',busy=False,**CONNECTION))
        if self.next_receipt is not None:
            code,body = self.next_receipt
            if '--run-id' in args and body.get('run_id')=='AUTO':
                body = dict(body,run_id=args[args.index('--run-id')+1])
            return code,decorated(body)
        result = dict(ok=True,connected=True,status='idle',busy=False,**CONNECTION)
        if '--run-id' in args:
            result.update(state='completed',run_id=args[args.index('--run-id')+1])
        return 0,decorated(result)

    def source(self):
        return self.runtime.write_script('sources/模型.cs','var doc = ctx.NewPart("Test");\n')

    def do_run(self,key='operation-1'):
        self.runtime.connect(); source=self.source()
        return self.runtime.run_script(source['path'],source['sha256'],key)


class RuntimeTests(Fixture):
    def test_verify_and_catalog_never_use_native(self):
        self.assertTrue(self.runtime.catalog()['ok']); self.assertEqual(self.calls,[])
        self.assertFalse((self.base/'private').exists())

    def test_manifest_drift_prevents_any_native(self):
        (self.package/'bridge/core.py').write_text('changed')
        with self.assertRaises(AutoSWError): self.runtime.connect()
        self.assertEqual(self.calls,[])

    def test_status_before_explicit_connect_never_adopts_global_host(self):
        self.assertFalse(self.runtime.status()['connected']); self.assertEqual(self.calls,[])

    def test_session_persists_without_exposing_private_binding(self):
        self.runtime.init(); old=json.loads((self.base/'private/state.json').read_text())
        self.make_runtime().init(); new=json.loads((self.base/'private/state.json').read_text())
        self.assertEqual(old['session_id'],new['session_id'])
        self.assertNotIn('session_id',self.runtime.init())

    def test_script_requires_connect_and_accepted_hash(self):
        source=self.source()
        with self.assertRaises(AutoSWError): self.runtime.run_script(source['path'],source['sha256'],'one')
        self.runtime.connect()
        with self.assertRaises(AutoSWError): self.runtime.run_script(source['path'],'0'*64,'one')
        self.assertEqual(len(self.calls),1)

    def test_binding_six_fields_injected_and_source_is_frozen(self):
        result=self.do_run(); call=self.calls[-1]
        self.assertEqual(json.loads(call[call.index('--expected-connection-json')+1]),CONNECTION)
        binding=json.loads(call[call.index('--binding-json')+1])
        self.assertEqual(binding['workspace'],str(self.workspace)); self.assertNotEqual(binding['session_id'],'standalone-local')
        accepted=call[call.index('--script')+1]
        self.assertTrue(accepted.startswith('autosw-accepted/'))
        self.assertEqual((self.workspace/accepted).read_bytes(),(self.workspace/'sources/模型.cs').read_bytes())
        self.assertTrue(result['ok']); self.assertFalse(set(IDENTITY)&set(result))

    def test_repeated_intent_returns_receipt_without_replay(self):
        result=self.do_run(); source=self.runtime.write_script('sources/other.cs','int x = 1;')
        oldsource=(self.workspace/'sources/模型.cs').read_bytes()
        again=self.runtime.run_script('sources/模型.cs',hashlib.sha256(oldsource).hexdigest(),'operation-1')
        self.assertEqual(result['run_id'],again['run_id']); self.assertTrue(again['cached_receipt'])
        self.assertEqual(len(self.calls),2)
        with self.assertRaises(AutoSWError): self.runtime.run_script(source['path'],source['sha256'],'operation-1')

    def test_exit_one_unknown_persists_and_blocks_new_run_and_reconnect(self):
        self.next_receipt=(1,dict(ok=False,state='unknown',code='SW_OPERATION_UNKNOWN',run_id='AUTO',execution_not_started=False))
        result=self.do_run(); self.assertEqual(result['process_exit_code'],1)
        self.runtime=self.make_runtime()
        with self.assertRaises(AutoSWError): self.runtime.connect()
        source=(self.workspace/'sources/模型.cs').read_bytes()
        with self.assertRaises(AutoSWError): self.runtime.run_script('sources/模型.cs',hashlib.sha256(source).hexdigest(),'replacement')
        self.assertEqual(len(self.calls),2)

    def test_busy_exit_zero_does_not_resolve_business_unknown(self):
        self.next_receipt=(0,dict(ok=True,state='unknown',status='unknown',busy=True,run_id='AUTO',**CONNECTION))
        result=self.do_run(); self.assertEqual(result['process_exit_code'],0)
        self.next_receipt=(0,dict(ok=True,status='idle',busy=False,**CONNECTION))
        self.assertEqual(self.runtime.status()['pending_run'],result['run_id'])
        self.assertTrue(self.runtime.status()['original_run_requires_readback'])

    def test_readback_requires_original_run_then_unlocks_positive_proof(self):
        self.next_receipt=(1,dict(ok=False,state='unknown',run_id='AUTO'))
        result=self.do_run()
        with self.assertRaises(AutoSWError): self.runtime.readback(str(uuid.uuid4()))
        self.next_receipt=None
        self.assertTrue(self.runtime.readback(result['run_id'])['ok'])
        self.assertIsNone(self.runtime.status()['pending_run'])
        self.assertEqual(json.loads(self.calls[-2][self.calls[-2].index('--expected-connection-json')+1]),CONNECTION)

    def test_wrong_run_or_connection_cannot_clear_pending(self):
        self.next_receipt=(0,dict(ok=True,state='completed',run_id=str(uuid.uuid4()),**CONNECTION))
        result=self.do_run(); self.assertEqual(result['code'],'AUTOSW_RUN_MISMATCH')
        wrong=dict(CONNECTION,pid=999)
        self.next_receipt=(0,dict(ok=True,state='completed',run_id='AUTO',**wrong))
        self.assertEqual(self.runtime.readback(result['run_id'])['code'],'AUTOSW_CONNECTION_CHANGED')

    def test_completion_missing_identity_or_bad_process_exit_remains_unknown(self):
        self.next_receipt=(0,dict(ok=True,state='completed',run_id='AUTO'))
        self.assertEqual(self.do_run()['code'],'AUTOSW_INCOMPLETE_NATIVE_PROOF')

    def test_definite_preexecution_failure_does_not_lock_replacement(self):
        self.next_receipt=(1,dict(ok=False,state='failed',run_id='AUTO',execution_not_started=True))
        self.do_run(); self.next_receipt=None
        self.assertIsNone(self.runtime.status()['pending_run'])

    def test_known_failed_run_allows_only_owned_cleanup_not_open(self):
        self.next_receipt=(1,dict(ok=False,state='failed',run_id='AUTO',native_outcome_known=True))
        failed=self.do_run(); self.next_receipt=None
        with self.assertRaises(AutoSWError): self.runtime.open(failed['run_id'])
        self.assertTrue(self.runtime.cleanup(failed['run_id'])['ok'])
        self.assertEqual(self.calls[-1][4],'cleanup')

    def test_unsafe_source_and_input_paths(self):
        for path in ('../secret.cs','sources/../escape.cs','C:/x.cs','sources/x.cs:secret','sources/NUL.cs','sources/a./x.cs','sources\\x.cs'):
            with self.subTest(path=path),self.assertRaises(AutoSWError): self.runtime.write_script(path,'int x=0;')
        (self.workspace/'inputs').mkdir(); (self.workspace/'inputs/data.png').write_bytes(b'not-a-real-image')
        self.assertEqual(self.runtime.input_inspect('inputs/data.png')['bytes'],16)
        (self.workspace/'inputs/private.key').write_bytes(b'test')
        with self.assertRaises(AutoSWError): self.runtime.input_inspect('inputs/private.key')

    def test_source_replace_requires_exact_prior_sha(self):
        source=self.source()
        with self.assertRaises(AutoSWError): self.runtime.write_script(source['path'],'int x=0;')
        updated=self.runtime.write_script(source['path'],'int x=0;',source['sha256'])
        self.assertNotEqual(source['sha256'],updated['sha256'])

    def test_link_or_hardlink_rejected(self):
        source=self.source(); outside=self.base/'outside.cs'; outside.write_text('int x=0;')
        hard=self.workspace/'sources/hard.cs'
        os.link(outside,hard)
        with self.assertRaises(AutoSWError): relative_path(self.workspace,'sources/hard.cs')
        try: (self.workspace/'sources/link.cs').symlink_to(outside)
        except OSError: return
        with self.assertRaises(AutoSWError): relative_path(self.workspace,'sources/link.cs')

    def test_public_receipt_hides_private_identity_recursively(self):
        value=public(dict(**CONNECTION,nested=[dict(account_id='test',session_id='test',binding_json='secret',volume=1.0)]))
        self.assertEqual(value,{'nested':[{'volume':1.0}]})

    def test_connect_unknown_is_durable_and_no_second_connect_or_cad(self):
        self.connect_receipt=(1,dict(ok=False,state='unknown',code='SW_OPERATION_UNKNOWN'))
        result=self.runtime.connect();self.assertEqual(result['state'],'unknown')
        self.runtime=self.make_runtime()
        with self.assertRaises(AutoSWError):self.runtime.connect()
        with self.assertRaises(AutoSWError):self.runtime.api('IModelDoc2')
        source=self.source()
        with self.assertRaises(AutoSWError):self.runtime.run_script(source['path'],source['sha256'],'unsafe-retry')
        self.assertEqual(len(self.calls),1)
        state=json.loads((self.base/'private/state.json').read_text())
        self.assertEqual(state['connect_attempt']['intent']['connect_id'],result['connect_id'])
        self.assertEqual(state['connect_attempt']['intent']['binding']['session_id'],state['session_id'])

    def test_status_recovers_only_original_connect_without_second_connect(self):
        self.connect_receipt=(1,dict(ok=False,state='unknown',code='SW_OPERATION_UNKNOWN'))
        old=self.runtime.connect();self.runtime=self.make_runtime();self.connect_receipt=None
        recovered=self.runtime.status()
        self.assertTrue(recovered['ok']);self.assertIsNone(recovered['pending_connect'])
        self.assertEqual(recovered['connect_id'],old['connect_id'])
        self.assertEqual([args[4] for args in self.calls],['connect','status'])
        state=json.loads((self.base/'private/state.json').read_text())
        self.assertEqual(state['connection'],CONNECTION)
        self.assertEqual(len(state['connect_attempt']['receipt_history']),2)
        self.assertEqual(state['connect_attempt']['receipt_history'][0]['receipt']['state'],'unknown')

    def test_zero_or_mismatched_connect_proof_cannot_adopt_global_host(self):
        self.connect_receipt=(1,dict(ok=False,state='unknown',code='SW_OPERATION_UNKNOWN'))
        self.runtime.connect()
        for body in (dict(ok=False,state='unknown',code='SW_OPERATION_UNKNOWN'),
                     dict(ok=True,connected=True,status='idle',busy=False,connect_id=str(uuid.uuid4()),**CONNECTION),
                     dict(ok=True,connected=True,status='idle',busy=False,source_sha256='0'*64,**CONNECTION)):
            self.next_receipt=(0,body)
            result=self.runtime.status()
            self.assertFalse(result['ok']);self.assertEqual(result['state'],'unknown')
            self.assertIsNotNone(result['pending_connect'])
            state=json.loads((self.base/'private/state.json').read_text())
            self.assertIsNone(state['connection'])
        self.assertEqual([args[4] for args in self.calls],['connect','status','status','status'])

    def test_mcp_never_accepts_connect_intent_parameter(self):
        server=Server(self.runtime)
        response=server.process(dict(jsonrpc='2.0',id=1,method='tools/call',params=dict(
            _meta={'io.modelcontextprotocol/protocolVersion':MODERN,'io.modelcontextprotocol/clientCapabilities':{}},
            name='autosw_connect',arguments=dict(connect_intent_json='cannot-inject'))))
        self.assertEqual(response['error']['code'],-32602);self.assertEqual(self.calls,[])

    def legacy_cleanup_pending(self):
        result=self.do_run();run_id=result['run_id']
        file=self.base/'private/state.json';state=json.loads(file.read_text())
        run=state['runs'][run_id];run['state']='failed'
        run['receipt']=dict(ok=False,state='failed',run_id=run_id,code='SW_NATIVE_FAILED',process_exit_code=1)
        run['cleanup_receipt']=dict(ok=False,state='failed',run_id=run_id,code='SW_NATIVE_FAILED',
            process_exit_code=1,native_stage='plan_owned_native_document_unload',execution_not_started=False)
        state['pending_run']=run_id;state.pop('pending_operation',None)
        file.write_text(json.dumps(state));self.runtime=self.make_runtime()
        return run_id,copy.deepcopy(run)

    def healthy_idle(self,**changes):
        body=dict(ok=True,connected=True,status='connected',busy=False,native_operation=None,
                  source_sha256=self.runtime.verify()['bridge_sha256'],**CONNECTION)
        body.update(changes);self.next_receipt=(0,body)

    def test_known_failed_cleanup_releases_only_operation_and_preserves_cad_receipt(self):
        result=self.do_run();run_id=result['run_id'];before=json.loads((self.base/'private/state.json').read_text())['runs'][run_id]
        self.next_receipt=(1,dict(ok=False,state='failed',run_id='AUTO',code='SW_NATIVE_FAILED',execution_not_started=False))
        failed=self.runtime.cleanup(run_id);self.assertFalse(failed['ok'])
        state=json.loads((self.base/'private/state.json').read_text());run=state['runs'][run_id]
        self.assertIsNone(state['pending_run']);self.assertIsNone(state['pending_operation'])
        self.assertEqual(run['state'],before['state']);self.assertEqual(run['receipt'],before['receipt'])
        self.assertEqual(run['cleanup_receipt']['state'],'failed');self.assertEqual(run['result_operations'][-1]['state'],'failed')
        self.assertEqual(run['cleanup_receipt']['process_exit_code'],1)

    def test_known_failed_open_releases_occupancy_without_changing_completed_science(self):
        result=self.do_run();run_id=result['run_id']
        self.next_receipt=(1,dict(ok=False,state='failed',run_id='AUTO',code='SW_NATIVE_FAILED',**CONNECTION))
        self.runtime.open(run_id)
        state=json.loads((self.base/'private/state.json').read_text())
        self.assertIsNone(state['pending_run']);self.assertEqual(state['runs'][run_id]['state'],'completed')
        self.assertEqual(state['runs'][run_id]['open_receipt']['state'],'failed')

    def test_unknown_result_operation_cannot_be_cleared_by_idle_status_or_science_readback(self):
        result=self.do_run();run_id=result['run_id']
        self.next_receipt=(1,dict(ok=False,state='unknown',run_id='AUTO',code='SW_OPERATION_UNKNOWN'))
        self.runtime.cleanup(run_id);self.healthy_idle()
        status=self.runtime.status();self.assertEqual(status['pending_run'],run_id);self.assertIsNone(status['recovered_operation'])
        self.assertFalse(status['original_run_requires_readback']);self.assertEqual(status['pending_result_operation']['command'],'cleanup')
        count=len(self.calls)
        with self.assertRaises(AutoSWError):self.runtime.readback(run_id)
        with self.assertRaises(AutoSWError):self.runtime.disconnect()
        self.assertEqual(len(self.calls),count)
        state=json.loads((self.base/'private/state.json').read_text())
        self.assertEqual(state['pending_operation']['state'],'unknown');self.assertEqual(state['runs'][run_id]['state'],'completed')

    def test_legacy_known_failed_cleanup_recovers_from_exact_original_idle_status_without_replay(self):
        run_id,original=self.legacy_cleanup_pending();self.healthy_idle();before_calls=len(self.calls)
        status=self.runtime.status();self.assertIsNone(status['pending_run'])
        self.assertEqual(status['recovered_operation']['outcome'],'failed');self.assertFalse(status['recovered_operation']['action_replayed'])
        self.assertEqual([args[4] for args in self.calls[before_calls:]],['status'])
        state=json.loads((self.base/'private/state.json').read_text())
        self.assertEqual(state['runs'][run_id],original)
        proof=state['operation_recoveries'][-1];self.assertTrue(proof['legacy_marker'])
        self.assertEqual(proof['original_run_state'],'failed');self.assertFalse(proof['action_replayed'])

    def test_legacy_recovery_rejects_wrong_identity_source_busy_or_unresolved_native_operation(self):
        run_id,original=self.legacy_cleanup_pending()
        variants=[dict(pid=999),dict(source_sha256='0'*64),dict(busy=True),
                  dict(native_operation=dict(status='running',run_id=run_id)),dict(status='unknown')]
        for changes in variants:
            self.healthy_idle(**changes);status=self.runtime.status()
            self.assertEqual(status['pending_run'],run_id);self.assertIsNone(status['recovered_operation'])
        state=json.loads((self.base/'private/state.json').read_text())
        self.assertEqual(state['runs'][run_id],original);self.assertEqual(state['operation_recoveries'],[])

    def test_legacy_no_connect_source_proof_unknown_receipt_or_ambiguous_operation_stays_pending(self):
        run_id,original=self.legacy_cleanup_pending();file=self.base/'private/state.json'
        baseline=json.loads(file.read_text())
        variants=[]
        bad=copy.deepcopy(baseline);bad['connect_attempt']['intent']['source_sha256']='0'*64;variants.append(bad)
        bad=copy.deepcopy(baseline);bad['runs'][run_id]['cleanup_receipt']['state']='unknown';variants.append(bad)
        bad=copy.deepcopy(baseline);bad['runs'][run_id]['cleanup_receipt']['run_id']=str(uuid.uuid4());variants.append(bad)
        bad=copy.deepcopy(baseline);bad['runs'][run_id]['open_receipt']=copy.deepcopy(bad['runs'][run_id]['cleanup_receipt']);variants.append(bad)
        bad=copy.deepcopy(baseline);bad['runs'][run_id]['state']='unknown';bad['runs'][run_id]['receipt']['state']='unknown';variants.append(bad)
        for state in variants:
            file.write_text(json.dumps(state));self.healthy_idle();status=self.runtime.status()
            self.assertEqual(status['pending_run'],run_id);self.assertIsNone(status['recovered_operation'])
            self.assertEqual(json.loads(file.read_text())['operation_recoveries'],[])


class ProtocolTests(unittest.TestCase):
    class Fake:
        def catalog(self): return dict(ok=True,title='AutoSW 中文')

    def setUp(self): self.server=Server(self.Fake())

    def request(self,method,params=None,id=1,modern=True):
        params=dict(params or {})
        if modern: params['_meta']={'io.modelcontextprotocol/protocolVersion':MODERN,'io.modelcontextprotocol/clientCapabilities':{}}
        return self.server.process(dict(jsonrpc='2.0',id=id,method=method,params=params))

    def test_modern_discovery_and_inline_tools_without_initialize(self):
        result=self.request('server/discover')['result']
        self.assertEqual(result['resultType'],'complete'); self.assertIn(MODERN,result['supportedVersions'])
        result=self.request('tools/call',dict(name='autosw_catalog',arguments={}))['result']
        self.assertEqual(result['structuredContent']['title'],'AutoSW 中文'); self.assertFalse(result['isError'])

    def test_all_four_legacy_negotiations(self):
        for version in LEGACY:
            self.server=Server(self.Fake())
            result=self.request('initialize',dict(protocolVersion=version,capabilities={},clientInfo=dict(name='offline',version='1')),modern=False)['result']
            self.assertEqual(result['protocolVersion'],version); self.assertNotIn('resultType',result)
            self.assertIn('error',self.request('tools/list',modern=False))
            self.assertIsNone(self.server.process(dict(jsonrpc='2.0',method='notifications/initialized')))
            self.assertTrue(self.request('tools/list',modern=False)['result']['tools'])

    def test_missing_metadata_and_unsupported_version(self):
        self.assertEqual(self.request('tools/list',modern=False)['error']['code'],-32602)
        bad={'_meta':{'io.modelcontextprotocol/protocolVersion':'2099-01-01','io.modelcontextprotocol/clientCapabilities':{}}}
        self.assertEqual(self.request('server/discover',bad,modern=False)['error']['code'],-32022)

    def test_invalid_request_ids_batch_and_notification_no_response(self):
        for item in ([],{},dict(jsonrpc='2.0',id=None,method='ping'),dict(jsonrpc='2.0',id=True,method='ping'),
                     dict(jsonrpc='2.0',id=[],method='ping'),dict(jsonrpc='2.0',id=2**60,method='ping')):
            self.assertEqual(self.server.process(item)['error']['code'],-32600)
        self.assertIsNone(self.server.process(dict(jsonrpc='2.0',method='unknown')))

    def test_rejects_argument_scope_identity_rawshell_and_unknown_tool(self):
        for arguments in ({'workspace':'elsewhere'},{'binding_json':'fake'},{'argv':['cmd.exe']},{'api_key':'fake'}):
            response=self.request('tools/call',dict(name='autosw_catalog',arguments=arguments))
            self.assertEqual(response['error']['code'],-32602)
        self.assertEqual(self.request('tools/call',dict(name='shell',arguments={}))['error']['code'],-32602)

    def test_no_schema_has_hidden_shell_identity_or_workspace(self):
        for tool in DEFINITIONS:
            self.assertFalse(set(tool['inputSchema']['properties'])&{'workspace','account_id','session_id','binding_json','argv','command','api_key'})
            self.assertFalse(tool['inputSchema']['additionalProperties'])

    def test_successful_transport_with_unknown_native_is_error_tool_result(self):
        self.server.runtime.readback=lambda run_id:dict(ok=True,state='unknown',busy=True,process_exit_code=0,run_id=run_id)
        response=self.request('tools/call',dict(name='autosw_readback',arguments=dict(run_id=str(uuid.uuid4()))))['result']
        self.assertTrue(response['isError']); self.assertEqual(response['structuredContent']['process_exit_code'],0)


class StdioTests(unittest.TestCase):
    def launch(self, driver=None):
        temporary=tempfile.TemporaryDirectory(prefix='AutoSW-stdio-'); self.addCleanup(temporary.cleanup)
        if driver is None:
            args=[sys.executable,'-I','-B',str(SCRIPTS/'autosw.py'),'--workspace',temporary.name,'mcp']
        else:
            args=[sys.executable,'-I','-B','-c',driver]
        process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                 encoding='utf-8',text=True,bufsize=1)
        def clean():
            if not process.stdin.closed:
                try: process.stdin.close()
                except OSError: pass
            if process.poll() is None:
                try: process.wait(3)
                except subprocess.TimeoutExpired: process.kill(); process.wait(3)
            process.stdout.close(); process.stderr.close()
        self.addCleanup(clean)
        received=queue.Queue()
        def reader():
            for line in process.stdout: received.put(line)
        threading.Thread(target=reader,daemon=True).start()
        return process,received

    def send(self,process,message):
        process.stdin.write((message if isinstance(message,str) else json.dumps(message,ensure_ascii=False))+'\n')
        process.stdin.flush()

    def modern(self,id,method,**params):
        return dict(jsonrpc='2.0',id=id,method=method,params=dict(params,
            _meta={'io.modelcontextprotocol/protocolVersion':MODERN,'io.modelcontextprotocol/clientCapabilities':{}}))

    def test_real_cli_utf8_framing_invalid_json_and_eof_without_native(self):
        process,received=self.launch()
        self.send(process,self.modern('中文标识','server/discover'))
        self.assertEqual(json.loads(received.get(timeout=4))['id'],'中文标识')
        self.send(process,'{bad json')
        self.assertEqual(json.loads(received.get(timeout=4))['error']['code'],-32700)
        self.send(process,dict(jsonrpc='2.0',id=[],method='ping'))
        self.assertEqual(json.loads(received.get(timeout=4))['error']['code'],-32600)
        self.send(process,self.modern(2,'tools/list'))
        self.assertEqual(len(json.loads(received.get(timeout=4))['result']['tools']),len(DEFINITIONS))
        process.stdin.close(); self.assertEqual(process.wait(4),0)
        self.assertEqual(process.stderr.read(),'')

    def test_cancel_active_serial_tool_suppresses_response_does_not_run_second_native(self):
        # A fake long operation in a separate Python process: no native bridge exists.
        driver='import sys,time; sys.path.insert(0,'+repr(str(SCRIPTS))+'); from autosw_mcp import serve\n'
        driver+='class Fake:\n def catalog(self):\n  time.sleep(0.8)\n  return {"ok": True}\n'
        driver+='serve(Fake(),sys.stdin,sys.stdout)\n'
        process,received=self.launch(driver)
        self.send(process,self.modern(1,'tools/call',name='autosw_catalog',arguments={}))
        time.sleep(0.15)
        self.send(process,dict(jsonrpc='2.0',method='notifications/cancelled',params=dict(requestId=1)))
        self.send(process,self.modern(2,'ping'))
        result=json.loads(received.get(timeout=4)); self.assertEqual(result['id'],2)
        with self.assertRaises(queue.Empty): received.get(timeout=0.2)
        process.stdin.close(); self.assertEqual(process.wait(3),0)

    def test_eof_exits_during_fake_slow_operation(self):
        driver='import sys,time; sys.path.insert(0,'+repr(str(SCRIPTS))+'); from autosw_mcp import serve\n'
        driver+='class Fake:\n def catalog(self):\n  time.sleep(15)\n  return {"ok": True}\n'
        driver+='serve(Fake(),sys.stdin,sys.stdout)\n'
        process,received=self.launch(driver)
        self.send(process,self.modern(1,'tools/call',name='autosw_catalog',arguments={}))
        time.sleep(0.15); start=time.monotonic(); process.stdin.close()
        self.assertEqual(process.wait(3),0); self.assertLess(time.monotonic()-start,3)

    def test_invalid_utf8_never_writes_nonprotocol_stdout(self):
        process,received=self.launch()
        process.stdin.buffer.write(b'\xff\n'); process.stdin.buffer.flush()
        response=json.loads(received.get(timeout=4))
        self.assertEqual(response['jsonrpc'],'2.0'); self.assertEqual(response['error']['code'],-32700)
        process.wait(4)


if __name__=='__main__': unittest.main(verbosity=2)
