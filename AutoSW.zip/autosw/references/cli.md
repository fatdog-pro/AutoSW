# AutoSW 本地 CLI 与 MCP

独立入口是 `scripts/autosw.py`。便携包不附带 Python、SOLIDWORKS、厂商 DLL、SDK、许可或测试模型；使用 Windows x64、用户已安装的 64 位 Python 3.10+、Windows PowerShell 5.1，以及已安装并激活的 SOLIDWORKS。Python 仅使用标准库。实际原生能力和许可范围以本机 API 回执及验收为准。

先建立一个专用项目目录，将用户明确提供的图纸、图片及已有模型（包括引用组件）放在该目录的 `inputs/` 内。原输入只作身份检查和由官方 PackAndGo/导入产生副本；不要把整个磁盘、用户资料目录或技能安装目录作为工作区。

## 命令

以下 `python` 替换为本机 Python 的完整可执行路径，入口替换为本技能的真实绝对路径；`--workspace` 固定为一个既存项目目录。运行期间不要切换目录或通过其他执行器绕过绑定。

```text
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> verify
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> catalog
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> init
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> connect
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> status
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> api --type IModelDoc2 --member Save3
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> input-inspect --path inputs/model.sldprt
```

- `verify`：核对 `bridge-manifest.json` 中恰好七个桥接源码及聚合 SHA；不接触 CAD。
- `catalog`：返回包装器能力边界及同一源码冻结信息，不代表本机建模已通过。
- `init`：创建/读取本机用户私有的持久项目会话，不启动软件；分别返回 `pending_connect` 与 `pending_run`。
- `connect`：唯一允许显式启动或附接软件的命令。先持久化内部接入意图；原接入或原运行未决时拒绝第二次 connect，不自动重绑。
- `status`：检查已接受的原连接，或凭待确认的原接入意图恢复原连接。没有原连接和原接入意图时不寻找或接管全局实例。包含原 `pending_connect`、`pending_run` 和本工作区 run 摘要列表。空闲状态不能证明原未知 CAD 已完成。
- `api`：查询实际安装的官方类型/成员签名；需要先接入。
- `input-inspect`：仅返回 `inputs/` 受支持图纸/图片/CAD 文件的 SHA、大小和类型，不声称已识别尺寸或求解。

显式 `connect` 在派发前持久化独立 `connect_id`、本机用户/项目会话及桥源码 SHA。启动或复用宿主时，固定桥在用户私有目录写入不可覆盖的原意图和选定宿主证明。若回执丢失或状态文件短暂不可读，继续用 `status` 只按该原意图证明核对原宿主/SW 出生身份及主帧，不再次 connect、不启动另一个宿主或 SW。成功恢复显示 `connect_recovered=true`、`pending_connect=null`；缺证、身份/源码不一致或原宿主忙/未知时保持 `pending_connect`，拒绝新接入和 CAD 操作，不按“全局当前有个健康宿主”接管。升级前没有此意图证据的旧失败也不会自动认领。接入恢复不会解除另一个未知 CAD run。

启动前在安装验证/接口加载后再次完整核对进程；已有唯一 SW 时复用，查询失败不当作“没有 SW”。启动意图及实际 PID/出生身份在 COM 等待前落盘。`cad_execution_not_started` 仅表示未派发 CAD，不能用来推断应用没打开；`native_launch_may_have_occurred=true` 的初始化失败保留原意图，不盲重启。可验证的原启动前失败可由 status 结束该次连接占用，仍保留失败回执。宿主授权令牌不会在另一次接入时覆盖仍可能被原宿主使用的值。

写源码是一个明确独立操作：

```text
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> write-script --path sources/model.cs --source-stdin
```

将完整 UTF-8 C# `Build` 方法体写入该命令的标准输入；不含类声明/入口或任意 shell。返回源码 `sha256`。已存在文件需另外给 `--expected-sha256 <原SHA>`，防止悄悄覆盖。仅允许 `sources/*.cs`，最大 1 MiB；不能写桥接、私有状态、原生 run 或原输入。

脚本可用的 `ctx` 成员与保存/副本入口见[脚本上下文](native-api.md)。具体 SOLIDWORKS 官方对象签名继续使用 `api` 查询，不能由此表猜测厂商方法参数。

```text
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> run-script --path sources/model.cs --source-sha256 <已接受SHA> --operation-key model-v1
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> readback --run-id <原UUID>
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> open --run-id <原UUID>
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> cleanup --run-id <原UUID>
python -I -B <技能目录>/scripts/autosw.py --workspace <项目目录> disconnect
```

`run-script` 使用稳定意图键，只接受精确源码 SHA；执行前另存 `autosw-accepted/<run UUID>.cs` 冻结副本并持久化原 run。相同键与相同源只返回已保存回执，不再建模；相同键换源会拒绝。已知执行失败可依据真实错误另立修正意图，未知请求只能核对原 run，不能换键绕过。一个工作区同时只接受一个原生操作；跨进程也持有工作区锁。

结果 `saved=true` 与 `reopened=true` 是不同证明。当前结果若为 `verification_status=saved_native_verified_reopen_deferred`，表示结构/文件SHA/保存已核对，但因其他隐藏文档需保留，本次未调用关闭及磁盘重开；`reopen_verification` 记录原因、零关闭和范围。不能将 `ok=true` 或 `state=completed` 描述成已经盘开。缺少完整延后证据的普通 `reopened=false` 仍会拒绝。

`readback` 只处理本机当前用户、项目、持久会话登记的原 run，并注入它最初的连接身份。`open` 只打开已确认完成的原生产物，可指定该 run 记录范围内的 `--artifact solidworks-runs/<原UUID>/<原生文件>`。`cleanup` 仅正常关闭完成或已知失败 run 中归属明确、已保存的文档，未知仍拒绝；不删文件。`disconnect` 仅退役空闲宿主，保留 SW 和用户文档。不会模拟鼠标、键盘、屏幕识别或强杀用户软件。

通过参数解析的非 MCP 命令在 stdout 返回一份 UTF-8 JSON；命令行参数格式错误可能只在 stderr 显示用法并退出，不代表已受理原生动作。`process_exit_code` 保存实际桥接解释器退出事实，业务 `state/status/busy` 独立判断。退出码 0、`ok:true` 或宿主空闲均不能单独解除原未知 run。原生未确认时保留项目和请求，不隐瞒为成功。

打开/清理成果是独立于 CAD 建模结果的操作。已知操作失败会保留失败回执并结束这次操作占用，不把原建模失败改为成功，也不声称已关闭文档。旧版因已知清理失败遗留的占用，仅可在原桥源码恢复、同一原生身份的只读 `status` 明确空闲且原失败证据完整时解除；源码、身份或回执未决则保留。不能用一次普通 CAD 读回去抹掉另一项未知打开/清理操作。

`status` 若返回 `pending_result_operation`，其中 `command`、`run_id`、`state` 指向待核对的原 open/cleanup；继续用 status，不能以 readback 或新的 run 清除此操作。只有已知失败证据、原源码和同一空闲身份均满足恢复条件时，`recovered_operation` 才记录那次操作的 `outcome=failed`、`action_replayed=false`。这只解除已知失败的操作占用，原建模终态保持；未知结果操作仍保留，不声称已经打开或清理成功。

## stdio MCP

客户端命令指向本机 Python，参数为：

```json
{
  "command": "<Python完整路径>",
  "args": ["-I", "-B", "<技能绝对目录>/scripts/autosw.py", "--workspace", "<项目绝对目录>", "mcp"]
}
```

不要把示例占位符直接粘贴成实际路径；豆包是否提供本地 stdio/MCP 能力由其版本决定。普通网页聊天无法通过安装说明自动获得本机执行权限。

工具固定为：

| 工具 | 参数 |
| --- | --- |
| `autosw_catalog` / `autosw_connect` / `autosw_status` | `{}` |
| `autosw_api` | `type_name`，可选 `member` |
| `autosw_write_script` | `path`、`source`，覆盖时 `expected_sha256` |
| `autosw_run_script` | `path`、`source_sha256`、`operation_key` |
| `autosw_readback` / `autosw_cleanup` | `run_id` |
| `autosw_open` | `run_id`，可选 `artifact` |
| `autosw_input_inspect` | `path` |
| `autosw_disconnect` | `{}` |

所有工具参数拒绝额外字段；无 workspace、account、session、六字段身份、原始 argv、密钥、任意 shell 或桌面控制入口。执行器从用户私有 `%LOCALAPPDATA%/AutoSW/<用户与工作区摘要>/state.json` 取持久会话和已接受连接，目录 ACL 仅当前 Windows 用户和 SYSTEM。客户端提示词不能自行填写绑定或把任务转交另一实例。私有状态、桥接授权与六字段信息不返回模型。

MCP 每行一条 JSON-RPC，stdout 无额外日志；协议/参数错误使用 JSON-RPC error，执行失败使用 `tools/call` 的 `isError:true`。取消通知停止等待并抑制后续该 RPC 消息，已受理原生动作不能据此假称结束或重放；关闭 stdin 不退出 SW。重新启动 MCP 后先 `status`，有 `pending_run` 则核对原 UUID。

## 协议依据和验收边界

2026-11-01 只读核验的官方协议：

- [2026-07-28 版本模型](https://modelcontextprotocol.io/specification/2026-07-28/basic/versioning)、[Discovery](https://modelcontextprotocol.io/specification/2026-07-28/server/discover)、[逐请求 metadata](https://modelcontextprotocol.io/specification/2026-07-28/basic/index)、[stdio](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/stdio)、[Tools](https://modelcontextprotocol.io/specification/2026-07-28/server/tools)。现代请求在 `params._meta` 提供 protocolVersion/clientCapabilities，无 initialize；实现 `server/discover` 和 complete 结果。
- 兼容官方 [2024-11-05](https://modelcontextprotocol.io/specification/2024-11-05/basic/lifecycle)、[2025-03-26](https://modelcontextprotocol.io/specification/2025-03-26/basic/lifecycle)、[2025-06-18](https://modelcontextprotocol.io/specification/2025-06-18/basic/lifecycle)、[2025-11-25](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle) 的 initialize → initialized → tools 模式。只声明本适配器实现并离线验证的工具子集，不代表豆包已支持新协议或已实机连接。

离线协议及作用域测试运行 `python -B -m unittest discover -s <技能目录>/tests -v`；使用合成临时目录及 fake native runner。原生装配/配合、图纸解析与模型副本修改的实际验收另见 `verification.md`，不可用离线协议通过替代。
