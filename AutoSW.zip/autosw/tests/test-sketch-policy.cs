using System;

// Compile and audit method bodies only. Never invoke their Build methods.
public static class AutoSWSketchPolicyTests {
    public static int Run(string scratch) {
        var allowed=YanLabsSWScriptCompiler.Compile(
            "ISketchManager sketch=null;bool previous=sketch.AddToDB;try{sketch.AddToDB=true;}finally{sketch.AddToDB=previous;}",scratch);
        if(allowed==null)throw new Exception("AddToDB Boolean set/restore did not compile and pass the IL guard");
        Reject("IModelDocExtension extension=null;extension.BreakAllExternalFileReferences2(false);",scratch,".BreakAllExternalFileReferences2");
        Reject("ISldWorks app=null;int errors=0,warnings=0;app.OpenDoc6(\"unexecuted.sldprt\",1,1,\"\",ref errors,ref warnings);",scratch,".OpenDoc6");
        return 3;
    }
    private static void Reject(string body,string scratch,string member) {
        try {YanLabsSWScriptCompiler.Compile(body,scratch);}
        catch(InvalidOperationException error) {
            if(error.Message.Contains("Model API call blocked:")&&error.Message.Contains(member))return;
            throw new Exception("Expected an IL policy rejection for "+member+", received: "+error.Message);
        }
        throw new Exception("The IL guard unexpectedly allowed "+member);
    }
}
