"""SOLIDWORKS reviewed CLI; CAD work is owned by one same-login STA host."""
import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from core import execute, NativeOperationFailed, NativeOutcomeUnknown


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['catalog','connect','status','disconnect','close-owned-empty','api','run','script','readback','open','cleanup'])
    parser.add_argument('--workspace', required=True)
    parser.add_argument('--run-id')
    parser.add_argument('--spec')
    parser.add_argument('--script')
    parser.add_argument('--artifact')
    parser.add_argument('--type', dest='type_name')
    parser.add_argument('--member', dest='member_name')
    parser.add_argument('--expected-connection-json', help='Internal caller-accepted host/process/window binding; never supplied by model arguments')
    parser.add_argument('--binding-json')
    parser.add_argument('--connect-intent-json',help='Internal fixed-wrapper connect intent; never supplied by model arguments')
    args = parser.parse_args()
    try:
        receipt = execute(args.command,args.workspace,args.run_id,args.spec,args.binding_json,
                          args.script,args.artifact,args.type_name,args.member_name,args.expected_connection_json,args.connect_intent_json)
        print(json.dumps(receipt,ensure_ascii=True))
        return 0 if receipt.get('ok') is True else 1
    except Exception as error:
        details = getattr(error,'native_details',{})
        unknown = isinstance(error,NativeOutcomeUnknown) or getattr(error,'unknown',False)
        connect_id=None
        if args.connect_intent_json:
            try:connect_id=json.loads(args.connect_intent_json).get('connect_id')
            except (ValueError,AttributeError):pass
        print(json.dumps(dict(ok=False,error=str(error),code=getattr(error,'code','SW_NATIVE_FAILED'),
                             state='unknown' if unknown else 'failed',
                             run_id=args.run_id,
                             connect_id=connect_id,
                             execution_not_started=getattr(error,'execution_not_started',False),
                             original_request_preserved=True,**details),ensure_ascii=True))
        return 1


if __name__ == '__main__':
    sys.exit(main())
